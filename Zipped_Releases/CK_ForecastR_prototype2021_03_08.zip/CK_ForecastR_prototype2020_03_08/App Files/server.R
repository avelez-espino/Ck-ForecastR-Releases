
# INSERT PASSWORD STEP (CHECK WITH JOHN SON)


function(input, output, session) {


# Obsolete (old code and old report)
#  source("R/2_MainFunctionCall.R")
#	source("R/3a_HelperFunctions_ModelFitting.R")
#	source("R/3b_HelperFunctions_ReportCreation.R")

# for local debugging, turn on this part and comment out the package install below
source("R/3c_HelperFunctions_ModelSetup.R")
source.modules("R/")

# This pulls in the code for the new modules from the main report
# NOT WORKING ON SERVER DEPLOYMENT!
#library(devtools) # Load the devtools package.
#install_github("MichaelFolkes/forecastR_package")

# SHOULD NOT NEED THIS ANYMORE
load_or_install(c("meboot","forecast"))
library("meboot")
library("forecast")

# Think it needs these here for the server deployment
# These are all shiny specific (not needed in the package)
load_or_install(c("ggplot2","DT","markdown","rmarkdown","shiny","shinydashboard","shinyjqui","shinyFiles"))
library("ggplot2")
library("DT")
library("markdown")
library("rmarkdown")
library("shiny")
library("shinydashboard")
library("shinyjqui")
library("shinyFiles")





	volumes.use <- getVolumes()
	shinyDirChoose(input,"repdir",roots=getVolumes())
	reports.path.use <- reactive(input$repdir)
	output$reports.path.use <- renderPrint({   parseDirPath(roots=volumes.use, selection =reports.path.use())  })





	# Read in user-selected input file
    data.file <- reactive({
		inFile <- input$file.name.2
		if(is.null(inFile)){ data.use <- matrix(NA,ncol=2,nrow=5)}
		if(!is.null(inFile)){

			data.file.tmp <- read.csv(inFile$datapath, stringsAsFactors=FALSE)


			# doing this here for now, but it's a kludge -> see https://github.com/avelez-espino/forecastR_phase4/issues/39
			settings.cols <- c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")
			settings.tmp <- data.file.tmp[,settings.cols]
			data.use <- data.file.tmp[,!(dimnames(data.file.tmp)[[2]] %in% settings.cols)]

			yrs.window <- min(data.use$Run_Year) : max(data.use$Run_Year) # need this for all the other tabs -> just keep all the records
			if(input$MainTab == "precheck"){yrs.window <- input$yr.range.precheck[1]:max(data.use$Run_Year) }
			if(input$MainTab == "compare"){yrs.window <- input$yr.range.compare[1]:max(data.use$Run_Year) }
			if(input$MainTab == "report.withage"){yrs.window <- input$yr.range.report.withage[1]:max(data.use$Run_Year) }
			if(input$MainTab == "report.withoutage"){yrs.window <- input$yr.range.report.withoutage[1]:max(data.use$Run_Year) }


			records.keep <-  data.use$Run_Year %in% yrs.window
			data.use <- data.use[records.keep,]
			data.use <- cbind(settings.tmp[1:dim(data.use)[1],],data.use)
			}

	return(data.use)

	})


	 settings.basic <- reactive({
			data.file.tmp <- data.file()

			settings.list <- list(Stock = data.file.tmp[1,"Stock_Name"],
								Species = data.file.tmp[1,"Stock_Species"],
								Abundance = data.file.tmp[1,"Stock_Abundance"],
								FCYear = data.file.tmp[1,"Forecasting_Year"]
								)

			return(settings.list)


			})



model.list <-  reactive({

	data.file.tmp <- data.file()

	# models for all input types
	model.types <- list("Naive" = "Naive", "Time Series" = c("TimeSeriesArima","TimeSeriesExpSmooth"))

	pred.check <- sum(grepl("Pred_",names(data.file.tmp))) > 0  # have any predictor vars in data set?
	if(pred.check){ model.types <- c(model.types,list(ReturnRate = "ReturnRate"))}

	age.check <-   length(unique(data.file.tmp$Age_Class)) > 1   # have age classes in the data set?
	if(age.check){ model.types <- c(model.types,list(Sibling = c("SibRegSimple","SibRegLogPower", "SibRegKalman")))}


	return(model.types)
	})



predictors.list <- 	 reactive({
	data.file.tmp <- data.file()
	pred.check <- sum(grepl("Pred_",names(data.file.tmp)))>0 # have any predictor vars in data set?
	if(pred.check ){
			pred.vars  <-  names(prepData(data.file.tmp,out.labels="v2")$predictors[[1]]) # extract the col names for the first age class (should all be the same)
			drop.idx <- pred.vars %in% c("Run_Year","Brood_Year")
			pred.vars <- pred.vars[!drop.idx]
	}
	if(!pred.check){ pred.vars <- NULL }
	return(pred.vars)
	})


ages.list <-  reactive({
	data.file.tmp <- data.file()
	ages.vec <-   paste0("Age ",sort(unique(data.file.tmp$Age_Class)))

	if(length(ages.vec)>1){ages.vec <- c("all",ages.vec)}
	if(length(ages.vec)==1){ages.vec <- c("all")}

	return(ages.vec)
	})


######################################################################
# MODEL PRE_CHECK PIECES ("Explore" Tab)
######################################################################

# SHOULD EXTRACT THE data.file -> prepData as a reactive judge


# model list for Explore tab
output$model.menu.precheck <- renderUI({
	selectizeInput("model.use.precheck", "Model Type", choices = model.list(),
								 multiple=FALSE, selected=model.list()[1])
		})

# Predictor Variable List for Explore Tab
output$pred.var.precheck.menu <- renderUI({
	selectInput("pred.var.precheck", label = "Rate: Predictor", choices = predictors.list(),
							multiple=FALSE,selected = predictors.list()[1] )
				})


# Ages List for Explore Tab
output$ages.menu.precheck <- renderUI({
	selectizeInput("precheck.ageclass", "Age Class", choices = ages.list(),
								 multiple=FALSE, selected=ages.list()[1])
})


# TS: box cox option for Explore Tab
output$boxcox.precheck.menu <- renderUI({
	checkboxInput("precheck.boxcox", label="Time Series: Box-Cox Transform", value = FALSE )
})


# Naive: num yrs avg option for Explore Tab
output$avgyrs.precheck.menu <- renderUI({
	numericInput("precheck.avgyrs", label=h5("Naive: Avg Years"), value = 3 , min = 1, max = 10, step = 1,   width = "50%")
})


# Sibreg Kalman: AVG N OPTION for Explore Tab
output$intavg.precheck.menu <- renderUI({
	numericInput("precheck.intavg", label=h5("SibReg Kalman: Avg n Est"), value = 5, min = 1, max = 10, step = 1,   width = "50%")
})



# Predictor Variable List for Compare Tab - Model 10
output$m10.pred.var.menu <- renderUI({
	selectInput("m10.pred.var", label = "Rate:Predictor", choices = predictors.list(),
							multiple=FALSE,selected = predictors.list()[1] )
})



# Predictor Variable List for Compare Tab - Model 11
output$m11.pred.var.menu <- renderUI({
	selectInput("m11.pred.var", label = "Predictor", choices = predictors.list(),
							multiple=FALSE,selected = predictors.list()[1] )
})





	precheck.settings  <- reactive({

		print(input$model.use.precheck )

					# extract settings (should streamline)
				if(input$model.use.precheck  %in% c("TimeSeriesArima","TimeSeriesExpSmooth")){settings.use <- list(BoxCox= input$precheck.boxcox)}
				if(input$model.use.precheck  %in% c("ReturnRate")){
								settings.use <- list(avg =  input$rate.avg.precheck,
																		 pred.label= input$pred.var.precheck,
																		  last.n= input$last.n.precheck
																		 )}
				if(input$model.use.precheck  %in% c("Naive")){settings.use <- list(avg.yrs= input$precheck.avgyrs)}
				if(input$model.use.precheck  %in% c("SibRegKalman")){settings.use <- list(int.avg= input$precheck.intavg)}
				if(input$model.use.precheck  %in% c( "SibRegSimple","SibRegLogPower")){settings.use <- NULL}

				return(settings.use)

					})

	precheck.modelfit  <- reactive({
				data.file.tmp <- data.file()
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				settings.use <- precheck.settings()

				fit.obj <- fitModel(model= input$model.use.precheck, data = sample.dat$data,
														settings = settings.use ,tracing=FALSE)


				#print(input$model.use.precheck)
				#print(sample.dat$data)
				#print(settings.use)
				#print("-------------------------------------------")
				#print(fit.obj$"Age 3")
				#print("-------------------------------------------")
				#print(fit.obj$"Age 4")
				#print(names(fit.obj))

				return(fit.obj)
			})


    precheck.fc <- reactive({
				data.file.tmp <- data.file()
				settings.basic.use <- settings.basic()
				fit.obj <- precheck.modelfit()
				settings.use <- precheck.settings()

				sample.dat <-  prepData(data.file.tmp,out.labels="v2")



				if(is.null(predictors.list())){
						fc.obj <- calcFC(fit.obj= fit.obj,data = sample.dat$data, fc.yr= settings.basic.use$FCYear,
														 settings = settings.use, tracing=FALSE)
				}

				if(!is.null(predictors.list())){

					fc.obj <- calcFC(fit.obj= fit.obj,data = sample.dat$data, fc.yr= settings.basic.use$FCYear,
													 settings = settings.use,
													 predictors = sample.dat$predictors,tracing=FALSE)

				}

				#print(fc.obj)

				return(fc.obj)

				})


	int.samples.calc <- reactive({

			# for bootstrap and retrospective, calculate the samples, then the quantiles based on the samples
			# for prediction intervals its the other way around....

   			data.file.tmp <- data.file()
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				boot.type.in <- input$boot.type.precheck
				boot.n.in <- input$boot.n.precheck
				settings.use <- precheck.settings()
				settings.basic.use <- settings.basic()
				int.type <- input$interval.type.precheck
				fc.in <-  precheck.fc()


				if(int.type == "Bootstrap"){

					boot.int <- doBoot(data= sample.dat, args.fitmodel= list(model= input$model.use.precheck, settings = settings.use),
						args.calcfc = list(fc.yr= settings.basic.use$FCYear,  settings = settings.use),
						args.boot = list(boot.type=boot.type.in, boot.n=boot.n.in, plot.diagnostics=FALSE),
						full.out = TRUE, plot.out=FALSE)

					#print(head(boot.int))




					int.samples.out <- boot.int

					} # end if bootstrap


				if(int.type == "Retrospective"){

					min.retro.yrs <- input$min.retroyrs.explore

					retro.int <- doRetro(model= input$model.use.precheck, data = sample.dat$data,
            predictors =  sample.dat$predictors, covariates = sample.dat$covariates,
						retro.settings = list(min.yrs=min.retro.yrs),
						fit.settings = settings.use,
						fc.settings = settings.use,
						tracing=FALSE,out.type="short",
						interval.n = boot.n.in,
						interval.quants = FALSE,
						pt.fc = fc.in)

					int.samples.out <- 	retro.int$retro.interval



					} # end if retrospective



					if(int.type == "Prediction"){


						int.samples.out <- doSampleFromInt(fc.obj=fc.in, interval.n=boot.n.in,interval.quants=FALSE)

					} # end if prediction


				#print("-----int.samples.out---------")
				#print(int.samples.out)

					return(int.samples.out)

					})



	  explore.fc.table <- reactive({

				pt.fc <- precheck.fc()
				int.samples <- int.samples.calc()

				fc.mat <- apply(int.samples,MARGIN=2,FUN=quantile,probs=c(0.1,0.25,0.5,0.75,0.90))

				ages.labels <- dimnames(int.samples)[[2]]
				fc.mat <- as.data.frame(rbind(PointFc = unlist(pt.fc$pt.fc), fc.mat))
				fc.mat <- round(fc.mat)
				fc.mat <- sapply(fc.mat , FUN=function(x) prettyNum(x, big.mark=","))

				dimnames(fc.mat)[[2]] <- ages.labels
				dimnames(fc.mat)[[1]] <- c("PointFC", "p10", "p25", "Median", "p75", "p90")

				return(fc.mat)

			})


	 output$table.explore.fc <- DT::renderDataTable(
	 				DT::datatable(explore.fc.table(), options = list(paging = FALSE))
					)


    output$download.table.explore.fc <- downloadHandler(
					filename = function(){"TableForecastByAge.csv"},
					content = function(fname){
						write.csv(explore.fc.table(), fname,row.names=TRUE)
					}
					)




	output$precheck.plot.fitandfc <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				#print(fc.in)
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "fitted_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in )



					})



   	output$precheck.plot.resid_ts <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in )
				})

   	output$precheck.plot.fitvsobs <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "fitvsobs",age.which=age.in,plot.add=FALSE), fc.add= fc.in )
				})


   	output$precheck.plot.residvsfitted <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				#print("starting residsvsfitted plot----------------------------")
				#print(fit.in)
				#print(fc.in)

				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "residvsfitted",age.which=age.in,plot.add=FALSE),
										 fc.add= fc.in )
				})



   	output$precheck.plot.resid_hist<- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_hist",age.which=age.in,plot.add=FALSE), fc.add= fc.in )
				})




   	output$precheck.plot.resid_qq <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_qq",age.which=age.in,plot.add=FALSE), fc.add= fc.in )
				})


   	output$precheck.modeldiagnostic <- renderPlot({

				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "modeldiagnostic",age.which=age.in,plot.add=FALSE), fc.add= fc.in )
				})


    	output$precheck.plot.boots.sample <- renderPlot({
				data.file.tmp <- data.file()
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				age.in <- input$precheck.ageclass
				boot.type.in <- input$boot.type.precheck
				plotBootSeries(sample.dat$data, boot.type = boot.type.in, age.which=age.in)

				})






		output$precheck.plot.intervals <- renderPlot({

						int.type <- input$interval.type.precheck
						int.samples <- 	int.samples.calc()

						#print("starting plot")
						#print(head(int.samples))
						#print(colMeans(int.samples))
						#print(int.samples$'Age 5')



						box.plot(int.samples, y.lab = "Forecast Abundance",
							fill.vec = "lightblue" ,border.vec= "darkblue",
							labels=TRUE,violin=TRUE,y.lim=c(0,max(unlist(int.samples))),
							labels.angle = 0,labels.adj=c(0.5,2))

						title(main=paste0("Forecast Interval - ", int.type))



							})


  output$"downloadPreCheckRep" <- downloadHandler(
    filename = function() {
      paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck,"_",  gsub(" ","",input$precheck.ageclass),"_",  Sys.Date(), ".pdf", sep="")
    },
    content = function(file) {

	pdf(file,onefile=TRUE,width=11,height=8.5)

		fit.in <- precheck.modelfit()
		fc.in <-  precheck.fc()
		age.in <- input$precheck.ageclass

		data.file.tmp <- data.file()
		sample.dat <-  prepData(data.file.tmp,out.labels="v2")
		boot.type.in <- input$boot.type.precheck
		boot.n.in <- input$boot.n.precheck
		settings.use <- precheck.settings()
		settings.basic.use <- settings.basic()

		doBoot(data= sample.dat, args.fitmodel= list(model= input$model.use.precheck, settings = settings.use),
					args.calcfc = list(fc.yr= settings.basic.use$FCYear,  settings = settings.use),
					args.boot = list(boot.type=boot.type.in, boot.n=boot.n.in, plot.diagnostics=FALSE),
					full.out = FALSE, plot.out=TRUE)



		plotModelFit(fit.in, options= list(plot.which = "precheck.report",age.which=age.in,plot.add=FALSE), fc.add= fc.in )

		data.file.tmp <- data.file()
		sample.dat <-  prepData(data.file.tmp,out.labels="v2")
		boot.type.in <- input$boot.type.precheck
		plotBootSeries(sample.dat$data, boot.type = boot.type.in, age.which=age.in)



		dev.off()
    }
  )



######################################################################
# MODEL COMPARISON PIECES ("Compare" Tab)
######################################################################

	  output$compare.ageclass <- renderText({  input$compare.ageclass })

     multifc.list.gui <- reactive({

				multifc.list <- NULL

				# SHOULD CHANGE THE INPUTS FOR extractSettings() to a named list!!!!!!!!!!!!!!!!!!

				if(input$m1.use){multifc.list[[input$m1.name]] <-list(model.type= input$m1.modeltype, settings=extractSettings(input$m1.modeltype,input$m1.avgyrs,input$m1.boxcox,input$m1.kfyear))	}
				if(input$m2.use){multifc.list[[input$m2.name]] <-list(model.type= input$m2.modeltype, settings=extractSettings(input$m2.modeltype,input$m2.avgyrs,input$m2.boxcox,input$m2.kfyear))	}
				if(input$m3.use){multifc.list[[input$m3.name]] <-list(model.type= input$m3.modeltype, settings=extractSettings(input$m3.modeltype,input$m3.avgyrs,input$m3.boxcox,input$m3.kfyear))	}
				if(input$m4.use){multifc.list[[input$m4.name]] <-list(model.type= input$m4.modeltype, settings=extractSettings(input$m4.modeltype,input$m4.avgyrs,input$m4.boxcox,input$m4.kfyear))	}
				if(input$m4.use){multifc.list[[input$m5.name]] <-list(model.type= input$m5.modeltype, settings=extractSettings(input$m5.modeltype,input$m5.avgyrs,input$m5.boxcox,input$m5.kfyear))	}
				if(input$m6.use){multifc.list[[input$m6.name]] <-list(model.type= input$m6.modeltype, settings=extractSettings(input$m6.modeltype,input$m6.avgyrs,input$m6.boxcox,input$m6.kfyear))	}
				if(input$m7.use){multifc.list[[input$m7.name]] <-list(model.type= input$m7.modeltype, settings=extractSettings(input$m7.modeltype,input$m7.avgyrs,input$m7.boxcox,input$m7.kfyear))	}
				if(input$m8.use){multifc.list[[input$m8.name]] <-list(model.type= input$m8.modeltype, settings=extractSettings(input$m8.modeltype,input$m8.avgyrs,input$m8.boxcox,input$m8.kfyear))	}
				if(input$m9.use){multifc.list[[input$m9.name]] <-list(model.type= input$m9.modeltype, settings=extractSettings(input$m9.modeltype,input$m9.avgyrs,input$m9.boxcox,input$m9.kfyear))	}
				if(input$m11.use){multifc.list[[input$m11.name]] <-list(model.type= input$m11.modeltype, settings=extractSettings(input$m11.modeltype,input$m11.avgyrs,input$m11.boxcox,input$m11.kfyear,
																																																													input$m11.pred.var,input$m11.rate.avg,input$m11.last.n))	}
				if(input$m10.use){multifc.list[[input$m10.name]] <-list(model.type= input$m10.modeltype, settings=extractSettings(input$m10.modeltype,input$m10.avgyrs,input$m10.boxcox,input$m10.kfyear,
																																																													input$m10.pred.var,input$m10.rate.avg,input$m10.last.n))	}


				return(multifc.list)

				})


		compare.multifit  <- reactive({
				data.file.tmp <- data.file()
				min.retro.yrs <- input$min.retroyrs.compare
				int.type.in <- input$interval.type.compare
				int.n.in <- input$boot.n.compare
				boot.type.in <- input$boot.type.compare
				settings.use <- multifc.list.gui()

				multiresults.retro <- multiFC(data.file=data.file.tmp,settings.list=settings.use,
								do.retro=TRUE,retro.min.yrs=min.retro.yrs,
								out.type="short",
								int.type = int.type.in, int.n = int.n.in ,
								boot.type = boot.type.in,
								tracing=FALSE)


				return(multiresults.retro)


				})





		compare.ptfc.table <- reactive({
					multifit.out <- compare.multifit()
					multi.ptfc <- round(multifit.out[["table.ptfc"]])
					model.names <- dimnames(multi.ptfc )[[1]]


					multi.ptfc <- sapply(multi.ptfc , FUN=function(x) prettyNum(x, big.mark=","))


					dimnames(multi.ptfc )[[1]] <- model.names
					return(multi.ptfc)
					})





			compare.int.array <- reactive({

					#this is the full array of model * plevel * age, without number formatting

					multifit.out <- compare.multifit()
					multi.int.array <- round(multifit.out[["int.array"]])
					return(multi.int.array )


					})

			compare.int.table <- reactive({

					# this is the formatted table of model * plevel for the user-selected age class
					# WARNING: These are now text values with formatting ("13,174" vs 13174)

					multi.int.array <- compare.int.array()

					multi.int.table <- as.data.frame(multi.int.array[,,input$compare.ageclass])
					model.names <- dimnames(multi.int.table)[[1]]
					multi.int.table  <- sapply(multi.int.table , FUN=function(x) prettyNum(x, big.mark=","))

					dimnames(multi.int.table )[[1]] <- model.names
					return(multi.int.table )


					})





#		output$table.multi.ptfc  <- renderTable(
#				compare.ptfc.table(), rownames= TRUE, digits=0 , stripes = TRUE, hover = TRUE
#				)

# obsolete, because using version with rank added in below
#     output$table.multi.ptfc <- DT::renderDataTable(
#	 				DT::datatable(compare.ptfc.table(), options = list(paging = FALSE))
#					)

     	output$compare.ptfc <- renderPlot({

					multifit.out <- compare.multifit()
					rank.table <- compare.ranking.table()

					multi.int.array <- compare.int.array()

					int.table  <- as.data.frame(multi.int.array[,,input$compare.ageclass])


					if(input$compare.plotsort == "AvgRank") {order.idx  <- order(rank.table[,"rank.avg"])}
					if(input$compare.plotsort == "Forecast") {order.idx  <- order(multifit.out[["table.ptfc"]][,input$compare.ageclass])}

					#print(order.idx)

					#print("rank.table")
					#print(rank.table)
					#print("multifit.out[[table.ptfc]]")
					#print(multifit.out[["table.ptfc"]])


					multi.ptfc <- multifit.out[["table.ptfc"]][order.idx,,drop=FALSE]
					fc.p10 <- int.table[order.idx,"p10"]
					fc.p90 <- int.table[order.idx,"p90"]

					model.names <- paste0(dimnames(rank.table)[[1]][order.idx]," (",round(rank.table[order.idx,"rank.avg"],1),")")


					n.models <- length(model.names)


					vec.plot <- multi.ptfc[,input$compare.ageclass]


					par(mai=c(1,2.5,1.5,1))
					plot(vec.plot , n.models:1, axes=FALSE,xlim = c(0,max(fc.p90)), xlab="Forecast",ylab="", ylim=c(0,n.models+1),
							pch=19,type="p",cex=1.5,col="red",cex.lab=1.4,main=input$compare.ageclass,col.main="darkblue")
					abline(h=1:n.models,col="lightgrey")
					segments(fc.p10,n.models:1,fc.p90, n.models:1,col="red",lwd=2)

					# Pt FC
					points(vec.plot , n.models:1, pch=19,type="p",cex=1.5,col="red")
					text(vec.plot , (n.models:1)+0.2, labels=prettyNum(round(vec.plot),big.mark=","),cex=1,col="red")

					# bounds
					#points(fc.p10,n.models:1,col="red",pch=4,cex=0.8)
					text(fc.p10 , (n.models:1)+0.2, labels=prettyNum(round(fc.p10),big.mark=","),cex=0.7,col="red")
					#points(fc.p90,n.models:1,col="red",pch=4,cex=0.8)
					text(fc.p90 , (n.models:1)+0.2, labels=prettyNum(round(fc.p90),big.mark=","),cex=0.7,col="red")


					axis(2,at=n.models:1,labels=model.names,las=2,cex.axis=1.2)
					axis(1)


			})






		compare.rankingpm <- reactive({input$compare.pm})


		compare.retropm.array<- reactive({
					multifit.out <- compare.multifit()

					multi.retropm <- multifit.out[["retro.pm"]][[input$retrotype.compare]]


					return(multi.retropm)
					})

		compare.retropm.table<- reactive({
					multi.retro.obj <- compare.retropm.array()
					retropm.table.out <- multi.retro.obj[,,input$compare.ageclass]
					return(retropm.table.out)
					})



		compare.ranking.obj <- reactive({
					ranking.pm.use <- compare.rankingpm()
					multi.retro.obj <- compare.retropm.array()



					ranking.out <- rankModels(dat = multi.retro.obj,columnToRank=ranking.pm.use, relative.bol=input$rel.bol)

					#print(ranking.out)
					# OLD VERSION
					#ranking.out <- getRanks(as.data.frame(multi.retropm), columnToRank = ranking.pm.use)
					#ranking.out <- ranking.out[ , grep("rank",dimnames(ranking.out)[[2]])]   # extract only the rank columns
					# can't sort here, b/c will screw up the merge below!!!
					#ranking.out <- ranking.out[order(ranking.out$average.rank),]

					return(ranking.out)
					})


		compare.ranking.table <- reactive({
					ranking.obj <- compare.ranking.obj()
					ranking.table.out  <- ranking.obj[[input$compare.ageclass]]
					ranking.table.out <- ranking.table.out[ , grep("rank",dimnames(ranking.table.out)[[2]])] # extract only the rank columns
					ranking.table.out <- round(ranking.table.out,2)
					return(ranking.table.out)
					})

		compare.cumul.ranking.table <- reactive({
					ranking.obj <- compare.ranking.obj()
					ranking.table.out  <- ranking.obj$cumulativerankSorted
					ranking.table.out <- ranking.table.out[ , grep("rank",dimnames(ranking.table.out)[[2]])] # extract only the rank columns
					ranking.table.out <- round(ranking.table.out,2)
					return(ranking.table.out)
					})


		compare.bestmodel.table <- reactive({

					multifit.out <- compare.multifit()
					pt.fc.in  <- round(multifit.out[["table.ptfc"]])
					ranking.obj <- compare.ranking.obj()
					ranking.bestmodel.out  <- ranking.obj$bestmodel
					multi.int.array <- compare.int.array()

					summary.table <- tableForecastRanking(pt.fc.in = pt.fc.in  , int.in = multi.int.array,
										bestmodel.in = ranking.bestmodel.out )

					return(summary.table )
					})


		compare.ptfc.table.merged <- reactive({
					fc.table <-  compare.ptfc.table()
					rank.table <- compare.ranking.table()
					merged.table <- cbind(AvgRank = round(rank.table[,"rank.avg"],2),fc.table)



					return(merged.table)
					})


     output$table.multi.ptfc <- DT::renderDataTable(
	 				DT::datatable(compare.ptfc.table.merged(), options = list(paging = FALSE))
					)

     output$compare.int.table <- DT::renderDataTable(
	 				DT::datatable(compare.int.table(), options = list(paging = FALSE),caption=input$compare.ageclass)
					)




     output$table.retropm <- DT::renderDataTable(
	 				DT::datatable(compare.retropm.table(), caption = input$compare.ageclass , options = list(paging = FALSE))
					)



      output$table.ranking <- DT::renderDataTable(
	 				DT::datatable(compare.ranking.table(), caption = input$compare.ageclass , options = list(paging = FALSE))
					)

      output$table.cumul.ranking <- DT::renderDataTable(
	 				DT::datatable(compare.cumul.ranking.table(), caption = "Cumulative Ranks" , options = list(paging = FALSE))
					)



       output$table.bestmodels <- DT::renderDataTable(
	 				DT::datatable(compare.bestmodel.table(), rownames=FALSE, options = list(paging = FALSE))
					)



 		output$download.ptfc.table.merged <- downloadHandler(
					filename = function(){"TablePointForecasts.csv"},
					content = function(fname){
						write.csv(compare.ptfc.table.merged(), fname,row.names=TRUE)
					}
					)


		output$download.bestmodels.table <- downloadHandler(
					filename = function(){"Table_BestModels.csv"},
					content = function(fname){
						write.csv(compare.bestmodel.table(), fname,row.names=FALSE)
					}
					)




	output$downloadComparisonRepWordShort <- downloadHandler(
	# using template from https://shiny.rstudio.com/articles/generating-reports.html
			filename =   paste0("WordReport_Short",Sys.Date(),".doc"),
			content = function(file) {
	        # Copy the report file to a temporary directory before processing it, in
			# case we don't have write permissions to the current working dir (which
			# can happen when deployed).
        tempReport <- file.path(tempdir(), "Report_ShortComp.Rmd")
        file.copy("Markdown/Report_ShortComp.Rmd", tempReport, overwrite = TRUE)

		settings.basic.use <- settings.basic()
        params <- c(settings.basic.use,
					list(Table_Multi_Pt_FC = compare.ptfc.table.merged()), # formatted table 1
					list(multifit.out = compare.multifit() )   # raw outputs in a list object
					)

        # Knit the document, passing in the `params` list, and eval it in a
        # child of the global environment (this isolates the code in the document
        # from the code in this app).
        rmarkdown::render(tempReport, output_file = file,
          params = params,
          envir = new.env(parent = globalenv())
			) # end render()
      } # end content
    ) # end downloadHandler()


 	output$downloadComparisonRepWordLong <- downloadHandler(
	# using template from https://shiny.rstudio.com/articles/generating-reports.html
			filename =   paste0("WordReport_Long",Sys.Date(),".doc"),
			content = function(file) {
	        # Copy the report file to a temporary directory before processing it, in
			# case we don't have write permissions to the current working dir (which
			# can happen when deployed).
        tempReport <- file.path(tempdir(), "Report_LongComp.Rmd")
        file.copy("Markdown/Report_LongComp.Rmd", tempReport, overwrite = TRUE)

		settings.basic.use <- settings.basic()
        params <- c(settings.basic.use,
					list(Table_Multi_Pt_FC = compare.ptfc.table.merged()), # formatted table 1
					list(multifit.out = compare.multifit() )   # raw outputs in a list object
					)

        # Knit the document, passing in the `params` list, and eval it in a
        # child of the global environment (this isolates the code in the document
        # from the code in this app).
        rmarkdown::render(tempReport, output_file = file,
          params = params,
          envir = new.env(parent = globalenv())
			) # end render()
      } # end content
    ) # end downloadHandler()

















	# not working for some reason
   	#	compare.fittedpm.table <- reactive({
	#				multifit.out <- compare.multifit()
	#				multi.fittedpm <- multifit.out[["retro.pm"]][["fitted.pm.last"]][,,input$compare.ageclass]
	#				return(multi.fittedpm)
	#				})

	#	output$table.fittedpm <- renderTable(
	#			compare.fittedpm.table(), rownames= TRUE, stripes = TRUE, hover = TRUE
	#			)



######################################################################
# OTHER STUFF
######################################################################

	output$inputheader.table <- renderTable({ data.file() })  # masking issue with package DT? shiny::renderTable doesn't fix it












}

