#### Protoype version: 2021-03-08 v1

You are working with a rapidly evolving prototype.
The ForecastR team is trying to address quirks and bugs
as they are found by users like you. 

To check a list of know bugs/issues with this prototype, 
and to add any new bugs/issues with this prototype,
go to **[this github thread](https://github.com/avelez-espino/Ck-ForecastR-Releases/issues/13)**

For more information about the app, check the *Help* and *About* tabs.

**What's New?**

Since the last major release in the spring of 2020,
the following major updates have been implemented:

* Return Rate (Mechanistic) Model added to the package code
and to the app interface.
* Explore tab options dynamically respond to data set and model selection (e.g. only show sibling regression model options
if data has age classes, menu options for model settings adapt to model selection)
*  Compare tab model selection re-design: have tabs for each model type now, with model-specific options.





