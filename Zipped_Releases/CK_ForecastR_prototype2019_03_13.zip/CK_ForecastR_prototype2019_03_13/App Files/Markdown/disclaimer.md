#### Protoype version: 2019-03-13 v1

You are working with a rapidly evolving prototype.
The ForecastR team is trying to address quirks and bugs
as they are found by users like you. 

To check a list of know bugs/issues with this prototype, 
and to add any new bugs/issues with this prototype,
go to **[this github thread](https://github.com/avelez-espino/Ck-ForecastR-Releases/issues/13)**

For more information about the app, check the *Help* and *About* tabs.


