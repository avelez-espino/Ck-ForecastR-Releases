### Model comparisons

interactive summary diagnostics go here