
# INSERT PASSWORD STEP (CHECK WITH JOHN SON)


function(input, output, session) {

  source("R/2_MainFunctionCall.R")
	source("R/3a_HelperFunctions_ModelFitting.R")
	source("R/3b_HelperFunctions_ReportCreation.R")


# Think it needs these here for the server deployment
	library("ggplot2")
	library("DT")
	library("markdown")
	library("rmarkdown")
	
	library("shiny")
	library("shinydashboard")
	library("shinyjqui")
	library("shinyFiles")
	
	
	
	volumes.use <- getVolumes()
	shinyDirChoose(input,"repdir",roots=getVolumes())
	reports.path.use <- reactive(input$repdir)
	output$reports.path.use <- renderPrint({   parseDirPath(roots=volumes.use, selection =reports.path.use())  })

		

	
	#############################
	# have this in the launchForecastR() function in the original structure
	# but think it needs to be here for the server deployment
	# read in all ".R" files and ".r" files in /R, and all files with "_functions.r" from the subfolders"
# -------------------

fun.path <- "R"

for(dir.use in list.dirs(path=fun.path,full.names = TRUE, recursive = TRUE)){
	print("------------------")
	print(dir.use)
	
	if(dir.use == fun.path){pattern.list <- c("*[.]R$","*[.]r$") } 
	if(dir.use != fun.path){pattern.list <- c("_functions.R","_functions.r") } 	

	for(pattern.use in pattern.list){
		fn.file.list <- list.files(path=dir.use,pattern=pattern.use) # get all .R files 
		#print(fn.file.list)
		print("-------")
		for(file.source in fn.file.list){
			print(paste("Sourcing: ",file.source))
			source(paste(dir.use,file.source,sep="/"))
			} # end looping through files
		} # end looping through patterns
	} # end looping through folders
	
	
	
	
		
	



# temporary kludge -> see comments in ui.R
#ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")
ages.menu.list <- c("all","Age 3","Age 4","Age 5","Age 6")

  # Reactive expression to create data frame of all input values ----
  fc.settings <- reactive({

     data.frame(
      Name = c("boots.method",
			   "set.seed",
               "index.year",
			   "B",
               "boxcoxtransform",
			   "Retro-MRE",
			   "Retro-MAE",
			   "Retro-MPE",
			   "Retro-MAPE",
			   "Retro-MASE",
			   "Retro-RMSE"
			   ),
      Value = as.character(c(input$boots.method,
                             input$set.seed,
							 input$index.year ,
                             input$B,
                             input$boxcoxtransform,
							 input$retromeasureMRE ,
							 input$retromeasureMAE,
							 input$retromeasureMPE ,
							 input$retromeasureMAPE ,
							 input$retromeasureMASE,
							 input$retromeasureRMSE
							 )),
      stringsAsFactors = FALSE)

  })



	# Read in user-selected input file
    data.file <- reactive({
		inFile <- input$file.name.2
		if(is.null(inFile)){ data.use <- matrix(NA,ncol=2,nrow=5)}
		if(!is.null(inFile)){ 
				
			data.file.tmp <- read.csv(inFile$datapath, stringsAsFactors=FALSE)  
			
					
			# doing this here for now, but it's a kludge -> see https://github.com/avelez-espino/forecastR_phase4/issues/39			
			settings.cols <- c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")
			settings.tmp <- data.file.tmp[,settings.cols]
			data.use <- data.file.tmp[,!(dimnames(data.file.tmp)[[2]] %in% settings.cols)]
			
			yrs.window <- min(data.use$Run_Year) : max(data.use$Run_Year) # need this for all the other tabs -> just keep all the records
			if(input$MainTab == "precheck"){yrs.window <- input$yr.range.precheck[1]:input$yr.range.precheck[2]}
			if(input$MainTab == "compare"){yrs.window <- input$yr.range.compare[1]:input$yr.range.compare[2]}			
			if(input$MainTab == "report.withage"){yrs.window <- input$yr.range.report.withage[1]:input$yr.range.report.withage[2]}
			if(input$MainTab == "report.withoutage"){yrs.window <- input$yr.range.report.withoutage[1]:input$yr.range.report.withoutage[2]}
		
						
			records.keep <-  data.use$Run_Year %in% yrs.window
			data.use <- data.use[records.keep,]
			data.use <- cbind(settings.tmp[1:dim(data.use)[1],],data.use)
			}
		
	return(data.use)
			
	})


	 settings.basic <- reactive({
			data.file.tmp <- data.file()
	
			settings.list <- list(Stock = data.file.tmp[1,"Stock_Name"],
								Species = data.file.tmp[1,"Stock_Species"],
								Abundance = data.file.tmp[1,"Stock_Abundance"],
								FCYear = data.file.tmp[1,"Forecasting_Year"]
								)
					
			return(settings.list)
	
	
			})
	
	
######################################################################  
# MODEL PRE_CHECK PIECES ("Explore" Tab)	
######################################################################  

# SHOULD EXTRACT THE data.file -> prepData as a reactive judge

	precheck.settings  <- reactive({
	
					# extract settings (should streamline)
				if(input$model.use.precheck  %in% c("TimeSeriesArima","TimeSeriesExpSmooth")){settings.use <- list(BoxCox= input$precheck.boxcox)}
				if(input$model.use.precheck  %in% c("Naive")){settings.use <- list(avg.yrs= input$precheck.avgyrs)}
				if(input$model.use.precheck  %in% c("SibRegKalman")){settings.use <- list(int.avg= input$precheck.intavg)}
				if(input$model.use.precheck  %in% c( "SibRegSimple","SibRegLogPower")){settings.use <- NULL}
				
				return(settings.use)
				
					})
	
	precheck.modelfit  <- reactive({
				data.file.tmp <- data.file()	
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				settings.use <- precheck.settings()

				fit.obj <- fitModel(model= input$model.use.precheck, data = sample.dat$data, settings = settings.use ,tracing=FALSE)

				return(fit.obj)
			})
	
	
    precheck.fc <- reactive({
				data.file.tmp <- data.file()	
				settings.basic.use <- settings.basic()
				fit.obj <- precheck.modelfit()
				settings.use <- precheck.settings()
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")	
				fc.obj <- calcFC(fit.obj= fit.obj,data = sample.dat$data, fc.yr= settings.basic.use$FCYear,  settings = settings.use, tracing=FALSE)
				return(fc.obj)
				
				})

   

	output$precheck.plot.fitandfc <- renderPlot({
				
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "fitted_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   	output$precheck.plot.resid_ts <- renderPlot({
					
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   	output$precheck.plot.resid_hist<- renderPlot({
					
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_hist",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   
   	output$precheck.plot.resid_qq <- renderPlot({
				
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_qq",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
    	output$precheck.plot.boots.sample <- renderPlot({
				data.file.tmp <- data.file()	
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				age.in <- input$precheck.ageclass
				boot.type.in <- input$boot.type.precheck
				plotBootSeries(sample.dat$data, boot.type = boot.type.in, age.which=age.in)
				 
				})  

   
   
		output$precheck.plot.intervals <- renderPlot({
   				data.file.tmp <- data.file()	
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				boot.type.in <- input$boot.type.precheck
				boot.n.in <- input$boot.n.precheck			
				settings.use <- precheck.settings()
				settings.basic.use <- settings.basic()
				doBoot(data= sample.dat, args.fitmodel= list(model= input$model.use.precheck, settings = settings.use),
					args.calcfc = list(fc.yr= settings.basic.use$FCYear,  settings = settings.use),
					args.boot = list(boot.type=boot.type.in, boot.n=boot.n.in, plot.diagnostics=FALSE),
					full.out = FALSE, plot.out=TRUE)

							})  
   
     
  output$"downloadPreCheckRep" <- downloadHandler(
    filename = function() {
      paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck,"_",  gsub(" ","",input$precheck.ageclass),"_",  Sys.Date(), ".pdf", sep="")
    },
    content = function(file) {
		
	pdf(file,onefile=TRUE,width=11,height=8.5)  

		fit.in <- precheck.modelfit()
		fc.in <-  precheck.fc()
		age.in <- input$precheck.ageclass
		
		data.file.tmp <- data.file()	
		sample.dat <-  prepData(data.file.tmp,out.labels="v2")
		boot.type.in <- input$boot.type.precheck
		boot.n.in <- input$boot.n.precheck			
		settings.use <- precheck.settings()
		settings.basic.use <- settings.basic()
		
		doBoot(data= sample.dat, args.fitmodel= list(model= input$model.use.precheck, settings = settings.use),
					args.calcfc = list(fc.yr= settings.basic.use$FCYear,  settings = settings.use),
					args.boot = list(boot.type=boot.type.in, boot.n=boot.n.in, plot.diagnostics=FALSE),
					full.out = FALSE, plot.out=TRUE)
					
		
					
		plotModelFit(fit.in, options= list(plot.which = "precheck.report",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
		
		data.file.tmp <- data.file()	
		sample.dat <-  prepData(data.file.tmp,out.labels="v2")
		boot.type.in <- input$boot.type.precheck
		plotBootSeries(sample.dat$data, boot.type = boot.type.in, age.which=age.in)
		
		
		
		dev.off()
    }
  )
   
   
   
######################################################################  
# MODEL COMPARISON PIECES ("Compare" Tab)	
######################################################################  
   
	  output$compare.ageclass <- renderText({  input$compare.ageclass })
   
     multifc.list.gui <- reactive({
				
				multifc.list <- NULL
				
				if(input$m1.use){multifc.list[[input$m1.name]] <-list(model.type= input$m1.modeltype, settings=extractSettings(input$m1.modeltype,input$m1.avgyrs,input$m1.boxcox,input$m1.kfyear))	}
				if(input$m2.use){multifc.list[[input$m2.name]] <-list(model.type= input$m2.modeltype, settings=extractSettings(input$m2.modeltype,input$m2.avgyrs,input$m2.boxcox,input$m2.kfyear))	}
				if(input$m3.use){multifc.list[[input$m3.name]] <-list(model.type= input$m3.modeltype, settings=extractSettings(input$m3.modeltype,input$m3.avgyrs,input$m3.boxcox,input$m3.kfyear))	}
				if(input$m4.use){multifc.list[[input$m4.name]] <-list(model.type= input$m4.modeltype, settings=extractSettings(input$m4.modeltype,input$m4.avgyrs,input$m4.boxcox,input$m4.kfyear))	}
				if(input$m4.use){multifc.list[[input$m5.name]] <-list(model.type= input$m5.modeltype, settings=extractSettings(input$m5.modeltype,input$m5.avgyrs,input$m5.boxcox,input$m5.kfyear))	}
				if(input$m6.use){multifc.list[[input$m6.name]] <-list(model.type= input$m6.modeltype, settings=extractSettings(input$m6.modeltype,input$m6.avgyrs,input$m6.boxcox,input$m6.kfyear))	}
				if(input$m7.use){multifc.list[[input$m7.name]] <-list(model.type= input$m7.modeltype, settings=extractSettings(input$m7.modeltype,input$m7.avgyrs,input$m7.boxcox,input$m7.kfyear))	}
				if(input$m8.use){multifc.list[[input$m8.name]] <-list(model.type= input$m8.modeltype, settings=extractSettings(input$m8.modeltype,input$m8.avgyrs,input$m8.boxcox,input$m8.kfyear))	}
				if(input$m9.use){multifc.list[[input$m9.name]] <-list(model.type= input$m9.modeltype, settings=extractSettings(input$m9.modeltype,input$m9.avgyrs,input$m9.boxcox,input$m9.kfyear))	}
				if(input$m10.use){multifc.list[[input$m10.name]] <-list(model.type= input$m10.modeltype, settings=extractSettings(input$m10.modeltype,input$m10.avgyrs,input$m10.boxcox,input$m10.kfyear))	}
									
				return(multifc.list)
				
				})
     
   
		compare.multifit  <- reactive({
				data.file.tmp <- data.file()
      
				settings.use <- multifc.list.gui()
				
				print("starting multuFC")
				multiresults.retro <- multiFC(data.file=data.file.tmp,settings.list=settings.use,
								do.retro=TRUE,do.boot=FALSE,out.type="short",
								retro.min.yrs=15,tracing=FALSE)
   
				print("finished multiFC")
   
				print(multiresults.retro)
				return(multiresults.retro)
				
				
				})
   
   
    
  
  
		compare.ptfc.table <- reactive({
					multifit.out <- compare.multifit() 
					multi.ptfc <- round(multifit.out[["table.ptfc"]])
					model.names <- dimnames(multi.ptfc )[[1]]
					multi.ptfc <- sapply(multi.ptfc , FUN=function(x) prettyNum(x, big.mark=","))
										
					dimnames(multi.ptfc )[[1]] <- model.names
					return(multi.ptfc)
					})
   
#		output$table.multi.ptfc  <- renderTable(
#				compare.ptfc.table(), rownames= TRUE, digits=0 , stripes = TRUE, hover = TRUE
#				)   

# obsolete, because using version with rank added in below   
#     output$table.multi.ptfc <- DT::renderDataTable(
#	 				DT::datatable(compare.ptfc.table(), options = list(paging = FALSE))
#					) 
   
     	output$compare.ptfc <- renderPlot({
				
					multifit.out <- compare.multifit() 
					rank.table <- compare.ranking.table()
					
					if(input$compare.plotsort == "AvgRank") {order.idx  <- order(rank.table[,"rank.avg"])}
					if(input$compare.plotsort == "Forecast") {order.idx  <- order(multifit.out[["table.ptfc"]][,input$compare.ageclass])}
					if(input$compare.plotsort == "None") {order.idx  <- 1: dim(multifit.out[["table.ptfc"]])[1] }
					
					
					multi.ptfc <- multifit.out[["table.ptfc"]][order.idx,]
									
					model.names <- paste0(dimnames(multi.ptfc )[[1]]," (",round(rank.table[order.idx,"rank.avg"],1),")")
									 
					
					n.models <- length(model.names)
					vec.plot <- multi.ptfc[,input$compare.ageclass]
					
					par(mai=c(1,2.5,1,1))
					plot(vec.plot , n.models:1, axes=FALSE,xlim = c(0,max(vec.plot)), xlab="Forecast",ylab="",
							pch=19,type="p",cex=1.5,col="red",cex.lab=1.4,main=input$compare.ageclass,col.main="darkblue")
					abline(h=1:n.models,col="lightgrey")
					points(vec.plot , n.models:1, pch=19,type="p",cex=1.5,col="red")
					text(vec.plot , (n.models:1)+0.2, labels=prettyNum(round(vec.plot),big.mark=","),cex=1,col="red")
					axis(2,at=n.models:1,labels=model.names,las=2,cex.axis=1.2)
	
			})
   
   
		compare.rankingpm <- reactive({input$compare.pm})
		   
   
		compare.retropm.array<- reactive({
					multifit.out <- compare.multifit() 
					multi.retropm <- multifit.out[["retro.pm"]][[input$retrotype.compare]]
					return(multi.retropm)
					})

		compare.retropm.table<- reactive({
					multi.retro.obj <- compare.retropm.array()
					retropm.table.out <- multi.retro.obj[,,input$compare.ageclass]
					return(retropm.table.out)
					})
					
		

		compare.ranking.obj <- reactive({
					ranking.pm.use <- compare.rankingpm()
					multi.retro.obj <- compare.retropm.array()
					
					ranking.out <- rankModels(dat = multi.retro.obj,columnToRank=ranking.pm.use, relative.bol=input$rel.bol)
					#print(ranking.out)					
					# OLD VERSION
					#ranking.out <- getRanks(as.data.frame(multi.retropm), columnToRank = ranking.pm.use) 
					#ranking.out <- ranking.out[ , grep("rank",dimnames(ranking.out)[[2]])]   # extract only the rank columns
					# can't sort here, b/c will screw up the merge below!!!
					#ranking.out <- ranking.out[order(ranking.out$average.rank),]
					
					return(ranking.out)
					})

							
		compare.ranking.table <- reactive({
					ranking.obj <- compare.ranking.obj() 
					ranking.table.out  <- ranking.obj[[input$compare.ageclass]]
					ranking.table.out <- ranking.table.out[ , grep("rank",dimnames(ranking.table.out)[[2]])] # extract only the rank columns  
					ranking.table.out <- round(ranking.table.out,2)
					return(ranking.table.out)
					})

		compare.cumul.ranking.table <- reactive({
					ranking.obj <- compare.ranking.obj() 
					ranking.table.out  <- ranking.obj$cumulativerankSorted
					ranking.table.out <- ranking.table.out[ , grep("rank",dimnames(ranking.table.out)[[2]])] # extract only the rank columns  
					ranking.table.out <- round(ranking.table.out,2)
					return(ranking.table.out)
					})

					
		compare.bestmodel.table <- reactive({
		
					multifit.out <- compare.multifit() 
					pt.fc.in  <- round(multifit.out[["table.ptfc"]])
					ranking.obj <- compare.ranking.obj() 
					ranking.bestmodel.out  <- ranking.obj$bestmodel

					summary.table <- tableForecastRanking(pt.fc.in = pt.fc.in  ,
										bestmodel.in = ranking.bestmodel.out )

					return(summary.table )
					})

					
		compare.ptfc.table.merged <- reactive({		
					fc.table <-  compare.ptfc.table()
					rank.table <- compare.ranking.table()
					merged.table <- cbind(AvgRank = round(rank.table[,"rank.avg"],2),fc.table)
					return(merged.table)
					})					

					
     output$table.multi.ptfc <- DT::renderDataTable(
	 				DT::datatable(compare.ptfc.table.merged(), options = list(paging = FALSE))
					) 
					
					
     output$table.retropm <- DT::renderDataTable(
	 				DT::datatable(compare.retropm.table(), caption = input$compare.ageclass , options = list(paging = FALSE))
					) 
				
	
				
      output$table.ranking <- DT::renderDataTable(
	 				DT::datatable(compare.ranking.table(), caption = input$compare.ageclass , options = list(paging = FALSE))
					)   
   
      output$table.cumul.ranking <- DT::renderDataTable(
	 				DT::datatable(compare.cumul.ranking.table(), caption = "Cumulative Ranks" , options = list(paging = FALSE))
					)   
    
   
   
       output$table.bestmodels <- DT::renderDataTable(
	 				DT::datatable(compare.bestmodel.table(), rownames=FALSE, options = list(paging = FALSE))
					)    
   
   
   
   
   
   
   
   
	output$downloadComparisonRepWord <- downloadHandler(
	# using template from https://shiny.rstudio.com/articles/generating-reports.html
			filename =   paste0("WordTest",Sys.Date(),".doc"),
			content = function(file) {
	        # Copy the report file to a temporary directory before processing it, in
			# case we don't have write permissions to the current working dir (which
			# can happen when deployed).
        tempReport <- file.path(tempdir(), "ShortCompRep.Rmd")
        file.copy("Markdown/ShortCompRep.Rmd", tempReport, overwrite = TRUE)

		settings.basic.use <- settings.basic()
        params <- c(settings.basic.use,
					list(Table_Multi_Pt_FC = compare.ptfc.table.merged()), # formatted table 1
					list(multifit.out = compare.multifit() )   # raw outputs in a list object
					)
		
        # Knit the document, passing in the `params` list, and eval it in a
        # child of the global environment (this isolates the code in the document
        # from the code in this app).
        rmarkdown::render(tempReport, output_file = file,
          params = params,
          envir = new.env(parent = globalenv())
			) # end render()
      } # end content
    ) # end downloadHandler()

 
   
   
   
   
   
   
	# not working for some reason
   	#	compare.fittedpm.table <- reactive({
	#				multifit.out <- compare.multifit() 
	#				multi.fittedpm <- multifit.out[["retro.pm"]][["fitted.pm.last"]][,,input$compare.ageclass]
	#				return(multi.fittedpm)
	#				})
   
	#	output$table.fittedpm <- renderTable(
	#			compare.fittedpm.table(), rownames= TRUE, stripes = TRUE, hover = TRUE
	#			)   
   
   
   
######################################################################  
# OTHER STUFF
######################################################################   
   
	output$inputheader.table <- renderTable({ data.file() })  # masking issue with package DT? shiny::renderTable doesn't fix it



	output$settings.table <- renderTable({   fc.settings() })
	#output$settings.table <- renderText({   fc.settings()})



	# create precheck summary report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected
    # THIS IS OBSOLETE
	# Doing this above with  output$"downloadPreCheckRep" <- downloadHandler(
  	#observeEvent(input$create.precheck.summary.withoutage, {
	#				print("-----------------------")

		# FOR NOW, THIS REPLICATES ALL THE STEPS FROM THE PRE-CHECK PLOTS ABOVE
	#	data.file.tmp <- data.file()	
		
		
	
	#	if(input$model.use.precheck.withage=="n1.model"){
					#pdf("OUTPUT/Naive1_WithAge_Precheck.pdf",onefile=TRUE,width=8.5,height=11) # Need to make this dynamic to include file name 
					
					#data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
					#data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
					#n1.fit.tmp <- naiveone.model(data.input.tmp)
					#n1.pointfc.tmp <- point.forecast.naiveone(data.input.tmp, n1.fit.tmp)

					
					# these 2 not showing up in output. Why? ggplot issue?
					#plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					#plot.fitted.naiveone(n1.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)					
							
					#plot(1:5,1:5) # this one shows up
	
					#for(i in 1:length(data.input.tmp)){
					#	barplot.forecasted.values.individual.ages.naiveone(n1.fit.tmp, n1.pointfc.tmp, i,abd=data.preprocess.tmp$specs$stockabundance)
					#	}
						

						
						
					#dev.off()
	#				}
	
			# fitted plot 1 for other models to be added


	#						})


	
	
	# create report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected
    # THIS IS THE ORIGINAL VERSION. IT WORKS WHEN LAUNCHING THE GUI LOCALLY
	# Have 2 options for server-based GUI
	#  		1) find a way to input a local path then write to that
	# 		2) use the downloadHandler approach like for the the pre-check pdf
	# -> not sure if option can work with ReportRs, so trying option 1 first
	
	
	
	# this version opens, but doesn't seem to link to anythin
	# shinyDirChoose(input, id= "rep.dir", roots=c(wd='.'), filetypes=c("docx"))   # or roots = c(home = '~')
	# rep.dir.use <- reactive(input$dir)
	# print(rep.dir.use)
	
	# not working either
	#volumes <- c("R Installation" = R.home())	
	#shinyDirChoose(input, id = "rep.dir", roots = volumes, session = session, restrictions = system.file(package = "base"))
	
	# trying it this way: https://stackoverflow.com/questions/46281137/reporters-package-to-download-docx-report-from-shiny
	
	
  	#observeEvent(input$CreateReportWithAge, {
	#			    print("-----------------------")

					
	#				rep.path <- parseDirPath(roots=volumes.use, selection =reports.path.use())
	#				print(rep.path)
					
					# temporary here until fixed GUI such that "With Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)
	#				print(input$file.name.2)
					# Why is this necessary?
	#				input.use <- list(model.type="WithAge",
	#								file.name= input$file.name.2$datapath,
	#								boots.method = input$boots.method,
	#								set.seed = input$set.seed,
	#								index.year = input$index.year ,
	#								B = input$B,
	#								boxcoxtransform =input$boxcoxtransform,
	#								model.use.withage = input$model.use.withage
	#								)

	#				print("-----------------------")
	#				print(input.use)
	#				print("-----------------------")

					#pdf("Test_Withage.pdf",onefile=TRUE,width=8.5,height=11)
	#				forecastR_Main(input.obj=input.use,
	#						path.Rfolder="R",
	#						path.reports=  rep.path ,  #"ForecastRReports",   #reports.path.use,
	#						path.template="../extdata/TemplateReport")
					
					#dev.off (not needed, b/c device turned off before at some point
	#						})

	
	
	
	output$"CreateReportWithAge" <- downloadHandler(
    filename =  "file.docx", 
		# dynamic name
	#function() {
    #  paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck.withage,"_", Sys.Date(), ".pdf", sep="")
    #},
    
	content = function(file) {
		

		input.use <- list(model.type="WithAge",
								file.name= input$file.name.2$datapath,
								boots.method = input$boots.method,
								set.seed = input$set.seed,
								index.year = input$index.year ,
								B = input$B,
								boxcoxtransform =input$boxcoxtransform,
								model.use.withage = input$model.use.withage
								)

				forecastR_Main(input.obj=input.use,
						path.Rfolder="R",
						path.reports=  "N1_Report_Test" ,  # just send it to the filename, and the file gets passed to downloadHandler
						path.template="TemplateReport")
		       # note: this function call includes:
			   #    - call to startReport(), which includes doc <<- docx(template = template, empty_template=TRUE)
			   #    - sources the specified Report.R script (e.g. "n1/Report - Naive One.R")
			   #    - call to endReport(), which includes  writeDoc(doc, file = docx.file)
		
		
		
		
    }
  )









	
							
							
							
							

	# create report - Without Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected

  	observeEvent(input$create.report.withoutage, {
					print("-----------------------")


					
					# temporary here until fixed GUI such that "Without Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)


					#print(file.name.2)

					# Why is this necessary?
					input.use <- list(model.type="WithoutAge",
									file.name= input$file.name.2,
									boots.method = input$boots.method,
									set.seed = input$set.seed,
									index.year = input$index.year ,
									B = input$B,
									boxcoxtransform =input$boxcoxtransform,
									model.use.withoutage = input$model.use.withage
									)



					print("-----------------------")
					print("input.use")
					print(input.use)
					print("-----------------------")

					#pdf("Test_Withoutage.pdf", onefile=TRUE,width=8.5,height=11)

					forecastR_Main(input.obj=input.use)
					#dev.off (not needed, b/c device turned off before at some point
							})











}

