capitalize <- function (string) {
	capped <- grep("^[^A-Z]*$", string, perl = TRUE)
	substr(string[capped], 1, 1) <- toupper(substr(string[capped],1, 1))
	return(string)
}


capwords <- function(s, strict = FALSE) {
	cap <- function(s) paste(toupper(substring(s, 1, 1)),
													 {s <- substring(s, 2); if(strict) tolower(s) else s},
													 sep = "", collapse = " " )
	sapply(strsplit(s, split = " "), cap, USE.NAMES = !is.null(names(s)))
}


isEmpty <- function(x) {return(identical(x, numeric(0)))}

is.even <- function(x) {x %% 2 == 0}

is.odd <- function(x) {x %% 2 != 0}


is_installed <- function(mypkg){ is.element(mypkg, installed.packages()[,1])}







#' @title Package load or install and load
#'
#' @description For installing and/or loading R packages
#'
#' @param package_names Character string of length one or more. The package name.
#'
#' @return Nothing returned.
#' @export
#'
#' @examples
load_or_install <- function(package_names){
	# function to load/install required packages
	for(package_name in package_names){
		if(!is_installed(package_name)){install.packages(package_name,repos="http://lib.stat.cmu.edu/R/CRAN")}
		library(package_name,character.only=TRUE,quietly=TRUE,verbose=FALSE)
	}
}#END load_or_install


panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor, ...){
	usr <- par("usr"); on.exit(par(usr))
	par(usr = c(0, 1, 0, 1))
	r <- abs(cor(x, y))
	txt <- format(c(r, 0.123456789), digits = digits)[1]
	txt <- paste0(prefix, txt)
	if(missing(cex.cor)) cex.cor <- 0.6/strwidth(txt)   # cex.cor <- 0.8/strwidth(txt)
	text(0.5, 0.5, txt, cex = cex.cor * r)
}#END panel.cor



#' @title Package load or install and load
#'
#' @description For installing and/or loading R packages
#'
#' @param p Character string of length one. The package name.
#'
#' @return Nothing returned.
#' @export
#'
#' @examples
usePackage <- function(p) {
	if(!is.element(p, installed.packages()[,1]))
		install.packages(p, dep = TRUE)
	require(p, character.only = TRUE)
}#END usePackage




wrapper <- function(x, ...){
	paste(strwrap(x, width=50, ...), collapse = "\n")
}
