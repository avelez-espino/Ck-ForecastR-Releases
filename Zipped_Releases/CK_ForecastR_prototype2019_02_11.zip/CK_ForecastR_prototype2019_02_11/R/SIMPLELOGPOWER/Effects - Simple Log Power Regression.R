usePackage("effects")
source("Effects - Simple Log Power Regression_functions.R")

## test
## my.effect.plot.multiple.predictor.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower, stockabundance, i=1)


# test
## my.effect.plot.multiple.predictor.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower, stockabundance, i=3)

## test
## bla <- my.effect.plot.multiple.predictor.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower, stockabundance, i=3)
## plot(bla)

## test
## bla <- my.effect.plot.multiple.predictor.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower, stockabundance, i=4)
## plot(bla)

