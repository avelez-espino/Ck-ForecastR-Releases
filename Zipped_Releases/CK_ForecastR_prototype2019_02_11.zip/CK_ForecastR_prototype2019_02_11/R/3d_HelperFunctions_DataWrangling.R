# This script contains functions for handling data

# Contents -----
# converter.fun: convert old data files into new generalized format (same for withage and withoutage


# ----------------------------------------------------------------
# FUNCTION TO CONVERT DATA FILES BETWEEN OLD FORMAT AND NEW FORMAT

converter.fun <- function(file.use, out.filename=NULL){
# old format: different file structure for "withage" and "withoutage"
# new format: same file structure
# out.filename is either NULL or path and filename like "OUTPUT/CovertedFile.csv"
# NOTE: If CV columns are present, they are dropped in the conversions
# old files without age: just add Age_Class column full of "Total" and Brood_Year column full of NA
# old files with age: add a row with total values and NA for Brood_Year

# detect file type
if("Age_Class" %in% dimnames(file.use)[[2]]){
	if(!("Total" %in% file.use[,"Age_Class"])){file.type <- "Old_WithAge" }
	if("Total" %in% file.use[,"Age_Class"]){file.type <- "New"}
	}
if(!("Age_Class" %in% dimnames(file.use)[[2]])){
	file.type <- "Old_WithoutAge"
	}



#-----------------------------
if(file.type=="Old_WithoutAge"){

	file.out <- file.use

	in.labels <-  c("Average_Escapement", "Average_Terminal_Run","Average_Production")

	out.labels <- c("Average_Escapement", "Average_Terminal_Run","Average_Production")


	cols.idx <- dimnames(file.out)[[2]] %in% in.labels
      labels.idx <- in.labels %in% dimnames(file.out)[[2]]

	dimnames(file.out)[[2]][cols.idx] <- out.labels[labels.idx]

	# need to fix column order of output
	file.out <- cbind(file.out,Brood_Year = NA, Age_Class = "Total")
	file.out <- file.out[,c("Stock_Name","Stock_Abundance","Stock_Species","Forecasting_Year",
				"Run_Year","Brood_Year","Age_Class","Average_Escapement","Average_Terminal_Run","Average_Production")]


} # end if "Old_WithoutAge"


#-----------------------------
if(file.type=="Old_WithAge"){


age.classes <- sort(unique(file.use[,"Age_Class"]))


in.labels <- c("Average_Escapement", "Average_Terminal_Run", "Average_Production")


n.run.yrs <- length(unique(file.use[,"Run_Year"]))
df.vec <- rep(NA,n.run.yrs)

sums.df <- data.frame(Run_Year=df.vec,Brood_Year=df.vec,Age_Class=df.vec,
			Average_Escapement=df.vec,Average_Terminal_Run=df.vec,Average_Production=df.vec)

yrs.vec <- aggregate(file.use[,var.use],by=list(Run_Year = file.use[,"Run_Year"]),FUN="sum")[,1]

sums.df[,"Run_Year"] <- yrs.vec
sums.df[,"Brood_Year"] <- NA
sums.df[,"Age_Class"] <- "Total"

for(var.use in in.labels){
	sums.vec <- aggregate(file.use[,var.use],by=list(Run_Year = file.use[,"Run_Year"]),FUN="sum")[,2]
	counts.vec <- aggregate(file.use[,var.use],by=list(Run_Year = file.use[,"Run_Year"]),FUN="length")[,2]
	num.ages <- length(unique(file.use[,"Age_Class"]))
	keep.idx  <- counts.vec == num.ages
	sums.vec[!keep.idx] <- NA
	sums.df[,var.use] <- sums.vec
	}

file.out <- sums.df
file.out <- cbind(file.use[2:(n.run.yrs+1),c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")],file.out)
file.out <- rbind(file.use,file.out)


} # end if "Old_WithAge"


#-----------------------------
if(file.type=="New"){

# keep the file as is (for now, conversion works only one way!)
file.out <- file.use

} # end if "New"


#-----------------------------
# write the output file, if a path is given
if(!is.null(out.filename)){write.csv(file.out,file=out.filename,row.names=FALSE)}

#--
return(file.out)

} # end converter.fun

