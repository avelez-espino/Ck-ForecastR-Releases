source("R/SIMPLESIBREG/Bias Coefficient Computation - Simple Sibling Regression_functions.R")

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - youngest age
#
##########################################################################################

windows()

SIMPLESIBREG$results <- SIMPLESIBREG$best.rmse.youngest.age

SIMPLESIBREG$bias.coefficient.afe.youngest.age.retro.simplesib(SIMPLESIBREG$results, SIMPLESIBREG$stockabundance, SIMPLESIBREG$index.year)

SIMPLESIBREG$bias.coeff.afe.youngest.age.retro.simplesib


## results$$retro$resjoin

## rm(results)

SIMPLESIBREG$results <- NULL 

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - older ages
#
##########################################################################################

SIMPLESIBREG$fits <- SIMPLESIBREG$results_best_fitting_model_for_each_age_class  ## fits
SIMPLESIBREG$results <- SIMPLESIBREG$individual.ages.retro.predictive.performance.simple.sibling.regression.youngest(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, SIMPLESIBREG$index.year)  # results


windows()
SIMPLESIBREG$bias.coefficients.afe.older.ages.retro.simplesib(SIMPLESIBREG$fits,
                                                     SIMPLESIBREG$results,
                                                     SIMPLESIBREG$stockabundance)

## rm(SIMPLESIBREG$fits)
## rm(SIMPLESIBREG$results)

SIMPLESIBREG$fits <- NULL 
SIMPLESIBREG$results <- NULL 


##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################

windows()

SIMPLESIBREG$results <- SIMPLESIBREG$best.rmse.youngest.age

SIMPLESIBREG$bias.coefficient.afe.total.age.retro.simplesib(SIMPLESIBREG$results, SIMPLESIBREG$stockabundance)

SIMPLESIBREG$bias.coeff.afe.total.age.retro.simplesib



##########################################################################################
#
# Time series plot of forecasted vs. actual abundance (older ages, simplesib)
#
##########################################################################################


#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values of abundance (individual ages, avgfive)
#-----------------------------------------------------------------------------------------

SIMPLESIBREG$results <- SIMPLESIBREG$best.rmse.youngest.age
SIMPLESIBREG$timeseries.plot.results.afe.individual.ages.retro.simplesib(SIMPLESIBREG$results,
                                                             SIMPLESIBREG$stockabundance)

## rm(results)

SIMPLESIBREG$results <- NULL 

##########################################################################################
#
# Time series plot of forecasted vs. actual abundance (total age, simplesib)
#
##########################################################################################

SIMPLESIBREG$results <- SIMPLESIBREG$best.rmse.youngest.age

SIMPLESIBREG$timeseries.plot.results.afe.total.age.retro.simplesib(SIMPLESIBREG$results, SIMPLESIBREG$stockabundance)

## rm(results)

SIMPLESIBREG$results <- NULL 

