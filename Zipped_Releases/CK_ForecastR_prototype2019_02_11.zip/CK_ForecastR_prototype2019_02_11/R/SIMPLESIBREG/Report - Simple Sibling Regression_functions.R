
best.rmse.results.youngest.age <- function(rmse.results.youngest.age.avgfive.plus.simple.sibling.regression, rmse.results.youngest.age.arima.plus.simple.sibling.regression, rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression){
 
   rmse.total.age.avgfive <- rmse.results.youngest.age.avgfive.plus.simple.sibling.regression$rmse.total
   rmse.total.age.arima  <- rmse.results.youngest.age.arima.plus.simple.sibling.regression$rmse.total
   rmse.total.age.expsmooth  <- rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression$rmse.total                                           
 
   
   rmse.total.age <- c(rmse.total.age.avgfive, rmse.total.age.arima, rmse.total.age.expsmooth)
   
   min.rmse.total.age <- min(rmse.total.age)
           
   index.min.rmse.total.age <- which(rmse.total.age %in% sort(unique(rmse.total.age))[1])                    
   index.min.rmse.total.age <- as.numeric(index.min.rmse.total.age)
 
   if (index.min.rmse.total.age==1){
       sibreg.youngest.age.method <- "naive forecasting (i.e., average of previous five years)"
       output <- rmse.results.youngest.age.avgfive.plus.simple.sibling.regression
   } else if (index.min.rmse.total.age==2) {
       sibreg.youngest.age.method <- "ARIMA forecasting"
       output <- rmse.results.youngest.age.arima.plus.simple.sibling.regression
   } else if (index.min.rmse.total.age==3) {
       sibreg.youngest.age.method <- "exponential smoothing forecasting"
       output <- rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression
   }
   
   myoutput <- list(method = sibreg.youngest.age.method, 
                    retro = output, 
                    min.rmse.total.age = min.rmse.total.age,
                    index.min.rmse.total.age = index.min.rmse.total.age)
   
}#END best.rmse.results.youngest.age

table_interval_forecasts <- function(results_best_fitting_model_for_each_age_class, PI.individual.ages.simple.sibling.regression.no.comma, forecastingyear, stockabundance){
	# this function deals only with forecasts produced by best sibling regression models for older ages

    point_forecast_results <-
      SIMPLESIBREG$point.forecast.best.fitting.model.for.each.age.class(results_best_fitting_model_for_each_age_class,
                                                           forecastingyear, SIMPLESIBREG$datafile_variables)

    interval_forecast_results <- PI.individual.ages.simple.sibling.regression.no.comma

    mytable <- matrix(NA, nrow=length(point_forecast_results), ncol=5)  # add a 5th column for interval forecast
    mytable <- as.data.frame(mytable)
    names(mytable)[-1] <- c("Best Model","Forecasting Year","Point Forecast","Interval Forecast")
    names(mytable)[1] <- paste(stockabundance)
    mytable

    for (i in 1:length(point_forecast_results)){

         mytable[i,1] <- names(point_forecast_results)[i]
         mytable[i,"Best Model"] <- point_forecast_results[[i]]$Model
         mytable[i,"Forecasting Year"] <- forecastingyear
         pfcst <- point_forecast_results[[i]]$PointForecast
         pfcst <- ifelse(pfcst>0,pfcst,0)
         pfcst <- round(pfcst)
         require(scales)
         pfcst <- as.character(comma(pfcst))
         mytable[i,"Point Forecast"] <- pfcst
         mytable[i,"Interval Forecast"] <- paste0(comma(interval_forecast_results[i,"PI.lwr"])," - ",comma(interval_forecast_results[i,"PI.upr"]))

    }

    usePackage("stringr")

    for (i in 1:length(point_forecast_results)){
       mytable[i,1] <- str_replace(mytable[i,1], "_", " ")
    }
    mytable
}#END table_interval_forecasts

empirical.probability.yboot.simple.sibling.regression.total.age <- function(pred.int.total.age.simple.sibling.regression.all.models, total.index, stockabundance){


    if (total.index==1) {   # naive model for youngest age (average of previous 5 years)

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    if (total.index==2) {   # arima model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    if (total.index==3) {   # exponential smoothing model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    ## cumulative probabilities evaluated for the endpoints of equal-sized bins covering the
    ## range of bootstrapped point forecasts

    x <- as.numeric(y.star.boot.stacked)
    usePackage("Hmisc")

    x.hist <- hist(x, breaks=20, plot=FALSE)
    x.hist.breaks <- x.hist$breaks

    my.ecdf <- ecdf(x)

    prob.less <- round(my.ecdf(x.hist.breaks),4)

    prob.greater <- round(1 - my.ecdf(x.hist.breaks),4)

    prob.less.percentage <- round(prob.less*100,2)

    prob.greater.percentage <- round(prob.greater*100,2)
    
    prob.interval.percentage <- c(NA, diff(prob.less.percentage))
    
    prob.interval.percentage <- round(prob.interval.percentage, 2)

    prob.threshold <- x.hist.breaks

    prob.thresholds <- data.frame(prob.threshold = prob.threshold,
                       prob.less.percentage = prob.less.percentage,
                       prob.greater.percentage = prob.greater.percentage, 
                       prob.interval.percentage = prob.interval.percentage)

    prob.thresholds

    ## cumulative probabilities evaluated for the point forecast of total abundance

    prob.less.pfct <- round(my.ecdf(pfct),4)
    prob.greater.pfct <- round(1 - my.ecdf(pfct),4)

    prob.less.percentage.pfct <- round(prob.less.pfct*100,2)

    prob.greater.percentage.pfct <- round(prob.greater.pfct*100,2)

    prob.threshold.pfct <- pfct
    
    prob.interval.percentage.pfct <- NA

    prob.pfct <-  data.frame(prob.threshold = prob.threshold.pfct,
                             prob.less.percentage = prob.less.percentage.pfct,
                             prob.greater.percentage = prob.greater.percentage.pfct, 
                             prob.interval.percentage = prob.interval.percentage.pfct)


    prob.pfct

    probs = list(prob.thresholds=prob.thresholds,
                 prob.point.forecast=prob.pfct)
    probs
}#END empirical.probability.yboot.simple.sibling.regression.total.age

extract.arima <- function(model){

   extract.arima.fit <- model

   sink("arimafit.txt")
   print(extract.arima.fit)
   sink()
   
   out <- readLines("arimafit.txt")
   usePackage("stringr")
   out.pattern <- str_detect(string=out, pattern="ARIMA")
   
   out.coefficients <- str_detect(string=out, pattern="Coefficients")
   flag <- sum(out.coefficients)  # flag = 0 means no Coefficients are reported for ARIMA model for youngest age
                                  # flag = 1 means Coefficients are reported for ARIMA model for youngest age
      
   modelarima <- out[out.pattern==TRUE]
   require(stringr)
   modelarima <- str_trim(modelarima)

   ## flag <- grepl("ARIMA(0,0,0)", modelarima, fixed=TRUE)

   if (flag > 0) { # if Coefficients are reported for ARIMA model for youngest age 
   
      extract.arima.fit.coef.names <- attr(extract.arima.fit$coef,"names")
      extract.arima.fit.coef <- round(extract.arima.fit$coef,4)
      
      if (!isEmpty(extract.arima.fit$var.coef)) {
        
          extract.arima.fit.se <- round(sqrt(diag(extract.arima.fit$var.coef)),4)
        
          ## http://stats.stackexchange.com/questions/8868/how-to-calculate-the-p-value-of-parameters-for-arima-model-in-r

          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.z.statistic <- extract.arima.fit$coef/sqrt(extract.arima.fit$var.coef)
          } else if (length(extract.arima.fit$coef)>1) {
              extract.arima.fit.z.statistic <- extract.arima.fit$coef/sqrt(diag(extract.arima.fit$var.coef))
          }
      
          extract.arima.fit.p.value <- pnorm(abs(extract.arima.fit.z.statistic), lower.tail=FALSE)*2
          extract.arima.fit.p.value <- round(extract.arima.fit.p.value, 4)
        
          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.table <- data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef,
                                            extract.arima.fit.se,
                                            round(extract.arima.fit.z.statistic,4),
                                            extract.arima.fit.p.value)
          } else if (length(extract.arima.fit$coef)>1) {
             extract.arima.fit.table <- cbind.data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef,
                                            extract.arima.fit.se,
                                            round(extract.arima.fit.z.statistic,4),
                                            extract.arima.fit.p.value)
          } # end if else if 

      
          rownames(extract.arima.fit.table) <- extract.arima.fit.coef.names
          colnames(extract.arima.fit.table) <- c("Coefficient","Estimate","Standard Error","Z-statistic","P-value")

          extract.arima.fit.aic <- extract.arima.fit$aic
          extract.arima.fit.bic <-  extract.arima.fit$bic
          extract.arima.fit.aicc <-  extract.arima.fit$aicc

          extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
          extract.arima.fit.loglik <- extract.arima.fit$loglik

          return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.table=extract.arima.fit.table,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))
                     
      
      } # end !isEmpty() 
     
     
      if (isEmpty(extract.arima.fit$var.coef)) {
        
          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.table <- data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef)
          } else if (length(extract.arima.fit$coef)>1) {
             extract.arima.fit.table <- cbind.data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef)
          } # end if else if 

      
          rownames(extract.arima.fit.table) <- extract.arima.fit.coef.names
          colnames(extract.arima.fit.table) <- c("Coefficient","Estimate")

          extract.arima.fit.aic <- extract.arima.fit$aic
          extract.arima.fit.bic <-  extract.arima.fit$bic
          extract.arima.fit.aicc <-  extract.arima.fit$aicc

          extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
          extract.arima.fit.loglik <- extract.arima.fit$loglik

          return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.table=extract.arima.fit.table,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))
        
      } # end isEmpty()


    } # end flag > 0 

    if (flag==0) {  # if Coefficients are NOT reported for ARIMA model for youngest age 
    
           extract.arima.fit.aic <- extract.arima.fit$aic
           extract.arima.fit.bic <-  extract.arima.fit$bic
           extract.arima.fit.aicc <-  extract.arima.fit$aicc

           extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
           extract.arima.fit.loglik <- extract.arima.fit$loglik

           return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))
               
       
    } # end flag = 0 

}#END extract.arima

table_point_forecasts <- function(results_best_fitting_model_for_each_age_class, forecastingyear, stockabundance){
    point_forecast_results <-
      SIMPLESIBREG$point.forecast.best.fitting.model.for.each.age.class(results_best_fitting_model_for_each_age_class,
                                                           forecastingyear, SIMPLESIBREG$datafile_variables)

    mytable <- matrix(NA, nrow=length(point_forecast_results), ncol=4)
    mytable <- as.data.frame(mytable)
    names(mytable)[-1] <- c("Best Model","Forecasting Year","Point Forecast")
    names(mytable)[1] <- paste(stockabundance)
    mytable

    usePackage("scales")

    for (i in 1:length(point_forecast_results)){

         mytable[i,1] <- names(point_forecast_results)[i]
         mytable[i,"Best Model"] <- point_forecast_results[[i]]$Model
         mytable[i,"Forecasting Year"] <- forecastingyear
         pfcst <- point_forecast_results[[i]]$PointForecast
         pfcst <- ifelse(pfcst>0,pfcst,0)
         pfcst <- round(pfcst)
         require(scales)
         pfcst <- as.character(comma(pfcst))
         mytable[i,"Point Forecast"] <- pfcst

    }

    usePackage("stringr")

    for (i in 1:length(point_forecast_results)){
       mytable[i,1] <- str_replace(mytable[i,1], "_", " ")
    }
    mytable
}#END table_point_forecasts


empirical.probability.yboot.simple.sibling.regression.total.age <- function(pred.int.total.age.simple.sibling.regression.all.models, total.index, stockabundance){
	# Empirical Probabilities:  Distribution of Bootstrapped Point Forecasts for Total Age

    if (total.index==1) {   # naive model for youngest age (average of previous 5 years)

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    if (total.index==2) {   # arima model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    if (total.index==3) {   # exponential smoothing model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simple.sibling.regression.all.models$sim[[total.index]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simple.sibling.regression.all.models$p[[total.index]] ## point forecast of total abundance

    }

    ## cumulative probabilities evaluated for the endpoints of equal-sized bins covering the
    ## range of bootstrapped point forecasts

    x <- as.numeric(y.star.boot.stacked)
    usePackage("Hmisc")

    x.hist <- hist(x, breaks=20, plot=FALSE)
    x.hist.breaks <- x.hist$breaks

    my.ecdf <- ecdf(x)

    prob.less <- round(my.ecdf(x.hist.breaks),4)

    prob.greater <- round(1 - my.ecdf(x.hist.breaks),4)

    prob.less.percentage <- round(prob.less*100,2)

    prob.greater.percentage <- round(prob.greater*100,2)
    
    prob.interval.percentage <- c(NA, diff(prob.less.percentage))
    
    prob.interval.percentage <- round(prob.interval.percentage,2)

    prob.threshold <- x.hist.breaks

    prob.thresholds <- data.frame(prob.threshold = prob.threshold,
                       prob.less.percentage = prob.less.percentage,
                       prob.greater.percentage = prob.greater.percentage, 
                       prob.interval.percentage = prob.interval.percentage)

    prob.thresholds

    ## cumulative probabilities evaluated for the point forecast of total abundance

    prob.less.pfct <- round(my.ecdf(pfct),4)
    prob.greater.pfct <- round(1 - my.ecdf(pfct),4)

    prob.less.percentage.pfct <- round(prob.less.pfct*100,2)

    prob.greater.percentage.pfct <- round(prob.greater.pfct*100,2)

    prob.threshold.pfct <- pfct
    
    prob.interval.percentage.pfct <- NA

    prob.pfct <-  data.frame(prob.threshold = prob.threshold.pfct,
                             prob.less.percentage = prob.less.percentage.pfct,
                             prob.greater.percentage = prob.greater.percentage.pfct, 
                             prob.interval.percentage = prob.interval.percentage.pfct)


    prob.pfct

    probs = list(prob.thresholds=prob.thresholds,
                 prob.point.forecast=prob.pfct)
    probs
}#END empirical.probability.yboot.simple.sibling.regression.total.age

upgrade_scatmat_data <- function(data){
    dataIsCharacter <- sapply(data, is.character)
    if (any(dataIsCharacter)) {
        dataCharacterColumns <- names(dataIsCharacter[dataIsCharacter])
        for (dataCol in dataCharacterColumns) {
            data[dataCol] <- as.factor(data[, dataCol])
        }
    }
    data
}#END upgrade_scatmat_data

scatmatold <- function(data, columns = 1:ncol(data), color = NULL, alpha = 1){

    usePackage("ggplot2")

    data <- SIMPLESIBREG$upgrade_scatmat_data(data)
    
    data.choose <- data[, columns]
    dn <- data.choose[sapply(data.choose, is.numeric)]
    if (ncol(dn) == 0) {
        stop("All of your variables are factors. Need numeric variables to make scatterplot matrix.")
    }
    else {

        ltdata.new <- lowertriangle(data, columns = columns, color = color)

        r <- ggplot(ltdata.new, mapping = aes_string(x = "xvalue",y = "yvalue")) +
                    facet_grid(ylab ~ xlab, scales = "free", switch="both", drop=FALSE) +
                     theme(axis.title.x = element_blank(),
                          axis.title.y = element_blank()) +
                     theme(aspect.ratio = 1)



        if (is.null(color)) {
            densities <- do.call("rbind", lapply(1:ncol(dn),
                function(i) {
                  data.frame(xlab = names(dn)[i], ylab = names(dn)[i],
                    x = dn[, i])
                }))
            for (m in 1:ncol(dn)) {
                j <- subset(densities, xlab == names(dn)[m])
                r <- r + stat_density(aes(x = x, y = ..scaled.. *
                  diff(range(x)) + min(x)), data = j, position = "identity",
                  geom = "line", color = "black")
            }
            r <- r + geom_point(alpha = alpha, na.rm = TRUE)
            return(r)
        }
        else {
            densities <- do.call("rbind", lapply(1:ncol(dn),
                function(i) {
                  data.frame(xlab = names(dn)[i], ylab = names(dn)[i],
                    x = dn[, i], colorcolumn = data[, which(colnames(data) ==
                      color)])
                }))
            for (m in 1:ncol(dn)) {
                j <- subset(densities, xlab == names(dn)[m])
                r <- r + stat_density(aes_string(x = "x", y = "..scaled.. * diff(range(x)) + min(x)",
                  colour = "colorcolumn"), data = j, position = "identity",
                  geom = "line")
            }
            r <- r + geom_point(data = ltdata.new, aes_string(colour = "colorcolumn"),
                alpha = alpha, na.rm = TRUE)
            return(r)
        }
    }
}#END scatmatold

ggscatmatrix <- function(data, columns = 1:ncol(data), color = NULL, alpha = 1, corMethod = "pearson"){
    usePackage("GGally")
    usePackage("ggplot2")

    data <- SIMPLESIBREG$upgrade_scatmat_data(data)
    data.choose <- data[, columns]
    dn <- data.choose[sapply(data.choose, is.numeric)]

    if (ncol(dn) == 0) {
        stop("All of your variables are factors. Need numeric variables to make scatterplot matrix.")
    }

    if (ncol(dn) < 2) {
        stop("Not enough numeric variables to make a scatter plot matrix")
    }

    a <- uppertriangle(data, columns = columns, color = color,
        corMethod = corMethod)

    if (is.null(color)) {
        plot <- scatmat(data, columns = columns, alpha = alpha) +
            geom_text(data = a, aes_string(label = "r"), colour = "black")
    }

    else {
        plot <- scatmatold(data, columns = columns, color = color,
            alpha = alpha) + geom_text(data = a, aes_string(label = "r",
            color = "colorcolumn")) + labs(color = color)
    }

    factor <- data.choose[sapply(data.choose, is.factor)]
    if (ncol(factor) == 0) {
        return(plot)
    }
    else {
        warning("Factor variables are omitted in plot")
        return(plot)
    }
}#END ggscatmatrix

myezCor <- function(data, r_size_lims = c(10, 30), point_alpha = 0.5, density_height = 1, density_adjust = 1, density_colour = "white", label_size = 10, label_colour = "black", label_alpha = 0.5, lm_colour = "red", ci_colour = "green", ci_alpha = 0.5, test_alpha = 0.05, test_correction = "none"){
	#usePackage("ez")
    ntests = ((((ncol(data) - 1)^2) - (ncol(data) - 1))/2)
    if (test_correction[1] == "bonferroni") {
        test_alpha = test_alpha/ntests
    } else {
        if (test_correction[1] == "sidak") {
            test_alpha = 1 - (1 - test_alpha)^(1/ntests)
        }
    }
    for (i in 1:length(data)) {
        data[, i] = (data[, i] - mean(data[, i], na.rm = T))/sd(data[,
            i], na.rm = T)
    }
    z = data.frame()
    z_cor = data.frame()
    i = 1
    j = i
    while (i <= length(data)) {
        if (j > length(data)) {
            i = i + 1
            j = i
        }
        else {
            x = data[, i]
            y = data[, j]
            toss = is.na(x) | is.na(y)
            x = x[!toss]
            y = y[!toss]
            temp = as.data.frame(cbind(x, y))
            temp = cbind(temp, names(data)[i], names(data)[j])
            z = rbind(z, temp)
            this_cor = round(cor(x, y), 2)
            this_cor.test = cor.test(x, y)
            this_col = ifelse(this_cor.test$p.value < test_alpha,
                "a", "b")
            this_size = (this_cor)^2
            cor_text = ifelse(this_cor == 0, "0", ifelse(this_cor ==
                1, "1", ifelse(this_cor == -1, "-1", ifelse(this_cor >
                0, substr(format(c(this_cor, 0.123456789), digits = 2)[1],
                2, 4), paste("-", substr(format(c(this_cor, 0.123456789),
                digits = 2)[1], 3, 5), sep = "")))))
            b = as.data.frame(cor_text)
            b = cbind(b, this_col, this_size, names(data)[j],
                names(data)[i])
            z_cor = rbind(z_cor, b)
            j = j + 1
        }
    }
    names(z) = c("x", "y", "x_lab", "y_lab")
    z = z[z$x_lab != z$y_lab, ]
    names(z_cor) = c("cor", "p", "rsq", "x_lab", "y_lab")
    z_cor = z_cor[z_cor$x_lab != z_cor$y_lab, ]
    diag = melt(data, measure.vars = names(data))
    names(diag)[1] = "x_lab"
    diag$y_lab = diag$x_lab
    dens = ddply(diag, .(x_lab, y_lab), function(x) {
        d = density(x$value[!is.na(x$value)], adjust = density_adjust)
        d = data.frame(x = d$x, y = d$y)
        d$ymax = d$y * (max(abs(c(z$x, z$y))) * 2 * density_height)/max(d$y) -
            max(abs(c(z$x, z$y))) * density_height
        d$ymin = -max(abs(c(z$x, z$y))) * density_height
        return(d)
    })
    labels = ddply(diag, .(x_lab, y_lab), function(x) {
        to_return = data.frame(x = 0, y = 0, label = x$x_lab[1])
        return(to_return)
    })
    
    points_layer = layer(geom = "point",  stat = "identity", position = "identity", params = list(alpha = point_alpha),
                         data = z, mapping = aes_string(x = "x", y = "y"))
    
    lm_line_layer = layer(geom = "line",  stat = "smooth", position = "identity", params = list(colour = lm_colour, method = "lm"),
                          data = z, mapping = aes_string(x = "x", y = "y"))
        
        
    lm_ribbon_layer = layer(geom = "ribbon",  stat = "smooth", position = "identity",
                            params = list(fill = ci_colour, alpha = ci_alpha, method = "lm"), 
                            data = z, mapping = aes_string(x = "x", y = "y"))
        
    cor_text_layer = layer(geom = "text", stat = "identity", position = "identity", 
                           data = z_cor, 
                           mapping = aes_string(label = "cor", size = "rsq", colour = "p", x = 0, y = 0))
        
    dens_layer = layer(geom = "ribbon", stat = "identity", position = "identity",
                       params = list(colour = "transparent", fill = "white"),      
                       data = dens, 
                       mapping = aes_string(x = "x", ymax = "ymax", ymin = "ymin"))
        
    label_layer = layer(geom = "text", stat = "identity", position = "identity",
                        params = list(colour = label_colour,size = label_size, alpha = label_alpha), 
                        data = labels, 
                        mapping = aes_string(x = "x", y = "y", label = "label"))
        
        
    y_lab = NULL
    x_lab = NULL
    
    f = facet_grid(x_lab ~ y_lab)
    
    packs = installed.packages()
    
    ggplot2_version_char = packs[dimnames(packs)[[1]] == "ggplot2",
        dimnames(packs)[[2]] == "Version"]
    
    ggplot2_version_char = strsplit(ggplot2_version_char, ".",
        fixed = T)[[1]]
    
   
    o = theme(panel.grid.minor = element_blank(), panel.grid.major = element_blank(),
            axis.ticks = element_blank(), axis.text.y = element_blank(),
            axis.text.x = element_blank(), axis.title.y = element_blank(),
            axis.title.x = element_blank(), legend.position = "none"
            # ,
            # strip.background = element_blank() # strip.text.x = element_blank(),
            # strip.text.y = element_blank()
            )
            
    
    x_scale = scale_x_continuous(limits = c(-1 * max(abs(dens$x)),
        max(abs(dens$x))))
        
    size_scale = scale_size(limits = c(0, 1), range = r_size_lims)
    
    
    
    return(ggplot(z_cor) + points_layer + # lm_ribbon_layer + lm_line_layer +
        dens_layer + # label_layer +
        cor_text_layer + f + o +
        x_scale +
        size_scale
        )
}#END myezCor
