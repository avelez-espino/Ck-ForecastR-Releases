

########################################################################################################
# Naive Time Series Forecasting (Average of Past 5 Years) - Forecasting Results
########################################################################################################
source("R/n5/Review Code - Average Five_functions.R")

n5$datafile <- datafile_original

n5$datafilesub <- n5$datafile

n5$stockabundance <- n5$datafile$Stock_Abundance[1]
n5$stockabundance <- gsub("[[:space:]]", "_", n5$stockabundance)

n5$stockname <- n5$datafile$Stock_Name[1]
n5$stockspecies <- n5$datafile$Stock_Species[1]
n5$forecastingyear <- n5$datafile$Forecasting_Year[1]


usePackage("stringr")
n5$forecastingyear <- str_replace_all(n5$forecastingyear, "\n","")
n5$forecastingyear <- as.numeric(n5$forecastingyear)



## datafile <- data.frame(BY, T2, T3, T4, T5)   # need to come back here to automate the creation of this data frame!!! [January 13, 2014]

n5$extract_ages <- sort(unique(n5$datafilesub$Age_Class))
n5$extract_names <- paste("T",n5$extract_ages,sep="")
n5$extract_names <- c("BY",n5$extract_names)


n5$tmpsub <- list()
for (i in 1:length(n5$extract_ages)){
    n5$tmpsub[[i]] <- subset(n5$datafilesub, Age_Class==n5$extract_ages[i])[,c("Brood_Year",paste0("Average","_",n5$stockabundance))]
}


n5$list.of.data.frames <- n5$tmpsub
n5$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), n5$list.of.data.frames)

n5$datafile_new <- n5$merged.data.frame
names(n5$datafile_new) <- n5$extract_names

## datafile <<- datafile_new

n5$datafile <- n5$datafile_new

#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for naive forecasting (average of past 5 years) ---------------------------------

n5$datalist <- n5$datalist.avgfive(n5$datafile, n5$forecastingyear)  # CY refers to the T variable with highest age


#--------- prepare data table for reporting --------------------------------------------------

n5$datafile.report <-  n5$datafile

n5$datafile.report[n5$datafile.report <0] <- "NA"



#--------- plot data to be used for naive forecasting (average of past five years) (uses ggplot) ---------------------------

n5$plot.data.avgfive(n5$datalist)


#--------- helper function for computing the average of the past five years of a time series -----


#--------- helper function for computing the average of the past 5 years of a time series -----


#---------  fit naive model (average of past 5 years) -----------------------------------------

n5$avgfive.model.fits  <- n5$avgfive.model(n5$datalist)

n5$fits <- n5$avgfive.model.fits


#---------  Plot naive model (average of past 5 years) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------
n5$fits <- n5$avgfive.model.fits
n5$plot.fitted.avgfive(n5$fits)


#-------------------------------------------------------------------------------
# Model Diagnostics for Age-Specific Naive Time Series Model  (Average of Past 5 Years)
#-------------------------------------------------------------------------------
n5$diagnostics.avgfive.model.fit(n5$fits,i)



#--------- point forecast for each individual age and for the total age ----------------------
# http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

n5$point.forecast.avgfive(n5$datalist, n5$fits)

n5$results.point.forecast.avgfive <- NULL
for (j in 1:length(n5$avgfive.model.fits)){

       n5$tmp_list <- n5$point.forecast.avgfive(n5$datalist, n5$avgfive.model.fits)[[j]]

       # list2 <- unlist(list1)

       # point.pred.asslr <- rbind(point.pred.asslr, list2)

       n5$tmp_df <- do.call(cbind.data.frame, n5$tmp_list)

       n5$results.point.forecast.avgfive <- rbind(n5$results.point.forecast.avgfive, n5$tmp_df)

}

n5$results.point.forecast.avgfive$Model <- as.character(n5$results.point.forecast.avgfive$Model)

## results.point.forecast.avgfive

## str(results.point.forecast.avgfive)





#--------- Naive Model (Average of Past 5 Years): retrospective evaluation for each individual age ----------------------------------
n5$results.individual.ages.retro.predictive.performance.avgfive  <-
     n5$individual.ages.retro.predictive.performance.avgfive(n5$datalist, n5$index.year)

## results.individual.ages.retro.predictive.performance.avgfive

## names(results.individual.ages.retro.predictive.performance.avgfive)


#---------------------------------------------------------------------------------------

### report retrospective performance measures for individual ages in a nicer format
n5$MIA <- n5$measures.individual.ages.retro.avgfive(n5$results.individual.ages.retro.predictive.performance.avgfive)

## MIA


##
## Total Age
##


#---------  Naive Forecast (Average of Past 5 Years): retrospective evaluation for the total age ----------------------------------------
n5$results.total.age.retro.predictive.performance.avgfive <-
      n5$total.age.retro.predictive.performance.avgfive(n5$datalist, n5$index.year)

n5$results.total.age.retro.predictive.performance.avgfive

## names(results.total.age.retro.predictive.performance.avgfive)



#-------------------------------------------------------------------------------
n5$total.age.retro.plot.avgfive(n5$total.age.retro.plot.info.avgfive, n5$stockabundance)

#-------------------------------------------------------------------------------------

### report retrospective performance measures for total age in a nicer format
n5$MTA <- n5$measures.total.age.retro.avgfive(n5$results.total.age.retro.predictive.performance.avgfive)

## M <- merge(MIA, MTA, by = intersect(names(MIA), names(MTA)), sort=FALSE)

n5$M <- merge(n5$MIA, n5$MTA, by = c("Measure"), sort=FALSE)

n5$M <- subset(n5$M, select=-Model.y)

## M

names(n5$M)[names(n5$M)=="Model.x"] <- "Model"

## M

n5$M.avgfive <- n5$M




### report actual, forecasted and error values for total age in a nicer format
n5$results.afe.total.age.retro.avgfive <-
 n5$afe.total.age.retro.avgfive(n5$results.total.age.retro.predictive.performance.avgfive)

n5$results.afe.total.age.retro.avgfive


## usePackage("scales")
## cbind(results.afe.total.age.retro.avgfive[,1],
##      comma(round(results.afe.total.age.retro.avgfive[,"Actual"])),
##      comma(round(results.afe.total.age.retro.avgfive[,"Forecast"])),
##      comma(round(results.afe.total.age.retro.avgfive[,"Error"]))
##)

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## fit <- avgfive.model.fits[[1]]
## forecast.avgfive.modified.meboot(fit, level=80, npaths=999)

n5$fits <- n5$avgfive.model.fits
n5$pred.int.individual.ages.avgfive <- n5$prediction.intervals.individual.ages.avgfive(n5$fits, n5$bootmethod, level=80, npaths=n5$B)

# pred.int.individual.ages.avgfive

#----------------------------------------------------------------------------

n5$PI.ctr <- NULL
n5$PI.lwr <- NULL
n5$PI.upr <- NULL
# PI.med <- NULL
n5$PI.sim <- NULL
n5$nms <- NULL

for (k in 1:length(n5$pred.int.individual.ages.avgfive)){

     n5$PI.ctr <- c(n5$PI.ctr,
                 n5$pred.int.individual.ages.avgfive[[k]]$PI.ctr)

     n5$PI.lwr <- c(n5$PI.lwr,
                 n5$pred.int.individual.ages.avgfive[[k]]$PI.lwr)

     n5$PI.upr <- c(n5$PI.upr,
                 n5$pred.int.individual.ages.avgfive[[k]]$PI.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.avgfive)[[k]]$PI.median)

     n5$PI.sim <- cbind(n5$PI.sim, n5$pred.int.individual.ages.avgfive[[k]]$sim)

     n5$nms <- c(n5$nms, n5$pred.int.individual.ages.avgfive[[k]]$age)

}

colnames(n5$PI.sim) <- n5$nms


n5$PI.lwr[n5$PI.lwr < 0] <- 0
n5$PI.upr[n5$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

n5$PI.ctr <- round(n5$PI.ctr)
n5$PI.lwr <- round(n5$PI.lwr)
n5$PI.upr <- round(n5$PI.upr)
## PI.med <- round(PI.med)


n5$PI.individual.ages.avgfive <- data.frame(PI.ctr=n5$PI.ctr, PI.lwr=n5$PI.lwr, PI.upr=n5$PI.upr)

n5$PI.individual.ages.avgfive.no.comma <- data.frame(PI.ctr=n5$PI.ctr, PI.lwr=n5$PI.lwr, PI.upr=n5$PI.upr)


## PI.individual.ages.avgfive

usePackage("scales")

n5$PI.individual.ages.avgfive <- comma(n5$PI.individual.ages.avgfive)

## PI.individual.ages.avgfive

n5$PI.individual.ages.avgfive.sim <- n5$PI.sim

## plot.distribution.bootstrapped.point.forecasts.individual.ages.avgfive(PI.individual.ages.avgfive.sim,
##                                                                        PI.individual.ages.avgfive.no.comma, stockabundance)


n5$plot.distribution.bootstrapped.point.forecasts.individual.ages.avgfive(n5$PI.individual.ages.avgfive.sim,
                                                                       n5$PI.individual.ages.avgfive.no.comma,
                                                                       n5$stockabundance)


############################################################################################
#*******************************************************************************************
#
#------------ compute prediction interval for point forecast of total age       -----------
#
#*******************************************************************************************

n5$avgfive.sim.total.age <- NULL
n5$nms <- NULL
n5$avgfive.PI.ctr.total.age <- 0
for (k in 1:length(n5$pred.int.individual.ages.avgfive)){
     n5$avgfive.sim.total.age <- cbind(n5$avgfive.sim.total.age, n5$pred.int.individual.ages.avgfive[[k]]$sim)
     n5$nms <- c(n5$nms, n5$pred.int.individual.ages.avgfive[[k]]$age)
     n5$avgfive.PI.ctr.total.age <- n5$avgfive.PI.ctr.total.age + n5$pred.int.individual.ages.avgfive[[k]]$PI.ctr
}

colnames(n5$avgfive.sim.total.age) <- n5$nms

n5$PI.total.age.avgfive <- NULL


n5$sim <- apply(n5$avgfive.sim.total.age, 1, sum)

n5$PI.total.age.avgfive$PI.ctr <- n5$avgfive.PI.ctr.total.age
## PI.total.age.avgfive$PI.med <- quantile(sim, 0.500)
n5$PI.total.age.avgfive$PI.lwr <- quantile(n5$sim, 0.10, type=8)  # need to automate this!
n5$PI.total.age.avgfive$PI.upr <- quantile(n5$sim, 0.90, type=8)  # need to automate this!

n5$PI.total.age.avgfive <- data.frame(n5$PI.total.age.avgfive)

## names(PI.total.age.avgfive) <- c("PI.ctr","PI.med","PI.lwr","PI.upr")
names(n5$PI.total.age.avgfive) <- c("PI.ctr","PI.lwr","PI.upr")

## PI.total.age.avgfive

rownames(n5$PI.total.age.avgfive) <- NULL

n5$PI.total.age.avgfive


#-----------------------------------------------------------------------------------------------


n5$PI.total.age.avgfive$PI.lwr[n5$PI.total.age.avgfive$PI.lwr < 0] <- 0
n5$PI.total.age.avgfive$PI.upr[n5$PI.total.age.avgfive$PI.upr < 0] <- 0
## PI.total.age.avgfive$PI.med[PI.total.age.avgfive$PI.med < 0] <- 0

n5$PI.total.age.avgfive$PI.ctr <- round(n5$PI.total.age.avgfive$PI.ctr)
n5$PI.total.age.avgfive$PI.lwr <- round(n5$PI.total.age.avgfive$PI.lwr)
n5$PI.total.age.avgfive$PI.upr <- round(n5$PI.total.age.avgfive$PI.upr)
## PI.total.age.avgfive$PI.med <- round(PI.total.age.avgfive$PI.med)

usePackage("scales")

n5$PI.total.age.avgfive.no.comma <- n5$PI.total.age.avgfive

n5$PI.total.age.avgfive$PI.ctr <- comma(n5$PI.total.age.avgfive$PI.ctr)

n5$PI.total.age.avgfive$PI.lwr <- comma(n5$PI.total.age.avgfive$PI.lwr)

n5$PI.total.age.avgfive$PI.upr <- comma(n5$PI.total.age.avgfive$PI.upr)

## PI.total.age.avgfive$PI.med <- comma(PI.total.age.avgfive$PI.med)

## PI.total.age.avgfive

n5$PI.total.age.avgfive.sim <- n5$sim



##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - total age
#
##########################################################################################



###
### Histogram of Bootstrap Predictions
###

n5$plot.distribution.bootstrapped.point.forecasts.total.age.avgfive(n5$PI.total.age.avgfive.sim,
                                                                  n5$PI.total.age.avgfive.no.comma,
                                                                  n5$stockabundance)


#-----------------------------------------------------------------------------------------
# Scatter plot of retrospectively forecasted versus actual values of abundance (individual ages, avgfive)
#-----------------------------------------------------------------------------------------
n5$results <- n5$results.individual.ages.retro.predictive.performance.avgfive

## scatter.plot.results.afe.individual.ages.retro.avgfive(
##   ## avgfive.model.fits,
##   results.individual.ages.retro.predictive.performance.avgfive
##   )



#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values of abundance (individual ages, avgthree)
#-----------------------------------------------------------------------------------------
n5$results <- n5$results.total.age.retro.predictive.performance.avgfive
n5$scatter.plot.results.afe.total.age.retro.avgfive(n5$results)

#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values of abundance (individual ages, avgfive)
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.avgfive
## timeseries.plot.results.afe.individual.ages.retro.avgfive(results, stockabundance)


n5$timeseries.plot.results.afe.individual.ages.retro.avgfive(n5$results.individual.ages.retro.predictive.performance.avgfive, n5$stockabundance)


#*******************************************************************************
# Time series plot of forecasted vs. actual abundance (total age, avgfive)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.avgfive
## timeseries.plot.results.afe.total.age.retro.avgfive(results, stockabundance)

n5$timeseries.plot.results.afe.total.age.retro.avgfive(n5$results.total.age.retro.predictive.performance.avgfive, n5$stockabundance)


#*******************************************************************************
# Histogram of Retrospective Forecast Errors - Individual Ages
#*******************************************************************************

###
### Histogram of Retrospective Forecast Errors: Individual Ages
###

# hist.results.afe.individual.ages.retro.avgfive

## fits <- avgfive.model.fits
## results <- results.individual.ages.retro.predictive.performance.avgfive


## par(mfrow=c(4,1), mar=c(4,4,3,2))
## hist.results.afe.individual.ages.retro.avgfive(
##    avgfive.model.fits,
##    results.individual.ages.retro.predictive.performance.avgfive
## )


## dens.results.afe.individual.ages.retro.avgfive(avgfive.model.fits,
## results.individual.ages.retro.predictive.performance.avgfive)

#*******************************************************************************
#
# histogram of retrospective forecast errors (total age)
#
#*******************************************************************************

# hist.results.afe.total.age.retro.avgfive

## dens.results.afe.total.age.retro.avgfive(results.afe.total.age.retro.avgfive)

## results <- results.afe.total.age.retro.avgfive
## hist.results.afe.total.age.retro.avgfive(results)

#*******************************************************************************
#  barplot forecasted values (specific ages)
#
#*******************************************************************************

n5$fits <- n5$avgfive.model.fits

n5$pointforecasts <- n5$point.forecast.avgfive(n5$datalist, n5$avgfive.model.fits)

## barplot.forecasted.values.individual.ages.avgfive(fits, pointforecasts,i=1)


#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************

n5$results <- n5$results.total.age.retro.predictive.performance.avgfive

n5$pointforecasts <- n5$point.forecast.avgfive(n5$datalist, n5$avgfive.model.fits)

## barplot.forecasted.values.total.age.avgfive(results, pointforecasts)

#*******************************************************************************
#
# Gary's Plot for Individual Ages
#
#*******************************************************************************
n5$results.retro <- n5$results.individual.ages.retro.predictive.performance.avgfive
## names(results.retro)

n5$results.pred <- n5$pred.int.individual.ages.avgfive

## par(mfrow=c(1,1))
## j <- 1

n5$gary.plot.individual.ages(n5$results.retro, n5$results.pred, j=1)


#*******************************************************************************
#
# Gary's Plot for "Total Age"
#
#*******************************************************************************
n5$results.retro <- n5$results.total.age.retro.predictive.performance.avgfive
## names(results.retro)
n5$results.pred <- n5$PI.total.age.avgfive.no.comma

n5$gary.plot.total.age(n5$results.retro, n5$results.pred)



###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (individual ages) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

n5$fits <- n5$avgfive.model.fits
n5$pointforecasts <- n5$point.forecast.avgfive(n5$datalist, n5$avgfive.model.fits)
n5$intervalforecasts <-   n5$PI.individual.ages.avgfive.no.comma

## i <- 1
n5$scatterplot.forecasted.values.and.forecast.intervals.individual.ages.avgfive(n5$fits, n5$pointforecasts, n5$intervalforecasts,i=1)


# plot forecasted values & forecast intervals:  scatterplot (total age)

n5$results <- n5$results.total.age.retro.predictive.performance.avgfive
n5$pointforecasts <- n5$point.forecast.avgfive(n5$datalist, n5$avgfive.model.fits)
n5$intervalforecasts <-  n5$PI.total.age.avgfive.no.comma

n5$scatterplot.forecasted.values.and.forecast.intervals.total.age.avgfive(
   n5$results,
   n5$pointforecasts,
   n5$intervalforecasts)




##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - individual ages
#
##########################################################################################

n5$fits <- n5$avgfive.model.fits
n5$results <- n5$results.individual.ages.retro.predictive.performance.avgfive

windows()
n5$bias.coefficients.afe.individual.ages.retro.avgfive(n5$avgfive.model.fits,
                                                    n5$results.individual.ages.retro.predictive.performance.avgfive,
                                                    n5$stockabundance)

n5$bias.coeff.afe.individual.ages.retro.avgfive

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################

n5$results <- n5$results.total.age.retro.predictive.performance.avgfive

windows()
n5$bias.coefficient.afe.total.age.retro.avgfive(n5$results.total.age.retro.predictive.performance.avgfive,
                                                n5$stockabundance)

n5$bias.coeff.afe.total.age.retro.avgfive

