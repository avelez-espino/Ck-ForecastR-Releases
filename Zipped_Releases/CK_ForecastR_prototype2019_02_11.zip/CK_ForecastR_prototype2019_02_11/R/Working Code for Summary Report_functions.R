
delete.NULLs  <-  function(x.list){   # delele null/empty entries in a list
    x.list[unlist(lapply(x.list, length) != 0)]
}

rank.rmse.results.individual.age  <- function(table.rmse.results.individual.age, pred.args, all.pred.args, j){  # j = cycles through ages

     ## need to work with absolute values of MRE and MPE (should these be selected by users)

     table.rmse.results.individual.age.tmp <- as.data.frame(table.rmse.results.individual.age[[j]])
     table.rmse.results.individual.age.tmp <- apply(table.rmse.results.individual.age.tmp, 2, abs)


     pred.int.widths <- NULL
     pred.int.models <- NULL
     pred.int.lower.limit <- NULL
     pred.int.upper.limit <- NULL
     pred.int.center <- NULL
     for (i in 1:length(pred.args)){   # cycle through each forecasting model using the index i;
                                       # cycle through each individual age using the index j

          model.info.tmp <- pred.args[all.pred.args[i]] # information for i-th model

          age.info.tmp <- model.info.tmp[[1]][[j]]                                         # information for j-th age

          pred.int.lower.limit.tmp <- round(age.info.tmp$PI.lwr)
          pred.int.upper.limit.tmp <- round(age.info.tmp$PI.upr)
          pred.int.width.tmp <- pred.int.upper.limit.tmp - pred.int.lower.limit.tmp
          pred.int.widths <- c(pred.int.widths, pred.int.width.tmp)

          class.tmp <- all.pred.args[i]

          usePackage("stringr")
          class.tmp <- str_replace_all(class.tmp, "pred.int.individual.ages.", "")
          class.tmp

          pred.int.models <- c(pred.int.models, class.tmp)
          pred.int.lower.limit <- c(pred.int.lower.limit, pred.int.lower.limit.tmp)
          pred.int.upper.limit <- c(pred.int.upper.limit, pred.int.upper.limit.tmp)

          pred.int.center.tmp <- round(age.info.tmp$PI.ctr)
          pred.int.center <- c(pred.int.center, pred.int.center.tmp)

     }

     pred.int <- data.frame(model=pred.int.models, center=pred.int.center,
                            lower=pred.int.lower.limit, upper=pred.int.upper.limit,
                            width=pred.int.widths)

     if (ncol(table.rmse.results.individual.age.tmp) > 1) {   # more than one retro measure

         table.rmse.results.individual.age.tmp[is.infinite(table.rmse.results.individual.age.tmp)] <- NA
         table.rmse.results.individual.age.tmp[is.nan(table.rmse.results.individual.age.tmp)] <- NA

         ranks <- apply(table.rmse.results.individual.age.tmp,2,rank, na.last="keep")

         avg.ranks <- round(apply(ranks,1,mean, na.rm=TRUE),2)
         pred.int.and.avg.ranks <- cbind.data.frame(pred.int, avg.ranks)
         ## index.min.avg.rank <- as.numeric(which(avg.ranks == min(avg.ranks))[1])
         index.min.avg.rank <- as.numeric(which(avg.ranks == min(avg.ranks)))
         index.min.avg.rank <- index.min.avg.rank[which(pred.int.widths[avg.ranks == min(avg.ranks)]==min(pred.int.widths[avg.ranks == min(avg.ranks)]))]
         model.min.avg.rank <- rownames(table.rmse.results.individual.age.tmp)[index.min.avg.rank]
     }

     ## when there is only one forecasting model, ranking is not necessary

     if (ncol(table.rmse.results.individual.age.tmp)>1) {
        out <- list()
        out$age <- names(table.rmse.results.individual.age)[j]
        ## out$ranking.method <- ranking.method
        out$ranking.measures <- colnames(table.rmse.results.individual.age.tmp)
        out$measures <- table.rmse.results.individual.age[[j]]  ## should you have absolute values here for MRE and MPE?
        out$absolute.measures <- apply(table.rmse.results.individual.age[[j]],2,abs)
        out$ranks <- ranks
        out$avg.ranks <- avg.ranks
        out$pred.int.and.avg.ranks <- pred.int.and.avg.ranks
        out$index.min.avg.rank <- index.min.avg.rank
        out$model.min.avg.rank <- index.min.avg.rank
        out$all.models <- rownames(table.rmse.results.individual.age.tmp)
        out$best.model <- rownames(table.rmse.results.individual.age.tmp)[index.min.avg.rank]
     }


     if(ncol(table.rmse.results.individual.age.tmp)==1) {

        model.tmp <- names(pred.args)
        usePackage("stringr")
        model.tmp <- str_replace_all(model.tmp,"pred.int.individual.ages.","")
        ## model.tmp <- str_replace_all(model.tmp,".individual.age","")


        out <- list()
        out$age <- names(table.rmse.results.individual.age)[j]
        ## out$ranking.method <- ranking.method
        out$ranking.measures <- rownames(table.rmse.results.individual.age.tmp)
        out$measures <- table.rmse.results.individual.age[[j]]  ## should you have absolute values here for MRE and MPE?
        out$absolute.measures <- abs(table.rmse.results.individual.age[[j]])  ## will this work for a vector?
        out$ranks <- 1
        out$avg.ranks <- 1
        tmpdat <- cbind.data.frame(pred.int, 1)
        colnames(tmpdat)[colnames(tmpdat)=="1"] <- "Rank"
        ## out$pred.int.and.avg.ranks <-    ## What should be listed here???
        out$index.min.avg.rank <- 1
        out$model.min.avg.rank <- 1
        out$all.models <- model.tmp
        out$best.model <- model.tmp
     }


     return(out)

}
