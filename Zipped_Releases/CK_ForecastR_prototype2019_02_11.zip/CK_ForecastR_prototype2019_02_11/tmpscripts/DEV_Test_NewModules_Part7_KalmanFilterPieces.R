# KALMAN FILTER OPTIONS TESTING

source("../R/utils.R")




# set up the sample data set

samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")



age.x <- sample.dat$data$"Age 4"
age.y <- sample.dat$data$"Age 5"

yrs.use <- age.y[,"Run_Year"]	

		
pred.age <- age.x[age.x[,"Run_Year"] %in% (yrs.use-1),3]
resp.age <- age.y[,3]

fc.pred <- age.x[age.x[,"Run_Year"]== max(yrs.use),3]



# do a simple linear regression

plot(pred.age,resp.age)

simple.fit <- lm(resp.age~pred.age)
summary(simple.fit)$coefficients
abline(simple.fit,col="red")






# -----------------------------------------
# CARRIE CODE
# -----------------------------------------

# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


x <- pred.age
y <- resp.age

###Set up initial parameters (Ts=1, but remaining initials can be adjusted)
initial<-list(lm(y~x)$coef[2], 10, 10 , lm(y~x)$coef[1], 10, 1)
names(initial)<-c("b", "ln.sig.e", "ln.sig.w", "mean.a", "var.a", "Ts")
output<-kf.rw(initial=initial,x=x,y=y)
names(output)
output$smoothe.mean.a
plot(output$smoothe.mean.a)
output$b


plot(pred.age,resp.age,bty="n",col="blue",pch=19)

colfunc <- colorRampPalette(c("lightgrey", "red"))
cols.list <- colfunc(length(output$smoothe.mean.a))
lwd.list <- seq(1,2,length.out = length(output$smoothe.mean.a))

for(i in 1:length(output$smoothe.mean.a) ){
	abline(output$smoothe.mean.a[i],output$b,col=cols.list[i],lwd=lwd.list[i])
	}









#------------------------------------------------------------------
# KFAS
# ----------------------------------------------------------------
# using {KFAS} package



load_or_install("KFAS")



# generate a state-space model based on a formula


kf.model.in <- SSModel(resp.age ~ SSMregression(~ 1+ pred.age, Q = NA), H = NA)
#kf.model.in <- SSModel(resp.age ~ SSMregression(~ 1+ pred.age, Q = diag(NA,1)), H = NA)
kf.fit <- fitSSM(kf.model.in, inits = c(0,0,0), method = "BFGS")
kf.model.out <- kf.fit$model

names(kf.fit)
names(kf.fit$optim.out)
kf.fit$optim.out$par
kf.fit$optim.out$value

names(kf.fit$model)
kf.fit$model$y # input values of the response
kf.fit$model$Z # input values of the predictor 
kf.fit$model$T  # ??
kf.fit$model$R  # ??
kf.fit$model$Q  # ??
kf.fit$model$a1  # ??
kf.fit$model$P1  # ??
kf.fit$model$P1inf # ??
kf.fit$model$u   # ??
kf.fit$model$distribution   # showing the distr. used (i.e. "gaussian")
kf.fit$model$tol   # ???tolerance??? of what?
kf.fit$model$call  # Model formula
kf.fit$model$terms   # ??

# this should produce fitted values I think, but these are too close to the obs data
predict(kf.model.out) 


# this gives an error
predict(kf.model.out,newdata=kf.model.in) 
predict(kf.model.out,newdata=SSMregression(~ 1 + fc.pred, Q = NA))
predict(kf.model.out,n.ahead=1) 
predict(kf.model.in) 

#???
residuals.KFS(kf.fit)
summary(kf.model)
fitted(kf.model)
plot(fitted(kf.model))


# not in KFAS anymore?
# regSSM()
#kf.model <- SSModel( regSSM(y=as.ts(resp.age),X=as.matrix(pred.age,ncol=1))


# their example: dynamic regression model

set.seed(1)
x1 <- rnorm(100)
x2 <- rnorm(100)
b1 <- 1 + cumsum(rnorm(100, sd = 1))
b2 <- 2 + cumsum(rnorm(100, sd = 0.1))
y <- 1 + b1 * x1 + b2 * x2 + rnorm(100, sd = 0.1)
model <- SSModel(y ~ SSMregression(~ x1 + x2, Q = diag(NA,2)), H = NA)
fit <- fitSSM(model, inits = c(0,0,0), method = "BFGS")
model <- fit$model
model$Q
model$H
out <- KFS(model)
ts.plot(out$alphahat[,-1], b1, b2, col = 1:4)




#------------------------------------------------------------------
# DLM
# ----------------------------------------------------------------
# using {dlm} package

load_or_install("dlm")



# their example
set.seed(2)
tmp <- dlmRandom(3, 5, 20)
names(tmp)
obs <- tmp$y
m <- tmp$mod
rm(tmp)
f <- dlmFilter(obs, m)
s <- dlmSmooth(f)
all.equal(s, dlmSmooth(obs, m))







