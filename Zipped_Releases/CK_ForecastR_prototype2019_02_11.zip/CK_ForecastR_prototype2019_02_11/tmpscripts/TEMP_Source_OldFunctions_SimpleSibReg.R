datafile_extract_age_class <- function(datafile, stockabundance){

    forecastingyear <- as.numeric(datafile$Forecasting_Year[1])
    datafilesub <- datafile

    stockname <- datafile$Stock_Name[1]
    extract_ages <- sort(unique(datafilesub$Age_Class))

    tmpvar <- list()
    for (i in 1:length(extract_ages)){
         if (stockabundance=="Terminal Run"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Terminal_Run")]
           names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Terminal_Run"] <- paste0("Age","_",extract_ages[i])
         }

         if (stockabundance=="Escapement"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Escapement")]
            names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Escapement"] <- paste0("Age","_",extract_ages[i])
         }

         if (stockabundance=="Production"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Production")]
            names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Production"] <- paste0("Age","_",extract_ages[i])
         }

    }

    names(tmpvar) <- paste("Age", extract_ages)
    return(tmpvar)
}#END datafile_extract_age_class




prepare_data_and_model_formulas <- function(datafile_variables){
   # http://stackoverflow.com/questions/4951442/formula-with-dynamic-number-of-variables
   # mylist.names <- names(datafile_variables)
   # mylist <- vector("list", length(mylist.names)-1)
   # names(mylist) <- mylist.names[-1]

   mylist <- rep(list(list()),length(names(datafile_variables))-1)

   for (i in 2:length(datafile_variables)){
        outcome_data <- datafile_variables[[i]]
        names(outcome_data)[names(outcome_data)=="Run_Year"] <-
            paste0("Run_Year","_",names(outcome_data)[length(names(outcome_data))])
        predictor_data <- list()

        for (j in 1:(i-1)){
          predictor_data[[j]] <- datafile_variables[[j]]
          names(predictor_data[[j]])[names(predictor_data[[j]])=="Run_Year"] <-
          paste0("Run_Year","_",names(predictor_data[[j]])[length(names(predictor_data[[j]]))])
        }

        mylist[[i-1]]$outcome_data <- outcome_data
        mylist[[i-1]]$predictor_data <- predictor_data
    }

    names(mylist) <- names(datafile_variables)[-1]

    # build model formulas for each applicable age class,
    # as well as provide data set to be used for each formula
    # myres <- list(list())
    myres <- rep(list(list()),length(mylist))

    for (k in 1:length(mylist)){
         mylength <- length(mylist[[k]]$predictor_data)
         outcome_name <- names(mylist[[k]]$outcome_data)[3]
         predictor_names <-  unlist(lapply(mylist[[k]]$predictor_data, function(ll) {names(ll)[3]}))
         predictor_names  <- rev(predictor_names)

         for (l in 1:length(predictor_names)){
             model_formulas <- list()
             for (j in 1:l){
                 model_formulas[[j]] <- as.formula(paste(outcome_name,"~","-1","+",paste(predictor_names[1:(l-j+1)],collapse="+")))
             }
         }

         model_formulas <- rev(model_formulas)
         usePackage("BBmisc")
         model_formulas <- getFirst(model_formulas)   # extract first formula only for simple sibling regression


         ## if (k >= 2) {
         ## for (kk in 2:length(predictor_names)){
         ##   model_formulas[[length(predictor_names)+kk-1]] <-
         ##   as.formula(paste(outcome_name,"~","-1","+","I(",paste(predictor_names[1:kk],collapse="+"),")"))
         ## }
         ## }

          myres[[k]]$model_formulas <- model_formulas

         # http://stackoverflow.com/questions/22955617/linear-models-in-r-with-different-combinations-of-variables
         # predictor_variables <- c("factor1","factor2")
         # as.formula(paste("y~",paste(listofvariables,collapse="+")))
        }

    names(myres) <- names(datafile_variables)[-1]

    mymerge <- list()
    for (i in 1:length(mylist)){
        tmpmerge <- mylist[[i]]$outcome_data
        for (j in length(mylist[[i]]$predictor_data):1) {
            tmpmerge <- merge(tmpmerge, mylist[[i]]$predictor_data[[j]], by="Brood_Year", all=FALSE)
        }
        mymerge[[i]] <- tmpmerge
    }

    names(mymerge) <- names(datafile_variables)[-1]
    results <- list(model_data=mymerge, model_formulas=myres)

    return(results)
}#END prepare_data_and_model_formulas






sibling_regression_model_fits <- function(data_and_model_formulas){
    ## fits <- rep(list(list()),length(data_and_model_formulas[[1]]))
     fits <- vector("list", length(data_and_model_formulas[[1]]))
     names(fits) <- names(data_and_model_formulas[[1]])

     for (i in 1:length(data_and_model_formulas[[1]])){
          fits[[i]] <- lm(formula=data_and_model_formulas$model_formulas[[i]]$model_formulas, data=data_and_model_formulas$model_data[[i]])
    }
    res <- list(model_data=data_and_model_formulas$model_data,
                model_formulas=data_and_model_formulas$model_formulas,
                model_fits=fits)
    return(res)
}#END sibling_regression_model_fits