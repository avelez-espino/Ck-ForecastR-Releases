
#working directory should be tmpscripts
setwd("tmpscripts")
# Read in all the modules

source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")
source("../R/Module_rankModels.R")

# Inputs
data.use <- read.csv("../inst/extdata/SampleFile_WithAge.csv")  # read in raw data

# data.use <- read.csv("../inst/extdata/SampleFile_WithAge_covariates.csv", stringsAsFactors = FALSE)  # read in raw data
# data.use <- read.csv("../inst/extdata/SampleFile_WithoutAge_covariates.csv", stringsAsFactors = FALSE)  # read in raw data
# str(data.use)

settings.use <- list(Naive1 = list(model.type="Naive",settings=list(avg.yrs=1)),
				Naive3 = list(model.type="Naive",settings=list(avg.yrs=3)),
				Naive5 = list(model.type="Naive",settings=list(avg.yrs=5)),
				SibRegSimple = list(model.type="SibRegSimple",settings=NULL),
				SibRegLogPower =  list(model.type="SibRegLogPower",settings=NULL),
				SibRegKalman =  list(model.type="SibRegKalman",settings=NULL),
				TimeSeriesArimaBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=TRUE)),
				TimeSeriesArimaNoBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=FALSE)),
				TimeSeriesExpSmoothBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=TRUE)),
				TimeSeriesExpSmoothNoBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=FALSE))
				)


dat.prepped <-  prepData(datafile = data.use,out.labels="v2")
#str(dat.prepped)

test.list <- lapply(1:1000, function(x, dat.prepped){dat.prepped$data}, dat.prepped)

multiresults.retro <- multiFC(data.file=data.use,settings.list=settings.use, do.retro=TRUE,do.boot=FALSE,out.type="short", retro.min.yrs=15,tracing=FALSE)

names(multiresults.retro)

retro.pm <- multiresults.retro$retro.pm
names(retro.pm)

#do we want to rank all arrays of retro.pm?

#rankmodels() expects to receive an array.
#this ranks just retro.pm$retro.pm.all.constantyrs
rownames(retro.pm$retro.pm.all.varyrs)
str(retro.pm$retro.pm.all.varyrs)
#get best model for youngest age:
#exclude regressions:
sibling.row.index <- grep(pattern = "sib", tolower(rownames(retro.pm$retro.pm.all.varyrs)))
#array of youngest age pm's without regression models:
dat.nonsibling <- retro.pm$retro.pm.all.varyrs[-(sibling.row.index),,1, drop=FALSE]
dat.ranks.youngest <- rankModels(dat = dat.nonsibling)


dat.ranks <- rankModels(dat = retro.pm$retro.pm.all.varyrs)

rankModels(dat = retro.pm$retro.pm.all.varyrs, columnToRank= c("MRE","MASE"))

str(dat.ranks)
names(dat.ranks)

retro.pm$retro.pm.all.varyrs

View(dat.ranks$ageranks$`Age 3`)

View(dat.ranks$ageranks$`Total`)

#this data frame has the model specific sum of rank values at age:
View(dat.ranks$cumulativerank)
#this data frame has the model specific sum of rank values at age, sorted by the sum of ranks:
dat.ranks$cumulativerankSorted

#if working with 'noage' data, it must still be a 3D array
dim(retro.pm$retro.pm.all.constantyrs)
#reduce age array to have just the totals (make it appear like a no-age array)
dat.ranks <- rankmodels(dat = retro.pm$retro.pm.all.constantyrs[,,5, drop=FALSE])

dat.ranks$cumulativerank
dat.ranks$cumulativerankSorted

