# Script to test new modules PART 10: doBoot

#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


# load packages
require(meboot)
require(forecast)

#read in data set
data.raw <- read.csv("../inst/extdata/FinalSampleFile_WithAge_exclTotal.csv",stringsAsFactors=FALSE)
data.prep <- prepData(data.raw,out.labels="v2")


# TEST A SINGLE BOOT SET
test.boot <- doBoot(data= data.prep, args.fitmodel= list(model= "Naive", settings = list(avg.yrs=3)),
					args.calcfc = list(fc.yr= 2018,  settings = NULL),
					args.boot = list(boot.type="meboot", boot.n=1000, plot.diagnostics=FALSE),
					full.out = TRUE, plot.out=TRUE)

test.boot 


plot(density(as.data.frame(test.boot)$Total))



# RUN A FULL SET OF BOOTSTRAPPED FORECASTS


fc.ylim <- c(0,30000)
num.boots <- 500


models.list <- list(Naive3 =list(model= "Naive", settings = list(avg.yrs=3)),
			  Naive5 = list(model= "Naive", settings = list(avg.yrs=5)),
			  TS_ArimaNoBC = list(model= "TimeSeriesArima", settings = list(BoxCox=FALSE)),
			  TS_ExpSMoothNoBC = list(model= "TimeSeriesExpSmooth", settings = list(BoxCox=FALSE)),
			  SibReg_Simple = list(model= "SibRegSimple", settings = NULL),
			  SibReg_LogPower = list(model= "SibRegLogPower", settings = NULL)
				)





test.boot.outlist <- NULL

ptm <- proc.time() # start the timer
pdf("../OUTPUT/TEST_Bootstrapped_Forecasts.pdf",onefile=TRUE,width=11,height=8.5)

for(type.boots in c("meboot","stlboot")){

print("-------------")
print(type.boots)
print("-------------")

par(mfrow=c(3,2))
for(i in 1:length(models.list)){

model.do <- models.list[[i]]

print(names(models.list)[i])


test.boot <- doBoot(data= data.prep, args.fitmodel= model.do ,
					args.calcfc = list(fc.yr= 2018,  settings = NULL),
					args.boot = list(boot.type=type.boots, boot.n=num.boots, plot.diagnostics=FALSE),
					full.out = FALSE)


test.boot.outlist[[paste(names(models.list)[i],type.boots,sep="_")]] <- test.boot

box.plot(as.list(test.boot),y.lab = "Forecast Abundance",fill.vec = "lightblue" ,border.vec= "darkblue",
				labels=TRUE,violin=TRUE,y.lim=fc.ylim)

title(main= names(models.list)[i])

title(main = type.boots	, outer=TRUE,line=-2,cex.main=1.8, col="darkblue")

} # end looping through models
} # end looping through bootstrap types

dev.off()

proc.time() - ptm # check the time



######################

#this reformats test.boot.outlist by grabbing each age column from the model specific output and putting ages in their own sublist.
ncol.val <- ncol(test.boot.outlist[[1]])

dat.test <- lapply(1:ncol.val, function(columnindex, test.boot.outlist){
	lapply(test.boot.outlist, function(dat.df, columnindex){
    dat.df[,columnindex]
	}, columnindex)
}, test.boot.outlist)

names(dat.test) <- names(test.boot.outlist[[1]])
str(dat.test)


names(dat.test)
dat.test[[2]]

############################################


# plot by age across FC


source.modules("../R/")

age.classes <- names(test.boot.outlist[[1]])

ptm <- proc.time() # start the timer
pdf("../OUTPUT/TEST_Bootstrapped_Forecasts_Plot2.pdf",onefile=TRUE,width=11,height=8.5)

par(mai=c(3,1,2,1))

for(boots.plot in c("meboot","stlboot")){

for(age.plot in age.classes){

print("----")
print(boots.plot)
print(age.plot)

# sub.idx <- grep(boots.plot,names(dat.test[[age.plot]])) # NOT WORKING

ylim.use <- c(0,max(unlist(dat.test[[age.plot]])))
box.plot(dat.test[[age.plot]],y.lab = "Forecast Abundance",fill.vec = "lightblue" ,border.vec= "darkblue",
				labels=FALSE,violin=TRUE,y.lim=ylim.use,labels.angle = 45)

title(main=age.plot)

}

}


dev.off()

########################


source.modules("../R/")
data.raw <- read.csv("../inst/extdata/FinalSampleFile_WithAge_exclTotal.csv",stringsAsFactors=FALSE)
data.prep <- prepData(data.raw,out.labels="v2")


calcInterval(dat.prepped = data.prep, 
					args.fitmodel= list(model= "Naive", settings = list(avg.yrs=3)),
					args.calcfc = list(fc.yr= 2018,  settings = NULL),
					args.boot = list(boot.type="meboot", boot.n=100, plot.diagnostics=FALSE)
					)








