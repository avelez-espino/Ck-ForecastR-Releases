# read in the functions
dir.use <- "../R/n3"
pattern.list <- c("_functions.r") #use ignore.case below

for(pattern.use in pattern.list){
	fn.file.list <- list.files(path=dir.use, pattern=pattern.use, ignore.case = TRUE, full.names = TRUE) # get all .R files 
	#print(fn.file.list)
	print("-------")
	for(file.source in fn.file.list){
		print(paste("Sourcing: ",file.source))
		source(file.source)
		} # end looping through files
	} # end looping through patterns




# read in the data file
data.readin <- read.csv("../inst/extdata/SampleFile_WithAge.csv", header=TRUE, as.is=TRUE)
data.readin

# apply the pre-processing step-> works, but gives a warning from the merge() step
# Leave as is for now, but fix or suppress later
# NOTE: using the naiveone throughout, assuming same
data.preprocess <- datalist.naiveone.pre(data.readin)
data.preprocess 


# apply the data processing step
# NOTE: using the naiveone throughout, assuming same
data.input <- datalist.naiveone(data.preprocess$output , data.preprocess$specs$forecastingyear)
data.input

# Summary plot of input data -> works, but had to modify fn ab bit, to also work without the internal call for  n1$stockabundance 
# NOTE: using the naiveone throughout, assuming same
plot.data.naiveone(data.input,abd=data.preprocess$specs$stockabundance)


# fit the model -> works
# Notes below from naiveone -> need to checl whether they apply here as well
# but why does it give "original data" and "model data" in output list, when they are both the same? Consistency with other models?
# Note: this produces a point estimate and an interval  Lo80 and Hi80 using the rwf() function from the {forecast} package
# Help page for rwf() states: rwf() returns forecasts and prediction intervals for a random walk with drift model applied to y. 
#                             This is equivalent to an ARIMA(0,1,0) model with an optional drift coefficient. 
# Note that the actual function call is rwf(series, h=1, drift=FALSE, level=0.80)
# In contrast: avgthree.model() uses a subroutine avgthree() that "manually" calculates the 3yr running avg and residuals, but no intervals)
#              couldn't rwf() do a 3yr window?

n3.fit <- avgthree.model(data.input)
n3.fit


# extract the point forecasts -> works
n3.pointfc <- point.forecast.avgthree(data.input, n3.fit)
n3.pointfc

# plot the model fits -> works, but:
# a) had to modify fn ab bit, to also work without the internal call for  n1$stockabundance (same as for plot.data.naiveone)
# b) gives a warning about a missing value in the geom_path -> Leave as is for now, but fix or suppress later
plot.fitted.avgthree(n3.fit,abd=data.preprocess$specs$stockabundance)

# barplot of forecasts by age
# had to modify fn ab bit, to also work without the internal call for  n1$stockabundance (same as for plot.data.naiveone)
barplot.forecasted.values.individual.ages.avgthree(n3.fit, n3.pointfc, 1,abd=data.preprocess$specs$stockabundance)
barplot.forecasted.values.individual.ages.avgthree(n3.fit, n3.pointfc, 2,abd=data.preprocess$specs$stockabundance)
barplot.forecasted.values.individual.ages.avgthree(n3.fit, n3.pointfc, 3,abd=data.preprocess$specs$stockabundance)

# barplot of forecasts total -> NEED TO FIGURE OUT WHERE "results" object is coming from
#barplot.forecasted.values.total.age.naiveone(results, pointforecasts)


# plot the model diagnostics -> NOT WORKING. ggplot issue?
# assuming that i just selects one of the age classes (extracts that element from the list of all outputs
diagnostics.avgthree.model.fit(n3.fit,i=1)


# Bootstrap intervals - NOT WORKING
forecast.avgthree.modified.meboot(n3.fit, level=80, npaths=2000) 
forecast.avgthree.modified.stlboot(n3.fit, level=80, npaths=2000)

# Bootstrap intervals - NOT WORKING -> NEED TO MODIFY THIS FUNCTION BECAUSE CALLING ABOVE FN AS n3$etc
prediction.intervals.individual.ages.avgthree(n3.fit, bootmethod="stlboot", level=80, npaths=2000)



###############
# pdf test


pdf("PdfTest_naive1withage.pdf",onefile=TRUE,height=11,width=8.5)
plot.data.naiveone(data.input,abd=data.preprocess$specs$stockabundance)
plot.fitted.naiveone(n3.fit,abd=data.preprocess$specs$stockabundance)
barplot.forecasted.values.individual.ages.naiveone(n3.fit, n3.pointfc, 1,abd=data.preprocess$specs$stockabundance)
barplot.forecasted.values.individual.ages.naiveone(n3.fit, n3.pointfc, 2,abd=data.preprocess$specs$stockabundance)
barplot.forecasted.values.individual.ages.naiveone(n3.fit, n3.pointfc, 3,abd=data.preprocess$specs$stockabundance)
dev.off()
















