

# Load the function that does the model set-up and launches the GUI
source("../R/1_LaunchApp.R")


# Run the function to launch GUI locally
launchForecastR(local=TRUE)




# Run the function to just go to the server version 
# THIS DOES NOT USE THE LATEST LOCAL VERSION!
launchForecastR(local=FALSE)







