# VARIABLES/ CAPABILITIES TO ADD
# - change the model.use selection dynamically based on model.type using one of the methods in https://shiny.rstudio.com/articles/dynamic-ui.html
# - test alternative layout options: https://shiny.rstudio.com/articles/layout-guide.html
# - design pieces: https://rstudio.github.io/shinydashboard/structure.html
# - https://stackoverflow.com/questions/24240434/r-shiny-error-object-of-type-closure-is-not-subsettable



	# to dynamically modify the number of tabpanels is a it trickier
    # https://stackoverflow.com/questions/19470426/r-shiny-add-tabpanel-to-tabsetpanel-dynamically-with-the-use-of-renderui	
	# https://stackoverflow.com/questions/39276104/r-shiny-how-to-add-data-tables-to-dynamically-created-tabs	 
		

		
#	http://shiny.rstudio.com/articles/dynamic-ui.html	




	# Basic check of required programs and 64 vs32 bit installs (is this the place for this?)

	# check if Java is installed
	# as per https://stackoverflow.com/questions/14964457/check-if-a-program-is-installed

	# Check which R version ins being used (64 or 32 bit)
	# as per SBC CK DB extraction code


	# ALMOST WORKING
	#shinyFileChoose(input, "file.name.2", session=session,roots=c(wd="."))

	#observeEvent(input$file.name.2, {
	#		file.name.2 <- parseFilePaths(roots=c(wd='.'), input$file.name.2)
    #    })
	
	
########################################################	
	
		age4 <- reactive({ sample(4000,20)  })
	age5 <- reactive({ age4 + sample(800,20) })

  # this crashing because report.trigger is not recognized as a logical variable
  #report.trigger <- eventReactive(input$create.rep, {  TRUE  })
  #report.trigger <- observe(input$create.rep, {  TRUE  })
  #print(report.trigger)
  #if(isTRUE(report.trigger)){ forecastR_Main(input.obj=input) 	}

 # TESTING
 	#file.name <- reactive({input$file.name})
 	observeEvent(input$test.button, {
					write.csv(matrix(1:6,ncol=2), file="Test.csv")
							})


	# Shiny Files version: not working
	#shinyFileChoose(input,"file.name.2", session=session,roots=c(wd="."))

	#observeEvent(input$file, {
	#		inFile <- parseFilePaths(roots=c(wd='.'), input$file.name.2)
	#		load(as.character(inFile$datapath), envir=.GlobalEnv)
    #})

	#data.file <- reactive({ read.csv(input$file.name.2,stringsAsFactors=FALSE)})
	
	
	
#########################################################


	# TO INCLUDE / TRY OUT (May not have to, because doing context sensitive filtering above)
	# link the year sliders on different tabs together ? (so that have to filter only once?)
	# https://shiny.rstudio.com/reference/shiny/latest/updateSliderInput.html
	# https://github.com/rstudio/shiny/issues/867
	
	
	
	
		#read in data file  # OLD WAY
	#data.file <- reactive({ read.csv(input$file.name,stringsAsFactors=FALSE)})
	#test.input <- list(model.type == "WithAge")
	#forecastR_Main(input.obj=test.input)
   #forecastR_Main(input.obj=input)


	# TRIED TO DO IT OUTSIDE THE INDIV FUNCTIONS, BUT SOME STEP NOT WORKING
	# DO IT BELOW INSIDE EACH PLOT/TABLE FOR NOW< AND FIX LATER ->  this works for now, but need to figure out more graceful handling of reactives 
	# As it is currently, the whole fitting process is repeated for each plot and table!!!
   
   # Pre-process the data (e.g. extract FC year and variable names)
   #data.preprocess <- reactive({
	#		if(input$model.use.precheck.withage=="n1.model"){datalist.naiveone.pre(data.file)}
				# data pre-process for other models to be added
	#		})
   
    # Process the input file using the legacy functions
	#data.input <- reactive({ 
	#	data.preprocess.tmp <- data.preprocess()	
	#	if(input$model.use.precheck.withage=="n1.model"){datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	}
	#	# data prep for other models to be added
	#	})
	
	
	###########################################################
	
	
	     # this is just a specific test of the method for passing info back and forth
	 # the actual function will need to be a lot more general to avoid replication
     output$fc.plot.1 <- renderPlot({

			x.full <- data.file()[,"Run_Year"]
			y.full <- data.file()[,"Average_Escapement"]
			fc.yr <- input$fc.yr.precheck.withoutage


			use.range <- input$yr.range.precheck.withoutage
			use.idx <-  x.full >= min(use.range) & x.full <= max(use.range)

			avg.ret.idx <- x.full >= (max(use.range)- input$avg.ret.numyrs)   & x.full <= max(use.range)
			avg.ret.yrs <- x.full[avg.ret.idx]
			avg.ret.fc <- mean(y.full[avg.ret.idx])

			plot(x.full,y.full,xlab="Run Year",ylab="Total Escapement", bty="n",pch=21,
					col="darkblue",bg="white",cex=1.3,xlim=c(min(use.range,x.full,fc.yr),max(use.range,x.full,fc.yr)))

			points(x.full[use.idx],y.full[use.idx], pch=21, col="darkblue",bg="lightgrey",cex=2)
			lines(avg.ret.yrs,rep(avg.ret.fc,length(avg.ret.yrs)) ,col="red",lwd=2)
			points(avg.ret.yrs,y.full[avg.ret.idx], pch=21, col="red",bg="red",cex=2)
			points(fc.yr,avg.ret.fc ,pch=23,col="red",bg="red",cex=5)



      })
	  
	  
	  ######################################################
	  
	  	# plot sample
	# output$fit.plot <- 	renderPlot({
	#		   				par(pty="s")
	#			age4 <- sample(4000,20)
	#			age5 <- age4 + sample(800,20)
	#			plot(age4,age5,xlab="Age4",ylab="Age5", bty="n",pch=21,col="darkblue",bg="lightgrey")
	#			abline(lm(age5~age4),col="red")
	#			})
	
	
	
	
	
	###############################################
	
	   	output$precheck.plot.data <- renderPlot({
	     		 
			data.file.tmp <- data.file()	 


			# all these will be replace with generic data plot function, once it is ready	
			# why would they be different? look the same in quick check
			# using the n1 version that I modified to work outside env (abd=NULL argument)
			
			#if(input$model.use.precheck.withage %in% c("n1.model","n3.model","n5.model")){
					data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
					data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
					plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance)
			#		}
	
				
			
   
		})
	
	
	
	######################################################################
	
	   
   
   
	output$precheck.plot.fit1  <- renderPlot({
	
		data.file.tmp <- data.file()	
	
		# so far the datalist.XYZ.pre() and datalist.XYZ functions seem identical
		# therefore have not made all the corresponding changes in the other ones
		# just using the naiveone version for now, then will replace with generic function 
		# when it is ready`
	
		data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
		data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)
	
		plot.out <- plot(1:5,1:5)			
					
					
				
				
		plot.out
		
		
	
	})
   
   
   
   
   
 	output$precheck.plot.fit2  <- renderPlot({
	
		data.file.tmp <- data.file()	
	
		age.class.tmp <- match(input$precheck.withage.ageclass, ages.menu.list)
	
		data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
		data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
	
		plot.out <- plot(1:5,1:5)			
					
					
		plot.out
	
	})  
   
   
##################################################################################


