# load in the data wrangling functions
source("../R/3d_HelperFunctions_DataWrangling.R")

# Test converter.fun()

sample.withage <- read.csv("DATA/SampleFile_WithAge.csv",stringsAsFactors=FALSE)
sample.withoutage <- read.csv("DATA/SampleFile_WithoutAgev2.csv",stringsAsFactors=FALSE)

file.test <- sample.withage
out.filename.test <-  "OUTPUT/ConverterTest_InputWithAge.csv"
test <- converter.fun(file.use =  file.test, out.filename = out.filename.test)   
test 

# => verified calcs in excel!

