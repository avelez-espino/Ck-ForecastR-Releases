
###############################################################
# RUNNING THE FULL SEQUENCE FOR MULTIPLE MODELS


#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")
require(forecast)
require(meboot)

# Inputs
data.use <- read.csv("../inst/extdata/SampleFile_WithAge.csv")  # read in raw data

settings.use <- list(Naive1 = list(model.type="Naive",settings=list(avg.yrs=1)),
				Naive3 = list(model.type="Naive",settings=list(avg.yrs=3)),
				Naive5 = list(model.type="Naive",settings=list(avg.yrs=5)),
				SibRegSimple = list(model.type="SibRegSimple",settings=NULL),
				SibRegLogPower =  list(model.type="SibRegLogPower",settings=NULL),
				SibRegKalman =  list(model.type="SibRegKalman",settings=NULL),
				TimeSeriesArimaBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=TRUE)),
				TimeSeriesArimaNoBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=FALSE)),
				TimeSeriesExpSmoothBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=TRUE)),
				TimeSeriesExpSmoothNoBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=FALSE))
				)



multiresults.ptfconly <- multiFC(data.file=data.use,settings.list=settings.use,
						do.retro=FALSE,do.boot=FALSE,out.type="short",
						retro.min.yrs=15,tracing=FALSE)
multiresults.ptfconly


source.modules("../R/")
multiresults.retro <- multiFC(data.file=data.use,settings.list=settings.use,
						do.retro=TRUE,do.boot=FALSE,out.type="short",
						retro.min.yrs=15,tracing=FALSE)


names(multiresults.retro)

names(multiresults.retro$retro.pm)
multiresults.retro$retro.pm
names(multiresults.retro$table.ptfc)
multiresults.retro$table.ptfc

multiresults.retro[["retro.pm"]][["retro.pm.bal"]]

multiresults.retro.full <- multiFC(data.file=data.use,settings.list=settings.use,
						do.retro=TRUE,do.boot=FALSE,out.type="full",
						retro.min.yrs=15,tracing=FALSE)

names(multiresults.retro.full)

names(multiresults.retro.full$retro.details)

names(multiresults.retro.full$retro.details$SibRegLogPower)
names(multiresults.retro.full$retro.details$SibRegLogPower$retro)
names(multiresults.retro.full$retro.details$SibRegLogPower$retro$retro.fits)
names(multiresults.retro.full$retro.details$SibRegLogPower$retro$retro.fits$FC2007)
names(multiresults.retro.full$retro.details$SibRegLogPower$retro$retro.fits$FC2007$"Age 6")
multiresults.retro.full$retro.details$SibRegLogPower$retro$retro.fits$FC2007$"Age 6"



