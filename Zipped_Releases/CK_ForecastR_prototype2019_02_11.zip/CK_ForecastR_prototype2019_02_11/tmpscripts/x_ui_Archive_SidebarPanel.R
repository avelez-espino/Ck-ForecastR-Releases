
# VARIABLES/ CAPABILITIES TO ADD
# - change the model.use selection dynamically based on model.type using one of the methods in https://shiny.rstudio.com/articles/dynamic-ui.html
# - test alternative layout options: https://shiny.rstudio.com/articles/layout-guide.html


stk.list <- c("Stock 1","Stock 2","Stock 3","Stock 4")

model.type.list <- c("WithAge","WithoutAge")

fc.model.list <- c("Sibling - SimpleReg1","Sibling - SimpleReg2",
				"Sibling - LogPowerReg1","Sibling - LogPowerReg2",
				"Sibling - ComplexReg1","Sibling - ComplexReg2",
				"Return - ExpSmoothing", "Return - Naive 1yr",
				"Return - Naive 3yr", "ABC")
				
boots.method.list <- c("Option 1", "Option 2")
			
			
			
report.type.list <- c("Word - Short","Word - Long", "Pdf - Long")			
				
				

pageWithSidebar(
  headerPanel("ForecastR"),
    
  sidebarPanel(
	selectInput("stk.use", "Stock", stk.list,selected=stk.list[1]),
	selectInput("model.type", "Model Type", model.type.list,selected=model.type.list[1]),
	 selectizeInput("model.use", "FC Model", choices = fc.model.list, multiple = TRUE ,selected=fc.model.list[4]),
    selectInput("boots.method", "Bootstrap Method", boots.method.list,
                selected=boots.method.list[1]),
	fileInput("file.in", "Choose Input File (not linked)", accept = c( "text/csv", "text/comma-separated-values,text/plain", ".csv")),
	sliderInput("yr.range", "Years", min = 1960, max = 2020, value = c(1995,2007)),	numericInput("boots.size", "Bootstrap Sample", 2000,
                 min = 1000, max = 10000),
	actionButton("store.settings", "Store Settings"),
		selectInput("rpt.type", "Report Type", report.type.list, selected=report.type.list[1]),
	# submitButton pauses everything until pressed	
	# actionButton more flexible
	# examples see:
	#  use as in https://github.com/rstudio/shiny-examples/blob/master/082-word-cloud/server.R	   
	# http://shiny.rstudio.com/articles/action-buttons.html
	# https://shiny.rstudio.com/reference/shiny/1.0.5/actionButton.html	
	textInput("file.name", "File Name", value = "Test_File.csv", placeholder = "Enter a file name"),
	actionButton("test.button", "Test: Create File")	

				 
		) # end sidebar
  ,
   

     mainPanel(

        tabsetPanel(type = "tabs", id="main.panel", selected ="Settings",
                  tabPanel("Fit Diagnostics", plotOutput("fit.plot")),
                  tabPanel("Settings",  tableOutput("settings.table"))
				)

		) # end main panel
  )


  
    
  
