datafile_extract_age_class <- function(datafile, stockabundance){

    forecastingyear <- as.numeric(datafile$Forecasting_Year[1])
    datafilesub <- datafile

    stockname <- datafile$Stock_Name[1]
    extract_ages <- sort(unique(datafilesub$Age_Class))

    tmpvar <- list()
    for (i in 1:length(extract_ages)){
         if (stockabundance=="Terminal Run"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Terminal_Run")]
           names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Terminal_Run"] <- paste0("Age","_",extract_ages[i])
         }

         if (stockabundance=="Escapement"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Escapement")]
            names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Escapement"] <- paste0("Age","_",extract_ages[i])
         }

         if (stockabundance=="Production"){
           tmpvar[[i]] <- subset(datafilesub, Age_Class==extract_ages[i])[,c("Run_Year","Brood_Year","Average_Production")]
            names(tmpvar[[i]])[names(tmpvar[[i]])=="Average_Production"] <- paste0("Age","_",extract_ages[i])
         }

    }

    names(tmpvar) <- paste("Age", extract_ages)

    return(tmpvar)

}#END datafile_extract_age_class



prepare_data_and_model_formulas_simplelogpower <- function(datafile_variables){
	# prepare data and model formulas for simple log power regressions without environmental covariates
  # http://stackoverflow.com/questions/4951442/formula-with-dynamic-number-of-variables
  # mylist.names <- names(datafile_variables)
  # mylist <- vector("list", length(mylist.names)-1)
  # names(mylist) <- mylist.names[-1]

   mylist <- rep(list(list()),length(names(datafile_variables))-1)

   for (i in 2:length(datafile_variables)){
   	# i is used to index the outcome variables (so it excludes the youngest age outcome)
        outcome_data <- datafile_variables[[i]]
        names(outcome_data)[names(outcome_data)=="Run_Year"] <- paste0("Run_Year","_",names(outcome_data)[length(names(outcome_data))])

        predictor_data <- list()
        for (j in 1:(i-1)){
          predictor_data[[j]] <- datafile_variables[[j]]
          names(predictor_data[[j]])[names(predictor_data[[j]])=="Run_Year"] <-
            paste0("Run_Year","_",names(predictor_data[[j]])[length(names(predictor_data[[j]]))])
        }

        mylist[[i-1]]$outcome_data <- outcome_data
        mylist[[i-1]]$predictor_data <- predictor_data

    } # end for i

    names(mylist) <- names(datafile_variables)[-1]

    ## build model formulas for each applicable age class,
    ## as well as provide data set to be used for each formula

    ## myres <- list(list())

    myres <- rep(list(list()),length(mylist))

    for (k in 1:length(mylist)){    # k indexes the outcome variables, so it excludes the youngest age outcome

         mylength <- length(mylist[[k]]$predictor_data)

         outcome_name <- names(mylist[[k]]$outcome_data)[3]

         predictor_names <-  unlist(lapply(mylist[[k]]$predictor_data, function(ll) {names(ll)[3]}))

         predictor_names  <- rev(predictor_names)


         for (l in 1:length(predictor_names)){

             model_formulas <- list()
             for (j in 1:l){

                 outcome_variable <- subset(mylist[[k]]$outcome_data, select=outcome_name)
                 zeroes_in_outcome_variable <- length(outcome_variable[outcome_variable==0]) # equals zero when we have no zeroes in the outcome variable
                 ln_outcome_variable <- ifelse(zeroes_in_outcome_variable==0,"log", "log1p")

                 tmp <- predictor_names[1:(l-j+1)]

                 ln_predictor_variables <- NULL
                 for (v in 1:length(tmp)){

                      A <- sapply(mylist[[k]]$predictor_data,"[[",tmp[v])
                      B <- A[!sapply(A, is.null)]
                      C <- unlist(B)
                      C
                      zeroes_in_predictor_variable <- length(C[C==0])  # equals zero when we have no zeroes in the predictor variable

                      D <- ifelse(zeroes_in_predictor_variable==0,"log", "log1p")
                      ln_predictor_variables <- c(ln_predictor_variables,D)
                 } # end for v



                 model_formulas[[j]] <- as.formula(paste(paste0(ln_outcome_variable,"(",outcome_name,")"),"~","1","+",
                                                   paste(paste0(ln_predictor_variables ,"(",predictor_names[1:(l-j+1)],")"),collapse="+")))
             } # end for j

         }  # end for l

         model_formulas <- rev(model_formulas)

         model_formulas

         usePackage("BBmisc")

         model_formulas <- getFirst(model_formulas)  # extract first formula only for simple log power regression

         str(model_formulas)

         #### if (k >= 2) {
         #### for (kk in 2:length(predictor_names)){


         ####   tmp <- predictor_names[1:kk]
         ####   MM <- data.frame(Brood_Year=forecastingyear-1)
         ####   for (v in 1:length(tmp)){
         ####        print(v)
         ####        AA <- sapply(mylist[[k]]$predictor_data,"[[",tmp[v])
         ####        AA <- unlist(AA[!sapply(AA, is.null)])
         ####         AA
         ####        BB <- sapply(rev(mylist[[k]]$predictor_data),"[[","Brood_Year")[v]
         ####        BB <- unlist(BB)
         ####
         ####        CC <- cbind.data.frame(BB,AA)
         ####        names(CC) <- c("Brood_Year", tmp[v])
         ####        print(head(CC))
         ####        print(tail(CC))
         ####        MM <- merge(MM,CC, by="Brood_Year",all=TRUE)
         ####   }
         ####
         ####   MM # stores all of the predictors needed for the I() transformation;
         ####      # now we need to compute the sum of these predictors and
         ####      # see if any of the sum values are equal to zero
         ####
         ####   SS <- rowSums(MM[,-1]) # sum of predictor variables included in the I() transformation
         ####   SS <- SS[!is.na(SS)]
         ####
         ####   zeroes_in_sum_of_predictor_variable <- length(SS[SS==0])  # equals zero when we have no zeroes in the sum of predictor variables
         ####
         ####   DD <- ifelse(zeroes_in_sum_of_predictor_variable==0,"log", "log1p")
         ####   ln_sum_of_predictor_variables <- DD
         ####
         ####   model_formulas[[length(predictor_names)+kk-1]] <-
         ####   as.formula(paste(paste0(ln_outcome_variable,"(",outcome_name,")"),"~","1","+",
         ####             ln_sum_of_predictor_variables,"(",paste(predictor_names[1:kk],collapse="+"),")"))
         ####
         ####             # paste0(ln_predictor_variables
         #### }
         #### }


         #### ## model_formulas <- rev(model_formulas)

         print(model_formulas)

         myres[[k]]$model_formulas <- model_formulas

         ## come back here: http://stackoverflow.com/questions/22955617/linear-models-in-r-with-different-combinations-of-variables
         ## predictor_variables <- c("factor1","factor2")
         ## as.formula(paste("y~",paste(listofvariables,collapse="+")))

    }

    names(myres) <- names(datafile_variables)[-1]

    mymerge <- list()
    for (i in 1:length(mylist)){
        tmpmerge <- mylist[[i]]$outcome_data
        for (j in length(mylist[[i]]$predictor_data):1) {
            tmpmerge <- merge(tmpmerge, mylist[[i]]$predictor_data[[j]], by="Brood_Year", all=FALSE)
        }
        mymerge[[i]] <- tmpmerge
    }

    names(mymerge) <- names(datafile_variables)[-1]

    results <- list(model_data=mymerge, model_formulas=myres)

    return(results)

}#END prepare_data_and_model_formulas_simplelogpower


simplelogpower_regression_model_fits <- function(data_and_model_formulas_simplelogpower){

    data_and_model_formulas <- data_and_model_formulas_simplelogpower
    ## fits <- rep(list(list()),length(data_and_model_formulas[[1]]))
    fits <- vector("list",length(data_and_model_formulas[[1]]))
    names(fits) <- names(data_and_model_formulas[[1]])

    for (i in 1:length(data_and_model_formulas[[1]])){
          fits[[i]] <-  lm(formula=data_and_model_formulas$model_formulas[[i]]$model_formulas, data=data_and_model_formulas$model_data[[i]])
}
   res <- list(model_data=data_and_model_formulas$model_data,
                model_formulas=data_and_model_formulas$model_formulas,
                model_fits=fits)

    return(res)
}#END simplelogpower_regression_model_fits