# This file is a temporary bridge between old code and new streamlined code
# For now, there are two steps here:
# Step 1: define the functions by copying one of the existing versions (assuming they are the same)
# Step 2: create the copies with the old function names from  that common source
# Eventually, step 1 will be replace with a new common function
# However, the reassignments in Step 2 will need to stay active 
# until the old report generation code has been replaced.
# THIS SCRIPT NEEDS TO BE SOURCED AT THE BEGINNING OF server.R
# NOTE that when running the old report generation scripts, these function assignments
# get overwritten by a call to "source()" (for now, during the transition period)


# STEP 1

datalist <- datalist.naiveone



# STEP 2
datalist.avgthree <- datalist.general
datalist.naiveone <- datalist.general