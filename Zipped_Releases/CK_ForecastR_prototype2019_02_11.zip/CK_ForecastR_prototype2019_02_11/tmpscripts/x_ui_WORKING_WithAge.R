
# VARIABLES/ CAPABILITIES TO ADD
# - change the model.use selection dynamically based on model.type using one of the methods in https://shiny.rstudio.com/articles/dynamic-ui.html
# - test alternative layout options: https://shiny.rstudio.com/articles/layout-guide.html
# - design pieces: https://rstudio.github.io/shinydashboard/structure.html
# - https://stackoverflow.com/questions/24240434/r-shiny-error-object-of-type-closure-is-not-subsettable

stk.list <- c("Stock 1","Stock 2","Stock 3","Stock 4")

# NOT USED AT MOMENT (SET BASED ON BUTTON)
model.type.list <- c("WithAge","WithoutAge")


# For now, exactly replicate the existing list of  model options
# During re-design, need to fix the fundamental structure 
# e.g. naive n.yr, rather than n1, n3, n5

fc.model.list.withage <-  c("n1.model","n3.model","n5.model","ARIMA.model","EXPSMOOTH.model",
						"SIMPLESIBREG.model","SIMPLELOGPOWER.model")
fc.model.list.withoutage <- c("noagemodelnaiveone","noagemodelavgthree","noagemodelavgfive",
								"noagemodelarima","noagemodelexpsmooth")
						
						

#fc.model.list.withage <- c("Sibling - SimpleReg1","Sibling - SimpleReg2",
#				"Sibling - LogPowerReg1","Sibling - LogPowerReg2",
#				"Sibling - ComplexReg1","Sibling - ComplexReg2",
#				"Return - ExpSmoothing","Return - Naive 1yr","Return - Naive 3yr","Return - Naive 5yr")
			
#fc.model.list.withoutage <- c("Return - ExpSmoothing","Return - Naive 1yr","Return - Naive 3yr", "Return - Naive 5yr","ABC")

				
			

				
				
				
boots.method.list <-  c("meboot", "stlboot") #meboot = max entropy, stlboot = loess")
			
			
			
report.type.list <- c("Pdf - Key Plots Only","Pdf - Long","Word - Short","Word - Long")			
				
navbarPage("ForecastR",

 tabPanel("Basic Settings",
  
  
  

pageWithSidebar(
  headerPanel("Basic Settings"),
    
  sidebarPanel(
			  tags$h4("Program Set-Up"),
			  actionButton("Rpacks.button", "Check/Install R Packages"),
			  actionButton("SoftwareChecklist.button", "Software Checklist"),
			  actionButton("Manual.button", "Open Online Manual"),
			  tags$h4("Bootstrap Settings"),
			   selectInput("boots.method", "Bootstrap Method", boots.method.list,   selected=boots.method.list[1]),
				numericInput("B", "# of Bootstrap Samples", value=2500),
				numericInput("set.seed", "Random Seed", value=1700),
				tags$h4("Retrospective Settings"),
				numericInput("index.year", "Min # years for retrospective", value=20), 
				tags$h4("Box-Cox Transformation"),
				checkboxInput("boxcoxtransform", label="Do Box-Cox Transform (when applicable)", value = FALSE)
		) # end sidebar
  ,
   

     mainPanel(

	   tableOutput("settings.table")
	

		) # end main panel

  
  
  
  
  
  ) #end page with side bar for basic settings
  ),  # end end first tab panel
  
  tabPanel("Data Loading",
    
pageWithSidebar(
  headerPanel("Data Loading"),
    
  sidebarPanel(
			  tags$h4("Data File"),
			  shinyFilesButton("file.name.2", "File select", 'Please select a file', multiple=FALSE)	,  
			  textInput("file.name", "File Name", value = "Data/SampleFile_WithAge.csv", placeholder = "Enter a file name")
			  
		) # end sidebar
  ,
   

     mainPanel(			
	     
			div(style = 'overflow: scroll', tableOutput("inputheader.table"),height = "400px")
			
	   
		) # end main panel
  
		) #end page with side bar for  data loading
  ),  # end  second tab panel
    

#################### MODEL PRE CHECK ######################################	
  navbarMenu("Model Pre-Check",
  
  
### Model Pre-Check With Age  
    tabPanel("With Age", value= "precheck.withage",

	pageWithSidebar(
	headerPanel("Pre-Check - With Age"),
    
	sidebarPanel(
		selectizeInput("model.use.precheck.withage", "FC Model", choices = fc.model.list.withage, selected=fc.model.list.withage[6]),
		numericInput("fc.yr", "FC Year", value=2018),
		sliderInput("yr.range.precheck.withage", "Data Years", sep="",min = 1960, max = 2020, value = c(1995,2017))	
			  
		) # end sidebar
  ,
   

     mainPanel(			
	     
		
	   
		) # end main panel
  
		) #end page with side bar for  data loading

		
		
	),


	
	
### Model Pre-Check Without Age 	
    tabPanel("Without Age", value= "precheck.withoutage",
	
	pageWithSidebar(
	headerPanel("Pre-Check - Without Age"),
    
	sidebarPanel(
	   	selectizeInput("model.use.precheck.withoutage", "x -FC Model", choices = fc.model.list.withoutage, selected=fc.model.list.withoutage[4]),
		numericInput("avg.ret.numyrs", "Avg Return Yrs", value=5,min=1),
		numericInput("fc.yr.precheck.withoutage", "FC Year", value=2018),
		sliderInput("yr.range.precheck.withoutage", "Years", sep="",min = 1960, max = 2020, value = c(1995,2017))	
			  
		) # end sidebar
  ,
   

     mainPanel(			
	     
		 plotOutput("fc.plot.1")	
	   
		) # end main panel
  
		) #end page with side bar for  data loading
	
	

		)		

	
	
	), 
# end Model Pre-Check
	
	
	
  navbarMenu("Reports",
 
 tabPanel("With Age",value= "report.withage",
  	pageWithSidebar(
	headerPanel("Report - With Age"),
    
	sidebarPanel("", value= "report.withage",
		selectizeInput("model.use.withage", "FC Model", choices = fc.model.list.withage, multiple = TRUE ,selected=fc.model.list.withage[6]),
		sliderInput("yr.range.withage", "Years", sep="",min = 1960, max = 2020, value = c(1995,2017)),
		selectizeInput("report.type.withage","Report Type",choices = report.type.list,selected=report.type.list[1]),
		actionButton("create.report.withage", "Create Report")
		),
		
	mainPanel(			
	     
		 textOutput("fit.track")	
	   
		) # end main panel
  
		) #end page with side bar for  report with age
		
	), # end tabpanel for report with age
		
  tabPanel("Without Age",value= "x" #,
	
	
	   
	
	
	
	) #end tab panel for report without age
	
	
	)	
	
	
) # end navbar Page


