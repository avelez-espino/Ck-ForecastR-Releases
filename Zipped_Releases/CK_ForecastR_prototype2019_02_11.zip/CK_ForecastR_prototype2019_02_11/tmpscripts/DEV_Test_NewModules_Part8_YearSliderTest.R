# PREP DATA SET
# this replicates the steps at the beginning of the server.R


data.file.tmp <- read.csv("../inst/extdata/SampleFile_WithAge.csv")
names(data.file.tmp)

settings.cols <- c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")
settings.tmp <- data.file.tmp[,settings.cols]
data.use <- data.file.tmp[,!(dimnames(data.file.tmp)[[2]] %in% settings.cols)]
		
yrs.window.full <- min(data.use$Run_Year) : max(data.use$Run_Year)
yrs.window.trimmed <- 1997 : 2017

records.keep.full <-  data.use$Run_Year %in% yrs.window.full
records.keep.trimmed <-  data.use$Run_Year %in% yrs.window.trimmed

data.use.full <- data.use[records.keep.full,]
data.use.full <- cbind(settings.tmp[1:dim(data.use.full)[1],],data.use.full)

data.use.trimmed <- data.use[records.keep.trimmed,]
data.use.trimmed <- cbind(settings.tmp[1:dim(data.use.trimmed)[1],],data.use.trimmed)



# USE FULL DATA SET
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")

# prep dat for model fitting
sample.dat.full <-  prepData(data.use.full,out.labels="v2")

# fit the models -> All Model Types Work

# Naive
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat.full$data, settings = list(avg.yrs=3),tracing=FALSE)

# Time Series
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat.full$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat.full$data, settings = list(BoxCox=FALSE),tracing=FALSE)

# Sib Reg
sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat.full$data, settings = NULL,tracing=FALSE)
sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat.full$data, settings = NULL,tracing=FALSE)
sample.fit.sibregkalman <- fitModel(model= "SibRegKalman", data = sample.dat.full$data, settings = NULL,tracing=FALSE)









# USE TRIMMED DATA SET
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")

# prep dat for model fitting
sample.dat.trimmed <-  prepData(data.use.trimmed,out.labels="v2")

# fit the models

# Naive -> work
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat.trimmed$data, settings = list(avg.yrs=3),tracing=FALSE)

# Time Series -> work
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat.trimmed$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat.trimmed$data, settings = list(BoxCox=FALSE),tracing=FALSE)

# Sib Reg -> WORKS
sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat.trimmed$data, settings = NULL,tracing=FALSE)
sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat.trimmed$data, settings = NULL,tracing=FALSE)
sample.fit.sibregkalman <- fitModel(model= "SibRegKalman", data = sample.dat.trimmed$data, settings = NULL,tracing=FALSE)












