# Script to test new modules PART 9: Bootstrap

#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


# load packages
require(meboot)
require(forecast)

#read in data set
data.raw <- read.csv("../inst/extdata/FinalSampleFile_WithAge_exclTotal.csv",stringsAsFactors=FALSE)
data.prep <- prepData(data.raw,out.labels="v2")



# ----------------------------------
# Test Subroutine createBoots()
# ----------------------------------

series.use <- data.prep$data$"Age 5"[,"Age_5"]

# source the required subroutines
source("../R/Module_Sub_boot_me.R")
source("../R/Module_Sub_boot_stl.R")
source("../R/Module_Sub_boots_functions.R")


# mini test of Box Cox
tmp.series <- matrix(1:100,ncol=10)
BoxCox(tmp.series,0.857)
InvBoxCox(BoxCox(tmp.series,0.857),0.857)




pdf("../OUTPUT/TEST_TimeSeriesBootstrapComparison.pdf",onefile = TRUE)
par(mfrow=c(2,1))

source.modules("../R/")
test.meboot <- bootSeries(series = series.use, boot.type = "meboot", boot.n = 1000 , plot.diagnostics = TRUE,plot.type = "sample" )
test.stlboot <- bootSeries(series = series.use, boot.type = "stlboot", boot.n = 1000 , plot.diagnostics = TRUE, plot.type= "sample" )

ylim.use <- c(0, max(unlist(c(test.meboot$series.boot,test.stlboot$series.boot))))


for(i in seq(1,991,by=10)){

x.vec <- 1:length(series.use)

par(mfrow=c(2,1))

plot(x.vec,test.meboot$series.boot[,i],type="l",col="red",main="meboot",ylab="Value",xlab="Year",ylim=ylim.use)
for(j in 1:9){lines(x.vec,test.meboot$series.boot[,i+j],type="l",col="red")}

plot(x.vec,test.stlboot$series.boot[,i],type="l",col="red",main="stlboot",ylab="Value",xlab="Year",ylim=ylim.use)
for(j in 1:9){lines(x.vec,test.stlboot$series.boot[,i+j],type="l",col="red")}


title(main=paste("Set of 10 starting with ",i),outer=TRUE,line=-1)


}



dev.off()

		
##################


# Test for GUI
source.modules("../R/")

par(mfrow=c(2,2))
plotBootSeries(data.prep$data, boot.type = "stlboot", age.which="Age 5")










###########
		

# ----------------------------------
# Test Subroutine fitModelandcalcFC()
# ----------------------------------		
		

source.modules("../R/")	


# test on a single data object 




sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = data.prep$data, settings = list(BoxCox=FALSE),tracing=FALSE)
calcFC(fit.obj= sample.fit.arima,data = sample.dat$data, fc.yr= 2018, settings = NULL, tracing=TRUE)	

sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = data.prep$data, settings = list(BoxCox=FALSE),tracing=FALSE)
calcFC(fit.obj= sample.fit.expsmooth,data = sample.dat$data, fc.yr= 2018,  settings = NULL, tracing=TRUE)	


pt.fc.arima <- fitModelandcalcFC(data = data.prep$data, fitmodel.args =list(model= "TimeSeriesArima", settings = list(BoxCox=FALSE)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))

pt.fc.expsmooth <- fitModelandcalcFC(data = data.prep$data, fitmodel.args =list(model= "TimeSeriesExpSmooth", settings = list(BoxCox=FALSE)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))


pt.fc.naive3 <- fitModelandcalcFC(data = data.prep$data, fitmodel.args =list(model= "Naive", settings = list(avg.yrs=3)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))




# apply to a list of lists
data.prep




data.booted <- lapply(1:100, function(x,data.prep){data.prep$data},data.prep)


## Speed Test EXPSMOOTH ------------------------------

# lapply version
ptm <- proc.time()
lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "TimeSeriesExpSmooth", settings = list(BoxCox=FALSE)),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
proc.time() - ptm 


# loop version
ptm <- proc.time()
for(i in 1:length(data.booted)){
	fitModelandcalcFC(data = data.booted[[i]], fitmodel.args =list(model= "TimeSeriesExpSmooth", settings = list(BoxCox=FALSE)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))
}
proc.time() - ptm 







## Speed Test ARIMA -----------------------------------

# lapply version
ptm <- proc.time()
lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "TimeSeriesArima", settings = list(BoxCox=FALSE)),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
proc.time() - ptm 


# loop version
ptm <- proc.time()
for(i in 1:length(data.booted)){
	fitModelandcalcFC(data = data.booted[[i]], fitmodel.args =list(model= "TimeSeriesArima", settings = list(BoxCox=FALSE)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))
}
proc.time() - ptm 




## Speed Test NAIVE -----------------------------------

# lapply 
ptm <- proc.time()
lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "Naive", settings = list(avg.yrs=3)),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
proc.time() - ptm 


# loop version
ptm <- proc.time()
for(i in 1:length(data.booted)){
	fitModelandcalcFC(data = data.booted[[i]], fitmodel.args =list(model= "Naive", settings = list(avg.yrs=3)),
								calcfc.args = list(fc.yr= 2018,  settings = NULL))
}
proc.time() - ptm 




## Speed Test SIMPLE SIBREG -----------------------------------
# BUT NOTE: TECHNICALLY WON'T USE SIBREG ON BOOTSTRAPPED DATA (OR WILL WE?)

sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)

# lapply 
ptm <- proc.time()
lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "SibRegSimple", settings = NULL),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
proc.time() - ptm 


# loop version
ptm <- proc.time()
for(i in 1:length(data.booted)){
	fitModelandcalcFC(data = data.booted[[i]], fitmodel.args = list(model= "SibRegSimple", settings = NULL),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
}
proc.time() - ptm 







## Speed Test SIMPLE SIBREG -----------------------------------
# BUT NOTE: TECHNICALLY WON'T USE SIBREG LOGPOWER ON BOOTSTRAPPED DATA (OR WILL WE?)

sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)

# lapply 
ptm <- proc.time()
tmp.out <- lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "SibRegLogPower", settings = NULL),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))
proc.time() - ptm 


# loop version

out.mat <- matrix(NA, ncol= length(data.prep$data)+1 ,nrow = length(data.booted),
			dimnames = list( 1:length(data.booted),c(names(data.prep$data),"Total")))



ptm <- proc.time()
for(i in 1:length(data.booted)){

out.mat[i,] <-	unlist(fitModelandcalcFC(data = data.booted[[i]], fitmodel.args = list(model= "SibRegLogPower", settings = NULL),
							calcfc.args = list(fc.yr= 2018,  settings = NULL)))
}
proc.time() - ptm 




###############################################
# FOR THE GUI PRECHECK TAB



source.modules("../R/")



lapply(data.booted,  fitModelandcalcFC,fitmodel.args =list(model= "TimeSeriesArima", settings = list(BoxCox=FALSE)),
							calcfc.args = list(fc.yr= 2018,  settings = NULL))





		
		
		
		
		
		
		
		
