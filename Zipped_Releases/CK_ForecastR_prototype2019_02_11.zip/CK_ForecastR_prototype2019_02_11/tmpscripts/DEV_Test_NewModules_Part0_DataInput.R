# Script to test new modules PART 0: Data Input


# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


############################################################
# Read in Sample Data Files
############################################################


# list of all the input files to be tested

files.list <- c("../inst/extdata/FinalSampleFile_WithAge_exclTotal.csv",
			"../inst/extdata/FinalSampleFile_WithAge_inclTotal.csv",
			"../inst/extdata/FinalSampleFile_WithAge_exclTotal_covariates.csv",
			"../inst/extdata/FinalSampleFile_WithAge_exclTotal_covariates_FCYearCheck.csv",
			"../inst/extdata/FinalSampleFile_WithAge_inclTotal_covariates.csv",
			"../inst/extdata/FinalSampleFile_WithoutAge.csv",
			"../inst/extdata/FinalSampleFile_WithoutAge_covariates_FCYearCheck.csv",
			"../inst/extdata/FinalSampleFile_WithoutAge_NoAgeCol.csv",
			"../inst/extdata/FinalSampleFile_WithoutAge_NoAgeCol_covariates.csv")




# start looping through the files




for(i in 1:length(files.list)){

print("----------------------------------------------------------------------")


print(files.list[i])

tmp.file <- read.csv(files.list[i],stringsAsFactors=FALSE)

#print(names(tmp.file))
#print(head(tmp.file))

data.use.tmp <-  prepData(tmp.file,out.labels="v2")

print(data.use.tmp$specs)
print(data.use.tmp$data)
print(data.use.tmp$output.pre)

} # end looping through files



