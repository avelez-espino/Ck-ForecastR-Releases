dfretro <- data.frame(years=2000:2017,retropointforecasts=as.integer(runif(18,min = 10,1e4)))

dffor <- data.frame(forecastingyear=2017,pointforecast=5000)



require("ggplot2")

###
#this call works fine:
ggplot(data=dfretro, aes(x=years, y=retropointforecasts)) +
	geom_rect(data=dfretro,aes(xmax=years-1/3,
														 xmin=years+1/3,
														 ymax=retropointforecasts,
														 ymin=0),fill="dodgerblue3") +
	geom_text(data=dfretro,aes(x=years,
														 y=retropointforecasts,
														 label=paste(comma(round(dfretro$retropointforecasts)))),
						colour="dodgerblue3",angle=90,size=2.5,hjust=0,vjust=0.2) +

	# geom_rect(data=dffor, aes(xmax=forecastingyear-1/3,
	#         xmin=forecastingyear+1/3,
	#         ymax=pointforecast,
	#         ymin=0),fill="violetred2") +

	geom_text(data=dffor,aes(x=forecastingyear,
													 y=pointforecast,
													 label=paste(comma(round(dffor$pointforecast)))),
						colour="violetred2",angle=90,size=2.5,hjust=0,vjust=0.2)

#######################
#this has an error - but not the same as I'm dealing with in the bigger code set:
ggplot(data=dfretro, aes(x=years, y=retropointforecasts)) +
	geom_rect(data=dfretro,aes(xmax=years-1/3,
														 xmin=years+1/3,
														 ymax=retropointforecasts,
														 ymin=0),fill="dodgerblue3") +
	geom_text(data=dfretro,aes(x=years,
														 y=retropointforecasts,
														 label=paste(comma(round(dfretro$retropointforecasts)))),
						colour="dodgerblue3",angle=90,size=2.5,hjust=0,vjust=0.2) +

	geom_rect(data=dffor, aes(xmax=forecastingyear-1/3,
														xmin=forecastingyear+1/3,
														ymax=pointforecast,
														ymin=0),fill="violetred2", inherit.aes = FALSE) +
	geom_text(data=dffor,aes(x=forecastingyear,
													 y=pointforecast,
													 label=paste(comma(round(dffor$pointforecast)))),
						colour="violetred2",angle=90,size=2.5,hjust=0,vjust=0.2, inherit.aes = FALSE)
