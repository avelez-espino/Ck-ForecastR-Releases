
###############################################################
# RUNNING THE FULL SEQUENCE FOR MULTIPLE MODELS


#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")
require("forecast")
require(meboot)






########################################################################
# TEST 1: WITH AGE DATA



# Inputs
data.use <- read.csv("../inst/extdata/SampleFile_WithAge.csv")  # read in raw data

settings.use <- list(Naive1 = list(model.type="Naive",settings=list(avg.yrs=1)),
				Naive3 = list(model.type="Naive",settings=list(avg.yrs=3)),
				Naive5 = list(model.type="Naive",settings=list(avg.yrs=5)),
				SibRegSimple = list(model.type="SibRegSimple",settings=NULL),
				SibRegLogPower =  list(model.type="SibRegLogPower",settings=NULL),
				SibRegKalman =  list(model.type="SibRegKalman",settings=NULL),
				TimeSeriesArimaBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=TRUE)),
				TimeSeriesArimaNoBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=FALSE)),
				TimeSeriesExpSmoothBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=TRUE)),
				TimeSeriesExpSmoothNoBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=FALSE))
				)





multiresults.retro <- multiFC(data.file=data.use,settings.list=settings.use,
						do.retro=TRUE,do.boot=FALSE,out.type="short",
						retro.min.yrs=15,tracing=FALSE)


#--------------------------------------------------------------------------------
# in server.R
#multiresults.retro <- multiFC(data.file=data.file.tmp,settings.list=settings.use,
#						do.retro=TRUE,do.boot=FALSE,out.type="short",
#						retro.min.yrs=15,tracing=FALSE)
# multifit.out[["retro.pm"]][[input$retrotype.compare]]
# ranking.pm.use <- compare.rankingpm()
# multi.retro.obj <- compare.retropm.array()
# ranking.out <- rankmodels(dat = multi.retro.obj,columnToRank=ranking.pm.use, relative.bol=input$rel.bol)
#----------------------------------------------------------------------------------







#
source.modules("../R/")
retro.pm.types <- names(multiresults.retro$retro.pm)
ranking.pm.use <-   c("MRE","MAE","MPE","MAPE","MASE","RMSE")  # one or more of  "MRE","MAE","MPE","MAPE","MASE","RMSE", or a vector of indices? 1:3  #
scaled.ranking <- TRUE

for(retro.type in retro.pm.types){

print("----------------------------------------------------------------------------------------------------------------")
print(retro.type)

#print("input for ranking function -----------------------------------------------")
pm.array.use <- multiresults.retro$retro.pm[[retro.type]]
#print(pm.array.use)

ranking.out <- rankModels(dat = pm.array.use,columnToRank=ranking.pm.use, relative.bol=scaled.ranking)
print("output from ranking function -----------------------------------------------")
print(ranking.out)

} # end looping through retro types)



#################################







tableForecastRanking(pt.fc.in =  multiresults.retro$table.ptfc,bestmodel.in = ranking.out$bestmodel)







#




########################################################################
# TEST 2: WITHOUT AGE DATA




# Inputs
data.use <- read.csv("../inst/extdata/SampleFile_WithoutAge.csv")  # read in raw data

settings.use <- list(Naive1 = list(model.type="Naive",settings=list(avg.yrs=1)),
				Naive3 = list(model.type="Naive",settings=list(avg.yrs=3)),
				Naive5 = list(model.type="Naive",settings=list(avg.yrs=5)),
				TimeSeriesArimaBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=TRUE)),
				TimeSeriesArimaNoBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=FALSE)),
				TimeSeriesExpSmoothBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=TRUE)),
				TimeSeriesExpSmoothNoBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=FALSE))
				)





multiresults.retro <- multiFC(data.file=data.use,settings.list=settings.use,
						do.retro=TRUE,do.boot=FALSE,out.type="short",
						retro.min.yrs=15,tracing=FALSE)

retro.pm.types <- names(multiresults.retro$retro.pm)
ranking.pm.use <-   c("MRE","MAE","MPE","MAPE","MASE","RMSE")  # one or more of  "MRE","MAE","MPE","MAPE","MASE","RMSE", or a vector of indices? 1:3  #
scaled.ranking <- FALSE

for(retro.type in retro.pm.types){

print("----------------------------------------------------------------------------------------------------------------")
print(retro.type)

#print("input for ranking function -----------------------------------------------")
pm.array.use <- multiresults.retro$retro.pm[[retro.type]]
#print(pm.array.use)

ranking.out <- rankModels(dat = pm.array.use,columnToRank=ranking.pm.use, relative.bol=scaled.ranking)
print("output from ranking function -----------------------------------------------")
print(ranking.out)

} # end looping through retro types)







