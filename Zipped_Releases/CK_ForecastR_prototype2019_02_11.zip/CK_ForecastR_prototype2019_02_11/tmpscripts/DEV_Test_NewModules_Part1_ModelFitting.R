# Script to test new modules PART 1: Model Fitting


# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")








############################################################
# Read in Sample Data Files
############################################################

samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")
names(samplefile.withage)
head(samplefile.withage)


samplefile.withage.cov <- read.csv("../inst/extdata/SampleFile_WithAge_covariates.csv")
samplefile.withoutage <- read.csv("../inst/extdata/SampleFile_WithoutAge.csv")
samplefile.withoutage.cov <- read.csv("../inst/extdata/SampleFile_WithoutAge_covariates.csv")








############################################################
# prepData()
############################################################

source("../R/Module_prepData.R")
data.use.list <-  prepData(samplefile.withage,out.labels="v1")


#vs. prepData.off(        )

# alt labels needed to match different conponents of old code
# see notes at the beginning of "../R/Module_prepData.R"

names(data.use.list)
data.use.list

names(data.use.list$data)
data.use.list$data


data.use.list$output.pre




############################################################
# Inventory of Estimation Subroutines
############################################################


source("../R/Module_Sub_EstimationFunctions.R")

# models in inventory
names(estimation.functions)

# components for each model
names(estimation.functions$SibRegSimple)

# accessing a function
estimation.functions$SibRegKalman$datacheck

# using a function
model.tmp <- "SibRegSimple"
data.tmp <- 1:5
tmp.out <- estimation.functions[[model.tmp]]$datacheck(data.tmp)
tmp.out



##################################
# Generic Linear Model subfunction
##################################
source("../R/Module_Sub_EstimationFunctions.R")

pdf("../OUTPUT/TEST_LinearFitIllustration.pdf")

base.line <- seq(1:12)
rnd.vec <- base.line + rnorm(n=length(base.line),mean=0,sd=1)
data.rnd <- data.frame(x = rnd.vec, y = 8 + 2 *rnd.vec + rnorm(n=length(base.line),mean=0,sd=1.5))
data.rnd
plot(data.rnd,xlim=c(min(0,min(data.rnd$x)),max(data.rnd$x)),ylim=c(min(0,min(data.rnd$y)),max(data.rnd$y)), bty="n",pch=19,col="darkblue", cex=1.2)
abline(h=0); abline(v=0)

test.fit.basic <- lm.fit(formula.use = "y ~ x",data.use=data.rnd)
test.fit.plus1 <- lm.fit(formula.use = "y ~ 1 + x",data.use=data.rnd)
test.fit.minus1 <- lm.fit(formula.use = "y ~ - 1 + x",data.use=data.rnd)

abline(test.fit.basic,col="lightgrey",lwd=8) # looks for the "coefficients" list element
abline(test.fit.plus1,col="red",lty=1) 
abline(test.fit.minus1,col="red",lty=2) 
points(data.rnd,pch=19,col="darkblue", cex=1.2)

legend("right",legend=c("y ~ x","y ~ 1 + x","y ~ - 1 + x"),lty=c(1,1,2),lwd=c(3,1,1),bty="n",col=c("lightgrey","red","red"))

dev.off()



##################################
# Generic Naive Fit subfunction and estimation function
##################################
source("../R/Module_Sub_EstimationFunctions.R")

sample.dat <-  prepData(samplefile.withage,out.labels="v2")
data.in <- sample.dat$data$"Age 6"[,"Age_6"]
names(data.in) <- sample.dat$data$"Age 6"[,"Run_Year"]
data.in

naive.fit(data.in,avg.yrs = 3,method = "classic")


estimation.functions[["Naive"]]$estimator(model.data = data.in,avg.yrs=3)




############################
# Simple Sibling Regression
###########################


# NOTES
# datafile_extract_age_class() from  simple sibreg does the same as the 
# datalist.XYZ() from the naive models and the pre=code for that which is now in a new
# function	 datalist.XYZ.pre()
# However for SimpleSibReg (and SimpleLogPower?) the labels are different
# => handling all this in the new prepData() module, with an options on the labels.


sample.dat <-  prepData(samplefile.withage,out.labels="v2")
sample.dat$data

# ---------------------------------------
# replicate the calculation for one age class using the generic linear subfunction

source("../R/Module_Sub_EstimationFunctions.R")

x.source <- sample.dat$data$"Age 5"
y.source <- sample.dat$data$"Age 6"

yrs.match <- intersect(x.source[,"Run_Year"],y.source[,"Run_Year"]-1)
test.data <- data.frame(Age6 = y.source[y.source[,"Run_Year"] %in% (yrs.match+1),"Age_6"],Age5 = x.source[x.source[,"Run_Year"] %in% yrs.match,"Age_5"])

test.fit.linsubfun <- lm.fit(formula.use = "Age6 ~ -1 + Age5",data.use=test.data)
test.fit.linsubfun 

# -> verified that this matches the old code results


# ---------------------------------------
# replicate the calculation for one age class using the estimation function

source("../R/Module_Sub_EstimationFunctions.R")

test.fit.estimfun <- estimation.functions[["SibRegSimple"]]$estimator(test.data)
test.fit.estimfun

names(test.fit.estimfun)






# -> verified that this matches the old code results


# ---------------------------------------
# replicate the calculation for all age classes using the overall fitting function

source("../R/Module_fitModel.R")

test.fit.fitModel <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=TRUE)
names(test.fit.fitModel)
names(test.fit.fitModel$"Age 6")





# using old code
source("TEMP_Source_OldFunctions_SimpleSibReg.R")

processed.dat <- datafile_extract_age_class(samplefile.withage, sample.dat$specs$stockabundance)
model.forms <- prepare_data_and_model_formulas(processed.dat)
model.forms$model_data$"Age 6"

test.fit.old <- sibling_regression_model_fits(model.forms)
names(test.fit.old$model_fits )
names(test.fit.old$model_fits$"Age 6")
summary(test.fit.old$model_fits$"Age 6")


sink("../OUTPUT/TEST_SimpleSibReg_Crosschecks_OneAgeClass.txt")

cat("Using the generic linear fit subroutine--------------------------------")
cat("\n"); cat("\n")

print(test.fit.linsubfun)

cat("Using the Estimation Function--------------------------------")
cat("\n"); cat("\n")

print(test.fit.estimfun)

cat("Using he fitFC() Module --------------------------------")
cat("\n"); cat("\n")

print(test.fit.fitModel$"Age 6")



cat("Using the old functions------------------------------------------------")
cat("\n"); cat("\n")

print(model.forms$model_formulas$"Age 6")
print(summary(test.fit.old$model_fits$"Age 6"))



sink()


############################
# Simple Log Power Sibling Regression
###########################





# ---------------------------------------
# replicate the calculation for all age classes using the overall fitting function

source("../R/Module_fitModel.R")
source("../R/Module_Sub_EstimationFunctions.R")
test.fit.fitModel <- fitModel(model= "SibRegLogPower", data = sample.dat$data, settings = NULL,tracing=TRUE)
test.fit.fitModel

# -> verified that it matches the old code



# using old code
source("TEMP_Source_OldFunctions_SimpleLogPower.R")
processed.dat <- datafile_extract_age_class(samplefile.withage, sample.dat$specs$stockabundance)
model.forms <- prepare_data_and_model_formulas_simplelogpower(processed.dat)
test.fit.old <- simplelogpower_regression_model_fits(model.forms)
names(test.fit.old$model_fits )
summary(test.fit.old$model_fits$"Age 6")



sink("../OUTPUT/TEST_SimpleLogPower_Crosschecks_OneAgeClass.txt")



cat("Using the fitModel() Module--------------------------------")
cat("\n"); cat("\n")

print(test.fit.fitModel$"Age 6")



cat("Using the old functions------------------------------------------------")
cat("\n"); cat("\n")

print(model.forms$model_formulas$"Age 6")
print(summary(test.fit.old$model_fits$"Age 6"))



sink()



############################
# ARIMA fit
###########################


source.modules("../R/")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

data.tmp <- sample.dat$data$"Age 6"[,3]
data.tmp 

arima.fit.test <- estimation.functions[["TimeSeriesArima"]]$estimator(model.data = data.tmp,settings=list(BoxCox=FALSE))
names(arima.fit.test)
#arima.fit.test


test.fit.fitModel <- fitModel(model= "TimeSeriesArima", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=TRUE)
test.fit.fitModel





############################
# EXPONENTIAL SMOOTHING
###########################




source.modules("../R/")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

data.tmp <- sample.dat$data$"Age 6"[,3]
data.tmp 

expsmooth.fit.test <- estimation.functions[["TimeSeriesExpSmooth"]]$estimator(model.data = data.tmp,settings=list(BoxCox=FALSE))
names(expsmooth.fit.test)
#expsmooth.fit.test


test.fit.fitModel <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=TRUE)
test.fit.fitModel





############################
# KALMAN FILTER SIB REG
###########################


source.modules("../R/")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

x.source <- sample.dat$data$"Age 5"
y.source <- sample.dat$data$"Age 6"
yrs.match <- intersect(x.source[,"Run_Year"],y.source[,"Run_Year"]-1)
test.data <- data.frame(Age6 = y.source[y.source[,"Run_Year"] %in% (yrs.match+1),"Age_6"],Age5 = x.source[x.source[,"Run_Year"] %in% yrs.match,"Age_5"])


test.kf.estimfun <- estimation.functions[["SibRegKalman"]]$estimator(test.data)
names(test.kf.estimfun )
#test.kf.estimfun$coefficients

test.fit.fitModel <- fitModel(model= "SibRegKalman", data = sample.dat$data, settings = list(X=NA),tracing=TRUE)
test.fit.fitModel


test.fit.fitModel$"Age 6"$fit.obj$coefficients


#### Complex Sibling Regression ####

source("../R/Module_prepData.R")
source("../R/Module_Sub_EstimationFunctions.R")
source("../R/Module_fitModel.R")

samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")
str(sample.dat)
sample.dat$data


test.fit.fitModel <- fitModel(model= "complexsibreg", data = sample.dat$data, settings = NULL,tracing=TRUE)
names(test.fit.fitModel)
names(test.fit.fitModel$"Age 6")

