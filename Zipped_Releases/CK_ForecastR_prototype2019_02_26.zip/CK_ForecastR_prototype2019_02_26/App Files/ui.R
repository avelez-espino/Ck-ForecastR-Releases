
# INSERT PASSWORD STEP HERE (CHECK WITH JOHN SON)



# Think it needs these here for the server deployment
	library("ggplot2")
	library("DT")
	library("markdown")
	library("rmarkdown")
	
	library("shiny")
	library("shinydashboard")
	library("shinyjqui")
	library("shinyFiles")


#model.types <- c("Naive", "TimeSeriesArima","TimeSeriesExpSmooth", "SibRegSimple","SibRegLogPower", "SibRegKalman")
	
model.types <- list("Naive" = "Naive", "Time Series" = c("TimeSeriesArima","TimeSeriesExpSmooth"), "Sibling" = c("SibRegSimple","SibRegLogPower", "SibRegKalman"))

	
# for reports using old code OBSOLETE
#fc.model.list.withage <-  c("n1.model","n3.model","n5.model","ARIMA.model","EXPSMOOTH.model",
#						"SIMPLESIBREG.model","SIMPLELOGPOWER.model")
#fc.model.list.withoutage <- c("noagemodelnaiveone","noagemodelavgthree","noagemodelavgfive",
#								"noagemodelarima","noagemodelexpsmooth")
										




				
# This is a kludge, until can dynamically link the dropdown and the tabset to the ages in the input file
#ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")
ages.menu.list <- c("all","Age 2","Age 3","Age 4","Age 5","Age 6","Age 7")
ages.menu.list.multi <- c("Total","Age 2","Age 3","Age 4","Age 5","Age 6","Age 7")





retro.types <- c("retro.pm.bal", "retro.pm.all.constantyrs", "retro.pm.all.varyrs","fitted.pm.last")   
names(retro.types) <- c("Balanced","Constant Years","Variable Years","Fitted")
				
boots.method.list <-  c("meboot", "stlboot") #meboot = max entropy, stlboot = loess")
			
report.type.list <- c("Pdf - Key Plots Only","Pdf - Long","Word - Short","Word - Long")			
				
navbarPage("ForecastR", id = "MainTab",


	 tabPanel("Disclaimer",

fluidPage(

  titlePanel("Disclaimer"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/disclaimer.md")
    )
  )
)


	
	  ),  # end Help tab panel


  

#######  
 tabPanel("Data Loading", value= "data.loading",
    
pageWithSidebar(
  headerPanel("Data Loading"),
    
  sidebarPanel(
			  tags$h4("Data File"),
			  tags$hr(),
			  #shinyFilesButton(id="file.name.2", label="File select", title="Please select a file", multiple=FALSE)	, 
			  fileInput("file.name.2", "Choose CSV File", accept = c("text/csv","text/comma-separated-values,text/plain", ".csv")    ),
			  tags$hr() ,
			  tags$a("Get Some Sample Data",href="https://www.dropbox.com/sh/3fouksm7p1pxrzv/AABQjY74uuHa0Gd8a7MHyUoUa?dl=0",target="_blank")
			  #textInput("file.name", "File Name", value = "Data/SampleFile_WithAge.csv", placeholder = "Enter a file name")
			) # end sidebar
  ,
   

     mainPanel(			
	     
			div(style = 'overflow: scroll', tableOutput("inputheader.table"),height = "400px")
			
	   
		) # end main panel
  
		) #end page with side bar for  data loading
  ),  # end  second tab panel
    

#################### MODEL PRE CHECK ######################################	

  
    tabPanel("Explore", value= "precheck",

	pageWithSidebar(
	headerPanel("Explore Models"),
    
	sidebarPanel(
		selectizeInput("model.use.precheck", "Model Type", choices = model.types, selected=model.types[1]),
		selectizeInput("precheck.ageclass", "Age Class", choices = ages.menu.list, selected=ages.menu.list[1]),
		#numericInput("fc.yr", "FC Year", value=2018),  # comes from data file for now		
		# slider below is for now changed to only give start year, then add the end year as 1-fc.yr on the server side
		sliderInput("yr.range.precheck", "Start (Run Years)",sep="",min = 1960, max = 2005, value = 1985),
		checkboxInput("precheck.boxcox", label="Box-Cox Transform (TS Models)", value = FALSE ),
		# change below to inline layout: https://github.com/rstudio/shiny/issues/1737
		numericInput("precheck.avgyrs", label=h5("Avg Years (Naive)"), value = 3 , min = 1, max = 10, step = 1,   width = "50%"),
		numericInput("precheck.intavg", label=h5("Avg n Est (Kalman)"), value = 5, min = 1, max = 10, step = 1,   width = "50%"),
		selectizeInput("interval.type.precheck", "Interval Type", choices = c("Retrospective","Prediction","Bootstrap"), selected="Retrospective"),
		numericInput("boot.n.precheck", "Interval Sample",  value = 100 , min = 10, max = 1000, step = 10,   width = "50%"),
		selectizeInput("boot.type.precheck", "Bootstrap Type", choices = c("meboot","stlboot"), selected="meboot"),		
		downloadButton("downloadPreCheckRep", "Download PDf report")
		#actionButton("create.precheck.summary.withoutage", "Create PDF Report")	
					  
		) # end sidebar
  ,
   

     mainPanel(			
	     
 
		 tabsetPanel(type = "tabs",
                  tabPanel("Fits & Point Forecast", plotOutput("precheck.plot.fitandfc",width = "100%", height = "600px")),
				  tabPanel("Forecast Plot", plotOutput("precheck.plot.intervals",width = "100%", height = "600px")),
				  tabPanel("Forecast Table",   DT::dataTableOutput("table.explore.fc"),
							downloadButton("download.table.explore.fc","Download")),
				tabPanel("Residuals",	
				tabsetPanel(type = "tabs",
					tabPanel("Pattern",plotOutput("precheck.plot.resid_ts",width = "100%", height = "600px") ),
                  tabPanel("Histogram",plotOutput("precheck.plot.resid_hist",width = "100%", height = "600px") ),
				  tabPanel("QQ Norm",plotOutput("precheck.plot.resid_qq",width = "100%", height = "600px") )
						)),
  				  tabPanel("Bootstrapped Series",plotOutput("precheck.plot.boots.sample",width = "100%", height = "600px") )
				  )
		 
		 
		
	   
		) # end main panel
  
		) #end page with side bar for model pre-check

		
		
	),


	
	
	

####################################
	 tabPanel("Compare" , value= "compare",

	pageWithSidebar(
	headerPanel("Compare Models"),
    
	sidebarPanel(width = 3, 
		
		# https://stackoverflow.com/questions/43973863/keep-datatable-sort-between-tabs-in-shiny
		# try to link table sorting to the plot order

		#actionButton("addmodel.compare", "x Add a Model"),
		#actionButton("resetmodel.compare", "x Reset Models"),
		tags$p("Note: Running a new batch of models takes a little time"),
		selectizeInput("compare.ageclass", "Age Class", choices = ages.menu.list.multi, selected=ages.menu.list[1]),
		selectizeInput("compare.plotsort", "Sort Plot By", choices = c("None","AvgRank","Forecast"), selected="None"),
		selectizeInput("retrotype.compare", "Retro PM Type", choices = retro.types, selected=retro.types[1]),
		selectizeInput("interval.type.compare", "Interval Type", choices = c("Retrospective","Prediction","Bootstrap"), selected="Retrospective"),
		numericInput("boot.n.compare", "Interval Sample",  value = 100 , min = 10, max = 1000, step = 10,   width = "50%"),		
		#numericInput("fc.yr", "FC Year", value=2018),  # comes from data file for now
		# slider below is for now changed to only give start year, then add the end year as 1-fc.yr on the server side
		sliderInput("yr.range.compare", "Start (Run Years)", sep="",min = 1960, max = 2005, value = 1985),
		checkboxGroupInput("compare.pm", label="Perf. Measures for Model Ranking", 
				choices=c("MRE","MAE","MPE","MAPE","MASE","RMSE")   , 
					selected = c("MRE","MAE","MPE","MAPE","MASE","RMSE") , inline = TRUE),
		checkboxInput("rel.bol","Use Scaled Ranking",value=FALSE),			
		#downloadButton("downloadComparisonTxt", "x Download text file"),
		#downloadButton("downloadComparisonCsv", "x Download csv files"),
		#downloadButton("downloadComparisonRep", "x Download pdf report"),
		downloadButton("downloadComparisonRepWord", "Download short MSWord report")
		#actionButton("create.precheck.summary.withoutage", "Create PDF Report")	
			

			
		) # end sidebar
  ,
   

     mainPanel(			
	     
 
		 tabsetPanel(type = "tabs",
					
				  tabPanel("Settings",
							tabsetPanel(type = "tabs",
								tabPanel("M1",checkboxInput("m1.use","Include this model",value=TRUE),
											  textInput("m1.name", "Model Label", value = "Naive3", width = "40%"),	
											  selectizeInput("m1.modeltype", "Model Type", choices = model.types, selected=model.types[1], width = "40%"),
											  numericInput("m1.avgyrs", label=h5("Avg Years (Naive Models)"), value = 3 , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m1.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m1.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M2",checkboxInput("m2.use","Include this model",value=TRUE),
											  textInput("m2.name", "Model Label", value = "Naive5", width = "40%"),	
											  selectizeInput("m2.modeltype", "Model Type", choices = model.types, selected=model.types[1], width = "40%"),
											  numericInput("m2.avgyrs", label=h5("Avg Years (Naive Models)"), value = 5 , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m2.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m2.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M3",checkboxInput("m3.use","Include this model",value=TRUE),
											  textInput("m3.name", "Model Label", value = "SibRegSimple", width = "40%"),	
											  selectizeInput("m3.modeltype", "Model Type", choices = model.types, selected="SibRegSimple", width = "40%"),
											  numericInput("m3.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m3.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m3.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M4",checkboxInput("m4.use","Include this model",value=TRUE),
											  textInput("m4.name", "Model Label", value = "SibRegLogPower", width = "40%"),	
											  selectizeInput("m4.modeltype", "Model Type", choices = model.types, selected="SibRegLogPower", width = "40%"),
											  numericInput("m4.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m4.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m4.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M5",checkboxInput("m5.use","Include this model",value=TRUE),
											  textInput("m5.name", "Model Label", value = "SibRegKalman", width = "40%"),	
											  selectizeInput("m5.modeltype", "Model Type", choices = model.types, selected="SibRegKalman", width = "40%"),
											  numericInput("m5.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m5.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m5.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = 5 , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M6",checkboxInput("m6.use","Include this model",value=FALSE),
											  textInput("m6.name", "Model Label", value = "TSArimaBC", width = "40%"),	
											  selectizeInput("m6.modeltype", "Model Type", choices = model.types, selected="TimeSeriesArima", width = "40%"),
											  numericInput("m6.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m6.boxcox","Box-Cox Transf. - Time Series Models",value=TRUE),
											  numericInput("m6.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL, min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M7",checkboxInput("m7.use","Include this model",value=TRUE),
											  textInput("m7.name", "Model Label", value = "TSArimaNoBC", width = "40%"),	
											  selectizeInput("m7.modeltype", "Model Type", choices = model.types, selected="TimeSeriesArima", width = "40%"),
											  numericInput("m7.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m7.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m7.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),
								tabPanel("M8",checkboxInput("m8.use","Include this model",value=FALSE),
											  textInput("m8.name", "Model Label", value = "TSExpSmoothBC", width = "40%"),	
											  selectizeInput("m8.modeltype", "Model Type", choices = model.types, selected="TimeSeriesExpSmooth", width = "40%"),
											  numericInput("m8.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m8.boxcox","Box-Cox Transf. - Time Series Models",value=TRUE),
											  numericInput("m8.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),									  
								tabPanel("M9",checkboxInput("m9.use","Include this model",value=TRUE),
											  textInput("m9.name", "Model Label", value = "TSExpSmoothNoBC", width = "40%"),	
											  selectizeInput("m9.modeltype", "Model Type", choices = model.types, selected="TimeSeriesExpSmooth", width = "40%"),
											  numericInput("m9.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m9.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m9.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  ),		
								tabPanel("M10",checkboxInput("m10.use","Include this model",value=FALSE),
											  textInput("m10.name", "Model Label", value = NULL, width = "40%"),	
											  selectizeInput("m10.modeltype", "Model Type", choices = model.types, selected=NULL, width = "40%"),
											  numericInput("m10.avgyrs", label=h5("Avg Years (Naive Models)"), value = NULL , min = 1, max = 10, step = 1,   width = "40%"),
											  checkboxInput("m10.boxcox","Box-Cox Transf. - Time Series Models",value=FALSE),
											  numericInput("m10.kfyear", label=h5("Avg Years for time-varying par (Kalman Filter Models)"), value = NULL , min = 1, max = 50, step = 1,   width = "40%")							
											  )													  
											  
										  
								 ) # end nested tabsetpanel 
								 ), # end tab panel for settings
                  tabPanel("Point Forecasts",  DT::dataTableOutput("table.multi.ptfc"),
							downloadButton("download.ptfc.table.merged","Download")
							),
				  tabPanel("Model Selection", DT::dataTableOutput("table.bestmodels"),
								downloadButton("download.bestmodels.table","Download")
							),
				 # tabPanel("x Pt FC w/ Best Models",  DT::dataTableOutput("table.bestmodel.fc")) ,
				  #tabPanel("x Bootstrap",  DT::dataTableOutput("table.bestmodel.fc.boot"))	
				tabPanel("FC Plot - By Age",
									h2(textOutput("compare.ageclass"), align = "center"),
									plotOutput("compare.ptfc",width = "100%", height = "600px")	),
			tabPanel("Ranking Details",	
				tabsetPanel(type = "tabs",

				 tabPanel("Rank - Across Ages", DT::dataTableOutput("table.cumul.ranking")) ,
				 
				  tabPanel("Perf. - By Age",
									#h2(textOutput("compare.ageclass"), align = "center"), # crashes the data loading???? DTpackage issue???? - using caption for now
									DT::dataTableOutput("table.retropm")) ,
				  tabPanel("Rank - By Age", 
									#h2(textOutput("compare.ageclass"), align = "center"), # crashes the data loading???? DTpackage issue????  - using caption for now
									DT::dataTableOutput("table.ranking"))
							))
													
			  
				  
				  )
		 
		 
		
	   
		) # end main panel
  
		) #end page with side bar for model comparison

	),

	
######### REPORTS	#############
  
	
	
	 tabPanel("Help",  value= "help.panel",

fluidPage(

  titlePanel("Help Page"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/help.md")
    )
  )
)


	
	  ),  # end Help tab panel
	
	tabPanel("About",
	
fluidPage(

  titlePanel("About ForecastR"),

  fluidRow(
    column(8,
      includeMarkdown("Markdown/about.md")
    )
  )	
)	
	  )  # end about tab panel
	
	
	
) # end navbar Page


