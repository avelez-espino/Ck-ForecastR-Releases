cat("Effects - Sibling Regression.R", "\n\n")

usePackage("effects")

SIMPLESIBREG$my.effect.plot.multiple.predictor(SIMPLESIBREG$results_best_fitting_model_for_each_age_class, SIMPLESIBREG$stockabundance, i=1)



