#there is an issues with the functions file around line 253-254
source("R/simplesibreg/RETRO - Simple Sibling Regression_functions.R")
source("R/utils.R")

cat("RETRO - Sibling Regression.R", "\n\n")

## need to refresh the datalist object, as it currently contains only the youngest age!!!

SIMPLESIBREG$datafile <- datafile_original

SIMPLESIBREG$datafilesub <- SIMPLESIBREG$datafile


SIMPLESIBREG$extract_ages <- sort(unique(SIMPLESIBREG$datafilesub$Age_Class))
SIMPLESIBREG$extract_names <- paste("T",SIMPLESIBREG$extract_ages,sep="")
SIMPLESIBREG$extract_names <- c("BY",SIMPLESIBREG$extract_names)

SIMPLESIBREG$tmpsub <- list()
for (i in 1:length(SIMPLESIBREG$extract_ages)){
     if (SIMPLESIBREG$stockabundance=="Terminal Run"){
     SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Terminal_Run")]
     } else if (SIMPLESIBREG$stockabundance=="Escapement") {
      SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Escapement")]
     } else if (stockabundance=="Production") {
      SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Production")]
     }
}



SIMPLESIBREG$list.of.data.frames <- SIMPLESIBREG$tmpsub
#debug here:
SIMPLESIBREG$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), SIMPLESIBREG$list.of.data.frames)

SIMPLESIBREG$datafile_new <- SIMPLESIBREG$merged.data.frame
names(SIMPLESIBREG$datafile_new) <- SIMPLESIBREG$extract_names

## SIMPLESIBREG$datafile <<- SIMPLESIBREG$datafile_new

SIMPLESIBREG$datafile <- SIMPLESIBREG$datafile_new

SIMPLESIBREG$datalist <- datalist.avgfive(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)  # CY refers to the T variable with highest age

##========================================================================================================
## youngest age: avgfive
##========================================================================================================

SIMPLESIBREG$index.year <- index.year


SIMPLESIBREG$result.avgfive.youngest <- individual.ages.retro.predictive.performance.avgfive.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$index.year)

SIMPLESIBREG$youngest.age.retro.plot.info.avgfive

youngest.age.retro.plot.avgfive(SIMPLESIBREG$youngest.age.retro.plot.info.avgfive, SIMPLESIBREG$stockabundance)


##========================================================================================================
## youngest age: arima
##========================================================================================================

SIMPLESIBREG$datalist <- datalist.arima(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)  # CY refers to the T variable with highest age

## arima.model.fits  <- SIMPLESIBREG$arima.model(SIMPLESIBREG$datalist, SIMPLESIBREG$boxcoxtransform)



SIMPLESIBREG$result.arima.simple.sibling.regression <- individual.ages.retro.predictive.performance.arima.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$boxcoxtransform, SIMPLESIBREG$index.year)

youngest.age.retro.plot.arima(SIMPLESIBREG$youngest.age.retro.plot.info.arima, stockabundance)

##========================================================================================================
## youngest age: expsmooth
##========================================================================================================

SIMPLESIBREG$datalist <- datalist.expsmooth(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)


#---------  fit exponential smoothing model -----------------------------------------

# SIMPLESIBREG$expsmooth.model.fits  <- SIMPLESIBREG$expsmooth.model(SIMPLESIBREG$datalist, SIMPLESIBREG$boxcoxtransform)

SIMPLESIBREG$result.expsmooth.simple.sibling.regression <- individual.ages.retro.predictive.performance.expsmooth.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$boxcoxtransform, SIMPLESIBREG$index.year)


youngest.age.retro.plot.expsmooth(SIMPLESIBREG$youngest.age.retro.plot.info.expsmooth, SIMPLESIBREG$stockabundance)




##=========================================================================================================
## simple sibling regression
##=========================================================================================================


SIMPLESIBREG$result.simple.sibling.regression <- individual.ages.retro.predictive.performance.simple.sibling.regression.youngest(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, SIMPLESIBREG$index.year)

SIMPLESIBREG$individual.ages.retro.plot.simplesib(SIMPLESIBREG$individual.ages.retro.plot.info.simplesib, SIMPLESIBREG$stockabundance, j=1)


##=========================================================================================================
## measures of retro performance - avgfive + sibreg
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.avgfive.plus.simple.sibling.regression

SIMPLESIBREG$result.avgfive.simple.sibling.regression <- individual.ages.retro.predictive.performance.simple.sibling.regression.youngest(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, index.year)

## call to total.age.retro.predictive.performance.avgfive.plus.simple.sibling.regression
SIMPLESIBREG$rmse.results.youngest.age.avgfive.plus.simple.sibling.regression <-
SIMPLESIBREG$total.age.retro.predictive.performance.avgfive.plus.simple.sibling.regression(SIMPLESIBREG$result.avgfive.youngest, SIMPLESIBREG$result.simple.sibling.regression)


##=========================================================================================================
## measures of retro performance - arima + sibreg
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.arima.plus.simple.sibling.regression


SIMPLESIBREG$result.arima.youngest <- individual.ages.retro.predictive.performance.arima.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$boxcoxtransform, SIMPLESIBREG$index.year)


SIMPLESIBREG$res.arima.simple.sibling.regression <- individual.ages.retro.predictive.performance.simple.sibling.regression.youngest(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, index.year)
## call to total.age.retro.predictive.performance.arima.plus.simple.sibling.regression
SIMPLESIBREG$rmse.results.youngest.age.arima.plus.simple.sibling.regression <-
SIMPLESIBREG$total.age.retro.predictive.performance.arima.plus.simple.sibling.regression(SIMPLESIBREG$result.arima.youngest, SIMPLESIBREG$result.simple.sibling.regression)

##=========================================================================================================
## measures of retro performance - expsmooth + sibreg
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.expsmooth.plus.simple.sibling.regression

SIMPLESIBREG$result.expsmooth.youngest <- SIMPLESIBREG$individual.ages.retro.predictive.performance.expsmooth.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$boxcoxtransform, SIMPLESIBREG$index.year)


SIMPLESIBREG$res.expsmooth.simple.sibling.regression <- individual.ages.retro.predictive.performance.simple.sibling.regression.youngest(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, SIMPLESIBREG$index.year)

## call to total.age.retro.predictive.performance.expsmooth.plus.simple.sibling.regression
SIMPLESIBREG$rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression <-
SIMPLESIBREG$total.age.retro.predictive.performance.expsmooth.plus.simple.sibling.regression(SIMPLESIBREG$result.expsmooth.youngest, SIMPLESIBREG$result.simple.sibling.regression)



##=========================================================================================================
## choosing the measure of retro performance (i.e., rmse) which is "best" for forecasting total age
## among avgfive + sibreg, arima + sibreg, expsmooth + sibreg
##=========================================================================================================

SIMPLESIBREG$best.rmse.youngest.age <-  SIMPLESIBREG$best.rmse.results.youngest.age(SIMPLESIBREG$rmse.results.youngest.age.avgfive.plus.simple.sibling.regression, SIMPLESIBREG$rmse.results.youngest.age.arima.plus.simple.sibling.regression, SIMPLESIBREG$rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression)

SIMPLESIBREG$best.rmse.youngest.age

###
###  "Cool" plots for the youngest age
###

SIMPLESIBREG$best.rmse.youngest.age$method   # "naive forecasting (i.e., average of previous five years)"
                                # "ARIMA forecasting"
                                # "exponential smoothing forecasting"

## youngest.age.retro.plot.avgfive(youngest.age.retro.plot.info.avgfive, stockabundance)
## youngest.age.retro.plot.arima(youngest.age.retro.plot.info.arima, stockabundance)
## youngest.age.retro.plot.expsmooth(youngest.age.retro.plot.info.expsmooth, stockabundance)


###
### Density Plot of Retrospective Forecast Errors: Individual Ages
###

SIMPLESIBREG$plot.dens.retrospective.forecast.errors.individual.ages.simple.sibling.regression(
    SIMPLESIBREG$best.rmse.youngest.age,
    SIMPLESIBREG$stockabundance)

###
### Density Plot of Retrospective Forecast Errors: Total Age
###

SIMPLESIBREG$plot.dens.retrospective.forecast.errors.total.age.simple.sibling.regression(
    SIMPLESIBREG$best.rmse.youngest.age,
    SIMPLESIBREG$stockabundance)


SIMPLESIBREG$best.rmse.youngest.age <-  SIMPLESIBREG$best.rmse.results.youngest.age(SIMPLESIBREG$rmse.results.youngest.age.avgfive.plus.simple.sibling.regression, SIMPLESIBREG$rmse.results.youngest.age.arima.plus.simple.sibling.regression, SIMPLESIBREG$rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression)

SIMPLESIBREG$best.rmse.youngest.age


##
## R-Squared Values from Retrospective Evaluation of Point Forecast Performance
##

## SIMPLESIBREG$r.squared.retro.simple.sibling.regression(best.rmse.youngest.age)


#*******************************************************************************
#
# Gary's Plot for Individual Ages: Youngest + Older
#
#*******************************************************************************


## j <- 1

SIMPLESIBREG$gary.plot.individual.ages.simple.sibling.regression( SIMPLESIBREG$best.rmse.youngest.age, SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest,# youngest age prediction: avgfive
SIMPLESIBREG$pred.int.individual.ages.arima.youngest,# youngest age prediction: arima
SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest, # youngest age prediction: expsmooth
SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,# older ages prediction: sibling regression (best model)
SIMPLESIBREG$forecastingyear, j=1)

#*******************************************************************************
#
# Gary's Plot for Total Age:
#
#*******************************************************************************

SIMPLESIBREG$gary.plot.total.age.simple.sibling.regression(SIMPLESIBREG$best.rmse.youngest.age, SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models,  # total age prediction
SIMPLESIBREG$forecastingyear)

##
## Table of results for candidate models for youngest age: avgfive, arima, expsmooth
##

SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest
SIMPLESIBREG$pred.int.individual.ages.arima.youngest
SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest


SIMPLESIBREG$table.results.individual.ages.all.models.youngest <- list()
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$Model <- c("Naive (Average of Previous Five Years)",
                                                             "ARIMA",
                                                             "Exponential Smoothing")

SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.ctr <- c( round(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.ctr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.ctr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.ctr))

SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr<- c( round(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.lwr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.lwr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.lwr))
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr <- as.numeric(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr)

SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr <- c(round(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.upr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.upr),
                                                               round(SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.upr))
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr <- as.numeric(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLESIBREG$rmse.total.age.avgfive <- SIMPLESIBREG$rmse.results.youngest.age.avgfive.plus.simple.sibling.regression$rmse.total
SIMPLESIBREG$rmse.total.age.arima  <- SIMPLESIBREG$rmse.results.youngest.age.arima.plus.simple.sibling.regression$rmse.total
SIMPLESIBREG$rmse.total.age.expsmooth  <- SIMPLESIBREG$rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression$rmse.total

SIMPLESIBREG$rmse.total.age <- c(SIMPLESIBREG$rmse.total.age.avgfive, SIMPLESIBREG$rmse.total.age.arima, SIMPLESIBREG$rmse.total.age.expsmooth)

SIMPLESIBREG$table.results.individual.ages.all.models.youngest$rmse.total.age <- SIMPLESIBREG$rmse.total.age  ## recall that this rmse is optimized for
                                                                                    ## prediction of total age!!!


SIMPLESIBREG$table.results.individual.ages.all.models.youngest <- do.call(cbind.data.frame, SIMPLESIBREG$table.results.individual.ages.all.models.youngest)

usePackage("scales")
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.ctr <- comma(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.ctr)
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr <- comma(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr)
SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr <- comma(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.int <- paste0(SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.lwr,
                                                                   " - ",
                                                                   SIMPLESIBREG$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLESIBREG$table.results.individual.ages.all.models.youngest <- subset(SIMPLESIBREG$table.results.individual.ages.all.models.youngest,
                                                            select=c(Model, PI.ctr,  PI.int, rmse.total.age))
names(SIMPLESIBREG$table.results.individual.ages.all.models.youngest) <-  c("Model", "Point Forecast", "Interval Forecast", "RMSE")

## SIMPLESIBREG$table.results.individual.ages.all.models.youngest


#=====================================================================================================================================
#
# Best RMSE
#
#######################################################################################################################################


SIMPLESIBREG$best.rmse.youngest.age <-  SIMPLESIBREG$best.rmse.results.youngest.age(SIMPLESIBREG$rmse.results.youngest.age.avgfive.plus.simple.sibling.regression,
                                                          SIMPLESIBREG$rmse.results.youngest.age.arima.plus.simple.sibling.regression,
                                                          SIMPLESIBREG$rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression)

SIMPLESIBREG$total.index <- SIMPLESIBREG$best.rmse.youngest.age$index.min.rmse.total.age



###
### plot forecast vs. actual (individual ages, simple sibling regression)
###

SIMPLESIBREG$plot.results.afe.individual.ages.retro.simple.sibling.regression(SIMPLESIBREG$best.rmse.youngest.age)

###
### plot forecasted vs. actual (total age, simple sibling regression)
###

SIMPLESIBREG$plot.results.afe.total.age.retro.simple.sibling.regression(SIMPLESIBREG$best.rmse.youngest.age, SIMPLESIBREG$stockabundance)
