# Simple Sibling Regression Models - Prediction Results
# Date Stamp: January 25, 2016


source("R/simplesibreg/Review Code - Simple Sibling Regression_functions.R")
source("R/utils.R")
cat("Review Code - Simple Sibling Regression.R", "\n\n")

SIMPLESIBREG <- new.env()

# setwd("C:\\Documents and Settings\\dv6110ca\\Desktop\\Demo R")
# setwd("L:\\IMPORTANT\\Demo R")
# setwd("F:\\IMPORTANT\\Demo R")
# datafile <- read.csv("SPR_thousands.csv", as.is=TRUE)

SIMPLESIBREG$datafile <- datafile_original

SIMPLESIBREG$stockabundance <- SIMPLESIBREG$datafile$Stock_Abundance[1]
SIMPLESIBREG$stockname <- SIMPLESIBREG$datafile$Stock_Name[1]
SIMPLESIBREG$stockspecies <- SIMPLESIBREG$datafile$Stock_Species[1]
SIMPLESIBREG$forecastingyear <- SIMPLESIBREG$datafile$Forecasting_Year[1]

usePackage("stringr")
SIMPLESIBREG$forecastingyear <- str_replace_all(SIMPLESIBREG$forecastingyear, "\n","")
SIMPLESIBREG$forecastingyear <- as.numeric(SIMPLESIBREG$forecastingyear)

SIMPLESIBREG$datafile_variables <- datafile_extract_age_class(SIMPLESIBREG$datafile, SIMPLESIBREG$stockabundance)

# names(datafile_variables)

SIMPLESIBREG$datafile_variables <- datafile_extract_age_class(SIMPLESIBREG$datafile, SIMPLESIBREG$stockabundance)

SIMPLESIBREG$data_and_model_formulas <-  prepare_data_and_model_formulas(SIMPLESIBREG$datafile_variables)

SIMPLESIBREG$data_and_model_formulas

#### the initial model fit: ####
SIMPLESIBREG$fits <-  sibling_regression_model_fits(SIMPLESIBREG$data_and_model_formulas)

print("printing SIMPLESIBREG$fits --------------------------------" )
print(SIMPLESIBREG$fits )
print("end of printing SIMPLESIBREG$fits --------------------------------" )

SIMPLESIBREG$fits

SIMPLESIBREG$fits$model_data
SIMPLESIBREG$fits$model_formulas
SIMPLESIBREG$fits$model_fits

## Important Reference on working with AIC:
## http://theses.ulaval.ca/archimede/fichiers/21842/apa.html

## Reference on differences in computing AIC values and on AICcmodavg package
## http://r.789695.n4.nabble.com/R-s-AIC-values-differ-from-published-values-td4384952.html

print("Flag 1")

print("Flag 2")

SIMPLESIBREG$results_model_selection <-  model_selection_results(SIMPLESIBREG$fits)

## SIMPLESIBREG$results_model_selection

## str(SIMPLESIBREG$results_model_selection)

## eliminate original function model_selection_table()?

model_selection_table_updated(SIMPLESIBREG$results_model_selection)

print("Flag 3")

## not sure yet how to handle model selection - single best model or model averaging?
## For now: choose the model with Delta AIC = 0 and with largest Akaike weight

SIMPLESIBREG$model_weights <- model_selection_delta_AIC_and_Akaike_weights(SIMPLESIBREG$results_model_selection)

print("Flag 4")

SIMPLESIBREG$model_weights

## usePackage("stringr")
## model_weights$Model <- str_replace_all(model_weights$Model,"NA ","")
## model_weights$Model <- str_replace_all(model_weights$Model," NA","")

print("Flag 5")

SIMPLESIBREG$best_fitting_model_for_each_age_class <-  select_best_fitting_model_for_each_age_class(SIMPLESIBREG$results_model_selection)

#### model summary for "best fitting model" for each age class ####

print("Flag 6")

SIMPLESIBREG$results_best_fitting_model_for_each_age_class <- summary_output_best_fitting_model_for_each_age_class(SIMPLESIBREG$fits, SIMPLESIBREG$results_model_selection)

format_results_best_fitting_model_for_each_age_class(SIMPLESIBREG$results_best_fitting_model_for_each_age_class,i=1)

#### point forecast for each individual age and for the total age ####
# http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

SIMPLESIBREG$point_forecast_best_model_for_each_age_class <-
point.forecast.best.fitting.model.for.each.age.class(SIMPLESIBREG$results_best_fitting_model_for_each_age_class, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$datafile_variables)


#### barplot forecasted values (specific ages) ####

SIMPLESIBREG$myplot <- barplot.forecasted.values.individual.ages.simplesib(SIMPLESIBREG$point_forecast_best_model_for_each_age_class, SIMPLESIBREG$forecastingyear, i=2)

plot(SIMPLESIBREG$myplot)


#### Compute Interval Forecasts ####
#this is the same call as happens on line 101:
#SIMPLESIBREG$results_best_fitting_model_for_each_age_class <- summary_output_best_fitting_model_for_each_age_class(SIMPLESIBREG$fits, SIMPLESIBREG$results_model_selection)

## SIMPLESIBREG$bootstrap.prediction.interval.simple.sibling.regression.no.covariates(SIMPLESIBREG$results_best_fitting_model_for_each_age_class,j=1,x0=500,B)

## SIMPLESIBREG$bootstrap.prediction.interval.simple.sibling.regression.no.covariates.updated(SIMPLESIBREG$results_best_fitting_model_for_each_age_class,j=3,x0=1000,B)

#### "best: sibling regression model forecast ####

# B <- 9999

SIMPLESIBREG$B <- B

#MF: forecast including bootstrap results:

#SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression <- best.sibling.regression.model.forecast(SIMPLESIBREG$datafile_variables, SIMPLESIBREG$results_best_fitting_model_for_each_age_class, SIMPLESIBREG$forecastingyear, B=SIMPLESIBREG$B)

#MF: alternate approach to bootstraping, just do a pdf of the prediction interval:
SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression <- calcPredictionPDF(SIMPLESIBREG$point_forecast_best_model_for_each_age_class, forecastingyear=SIMPLESIBREG$forecastingyear, B=SIMPLESIBREG$B)

#MF: the fit residuals can be found in here:
#SIMPLESIBREG$results_best_fitting_model_for_each_age_class

#### Histogram of Bootstrap Predictions: Best Fitting Models ####
#this is the same call as happens on line 101:
#SIMPLESIBREG$results_best_fitting_model_for_each_age_class <- summary_output_best_fitting_model_for_each_age_class(SIMPLESIBREG$fits, SIMPLESIBREG$results_model_selection)

SIMPLESIBREG$best.fits <-  SIMPLESIBREG$results_best_fitting_model_for_each_age_class

#### histogram with negative forecast values: ####
plot.yboot.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits, SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression)

SIMPLESIBREG$PI.ctr <- NULL
SIMPLESIBREG$PI.lwr <- NULL
SIMPLESIBREG$PI.upr <- NULL
# PI.med <- NULL
SIMPLESIBREG$PI.sim <- NULL
SIMPLESIBREG$nms <- NULL

for (k in 1:length(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression)){

     SIMPLESIBREG$PI.ctr <- c(SIMPLESIBREG$PI.ctr,
                 SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression[[k]]$p)

     SIMPLESIBREG$PI.lwr <- c(SIMPLESIBREG$PI.lwr,
                 SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression[[k]]$p.lwr)

     SIMPLESIBREG$PI.upr <- c(SIMPLESIBREG$PI.upr,
                 SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression[[k]]$p.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.expsmooth[[k]]$PI.median)

     SIMPLESIBREG$PI.sim <- cbind(SIMPLESIBREG$PI.sim, SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression[[k]]$y.star.boot)

     SIMPLESIBREG$form <-  as.formula(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression[[k]]$model.formula)
     usePackage("formula.tools")

     SIMPLESIBREG$nms <- c(SIMPLESIBREG$nms, lhs.vars(SIMPLESIBREG$form))

}

colnames(SIMPLESIBREG$PI.sim) <- SIMPLESIBREG$nms


SIMPLESIBREG$PI.lwr[SIMPLESIBREG$PI.lwr < 0] <- 0
SIMPLESIBREG$PI.upr[SIMPLESIBREG$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

SIMPLESIBREG$PI.ctr <- round(SIMPLESIBREG$PI.ctr)
SIMPLESIBREG$PI.lwr <- round(SIMPLESIBREG$PI.lwr)
SIMPLESIBREG$PI.upr <- round(SIMPLESIBREG$PI.upr)
## PI.med <- round(PI.med)


SIMPLESIBREG$PI.individual.ages.simple.sibling.regression <- data.frame(PI.ctr=SIMPLESIBREG$PI.ctr, PI.lwr=SIMPLESIBREG$PI.lwr, PI.upr=SIMPLESIBREG$PI.upr)

# PI.individual.ages.expsmooth.no.comma <- data.frame(PI.ctr=PI.ctr, PI.med=PI.med, PI.lwr=PI.lwr, PI.upr=PI.upr)

SIMPLESIBREG$PI.individual.ages.simple.sibling.regression.no.comma <- data.frame(PI.ctr=SIMPLESIBREG$PI.ctr, PI.lwr=SIMPLESIBREG$PI.lwr, PI.upr=SIMPLESIBREG$PI.upr)


#### PI.individual.ages.simple.sibling.regression ####
#usePackage("scales")
#SIMPLESIBREG$PI.individual.ages.simple.sibling.regression <- scales::comma(SIMPLESIBREG$PI.individual.ages.simple.sibling.regression)

#### PI.individual.ages.simple.sibling.regression ####
SIMPLESIBREG$PI.individual.ages.simple.sibling.regression.sim <- SIMPLESIBREG$PI.sim

####  Plot distribution of bootstrapped point forecasts - individual ages ####
plot.distribution.bootstrapped.point.forecasts.individual.ages.simple.sibling.regression(SIMPLESIBREG$PI.individual.ages.simple.sibling.regression.sim, SIMPLESIBREG$PI.individual.ages.simple.sibling.regression.no.comma)

#### plot forecasted values & forecast intervals:  scatterplot (individual ages) ####

SIMPLESIBREG$bestfits <- SIMPLESIBREG$results_best_fitting_model_for_each_age_class
SIMPLESIBREG$pointforecasts <- SIMPLESIBREG$point_forecast_best_model_for_each_age_class
SIMPLESIBREG$intervalforecasts <-   SIMPLESIBREG$PI.individual.ages.simple.sibling.regression.no.comma


scatterplot.forecasted.values.and.forecast.intervals.individual.ages.simple.sibling.regression(
            SIMPLESIBREG$bestfits, SIMPLESIBREG$pointforecasts,
            SIMPLESIBREG$intervalforecasts, SIMPLESIBREG$forecastingyear,i=1)

#### scatterplot matrix of abundance data (specific ages) ####
scatterplot.matrix.individual.ages.simplesib(SIMPLESIBREG$fits)

#### correlation matrix of abundance data (specific ages) ####
correlation.matrix.individual.ages.simplesib(SIMPLESIBREG$fits)

#### Model Diagnostics for "Best" Fitting Models ####
# best.fits <- results_best_fitting_model_for_each_age_class
# Plot of Residuals vs. Fitted Values: Best Fitting Models
plot.residuals.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Histogram of Residuals: Best Fitting Models ####
plot.histresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Density Plots of Residuals: Best Fitting Models ####
# best.fits
plot.densresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### ACF and PACF Functions of Residuals: Best Fitting Models ####
plot.acfpacf.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### ACF Plots of Residuals: Best Fitting Models ####
plot.acfresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### PACF Plots of Residuals : Best Fitting Models ####
plot.pacfresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

SIMPLESIBREG$best.fits <- SIMPLESIBREG$results_best_fitting_model_for_each_age_class
## http://docs.ggplot2.org/0.9.3.1/geom_vline.html

#### Time Series Plot of Residuals: Best Fitting Models ####
plot.timeresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Index Plot of Leverage Values: Best Fitting Models ####
plot.hatvalues.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Index Plots of Studentized Residuals: Best Fitting Models ####
plot.studentresid.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Index Plot of Cook's Distances:  Best Fitting Models ####
plot.cooks.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)

#### Influence Plots:  Best Fitting Models ####
plot.cooks.bubble.simple.sibling.regression.best.fitting.models(SIMPLESIBREG$best.fits)
