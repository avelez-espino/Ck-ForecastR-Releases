source("R/simplelogpower/RETRO - Simple Log Power Regression_functions.R")

cat("RETRO - Simple Log Power Regression.R", "\n\n")


## need to refresh the datalist object, as it currently contains only the youngest age!!!

SIMPLELOGPOWER$datafile <- SIMPLELOGPOWER$datafile_original

SIMPLELOGPOWER$datafilesub <- SIMPLELOGPOWER$datafile


SIMPLELOGPOWER$extract_ages <- sort(unique(SIMPLELOGPOWER$datafilesub$Age_Class))
SIMPLELOGPOWER$extract_names <- paste("T",SIMPLELOGPOWER$extract_ages,sep="")
SIMPLELOGPOWER$extract_names <- c("BY",SIMPLELOGPOWER$extract_names)

SIMPLELOGPOWER$tmpsub <- list()
for (i in 1:length(SIMPLELOGPOWER$extract_ages)){
     if (SIMPLELOGPOWER$stockabundance=="Terminal Run"){
     SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Terminal_Run")]
     } else if (SIMPLELOGPOWER$stockabundance=="Escapement") {
      SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Escapement")]
     } else if (SIMPLELOGPOWER$stockabundance=="Production") {
      SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Production")]
     }
}

SIMPLELOGPOWER$list.of.data.frames <- SIMPLELOGPOWER$tmpsub
SIMPLELOGPOWER$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), SIMPLELOGPOWER$list.of.data.frames)

SIMPLELOGPOWER$datafile_new <- SIMPLELOGPOWER$merged.data.frame
names(SIMPLELOGPOWER$datafile_new) <- SIMPLELOGPOWER$extract_names

SIMPLELOGPOWER$datafile <- SIMPLELOGPOWER$datafile_new

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist.avgfive(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)  # CY refers to the T variable with highest age

##========================================================================================================
## youngest age: avgfive
##========================================================================================================

SIMPLELOGPOWER$index.year <- index.year

SIMPLELOGPOWER$result.avgfive.youngest <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.avgfive.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$index.year)

SIMPLELOGPOWER$youngest.age.retro.plot.info.avgfive

SIMPLELOGPOWER$youngest.age.retro.plot.avgfive(SIMPLELOGPOWER$youngest.age.retro.plot.info.avgfive, SIMPLELOGPOWER$stockabundance)


##========================================================================================================
## youngest age: arima
##========================================================================================================

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist.arima(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)  # CY refers to the T variable with highest age

## arima.model.fits  <- arima.model(datalist, boxcoxtransform)

SIMPLELOGPOWER$result.arima.simple.sibling.regression <-  SIMPLELOGPOWER$individual.ages.retro.predictive.performance.arima.youngest( SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$forecastingyear,  SIMPLELOGPOWER$boxcoxtransform, SIMPLELOGPOWER$index.year)

SIMPLELOGPOWER$youngest.age.retro.plot.arima(SIMPLELOGPOWER$youngest.age.retro.plot.info.arima, SIMPLELOGPOWER$stockabundance)


##========================================================================================================
## youngest age: expsmooth
##========================================================================================================

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist.expsmooth(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)


#---------  fit exponential smoothing model -----------------------------------------

## expsmooth.model.fits  <- expsmooth.model(datalist, boxcoxtransform)

SIMPLELOGPOWER$result.expsmooth.simple.sibling.regression <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.expsmooth.youngest(
                                                                  SIMPLELOGPOWER$datalist,
                                                                  SIMPLELOGPOWER$forecastingyear,
                                                                  SIMPLELOGPOWER$boxcoxtransform,
                                                                  SIMPLELOGPOWER$index.year)

SIMPLELOGPOWER$youngest.age.retro.plot.expsmooth(SIMPLELOGPOWER$youngest.age.retro.plot.info.expsmooth, SIMPLELOGPOWER$stockabundance)


##=========================================================================================================
## Simple log power regression
##=========================================================================================================

SIMPLELOGPOWER$result.simplelogpower.regression <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.simplelogpower.regression.youngest(
                                             SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                             SIMPLELOGPOWER$index.year)




#=====================================================================================================================

SIMPLELOGPOWER$individual.ages.retro.plot.simplelogpower(
     SIMPLELOGPOWER$individual.ages.retro.plot.info.simplelogpower,
     SIMPLELOGPOWER$stockabundance,
     j=1)




##=========================================================================================================
## measures of retro performance - avgfive + simplelogpower
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.avgfive.plus.simplelogpower.regression
SIMPLELOGPOWER$result.avgfive.youngest <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.avgfive.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$index.year)

SIMPLELOGPOWER$res.avgfive.simplelogpower.regression <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.simplelogpower.regression.youngest(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression, SIMPLELOGPOWER$index.year)


## call to total.age.retro.predictive.performance.avgfive.plus.simplelogpower.regression
SIMPLELOGPOWER$rmse.results.youngest.age.avgfive.plus.simplelogpower.regression <-
SIMPLELOGPOWER$total.age.retro.predictive.performance.avgfive.plus.simplelogpower.regression(SIMPLELOGPOWER$result.avgfive.youngest, SIMPLELOGPOWER$res.avgfive.simplelogpower.regression)



##=========================================================================================================
## measures of retro performance - arima + sibreg
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.arima.plus.simplelogpower.regression

SIMPLELOGPOWER$result.arima.youngest <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.arima.youngest(
                                       datalist = SIMPLELOGPOWER$datalist,
                                       forecastingyear = SIMPLELOGPOWER$forecastingyear,
                                       boxcoxtransform = SIMPLELOGPOWER$boxcoxtransform,
                                       index = SIMPLELOGPOWER$index.year)


SIMPLELOGPOWER$res.arima.simplelogpower.regression <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.simplelogpower.regression.youngest(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression, SIMPLELOGPOWER$index.year)


## call to total.age.retro.predictive.performance.arima.plus.simplelogpower.regression
SIMPLELOGPOWER$rmse.results.youngest.age.arima.plus.simplelogpower.regression <-
SIMPLELOGPOWER$total.age.retro.predictive.performance.arima.plus.simplelogpower.regression(
      SIMPLELOGPOWER$result.arima.youngest,
      SIMPLELOGPOWER$res.arima.simplelogpower.regression)


##=========================================================================================================
## measures of retro performance - expsmooth + simplelogpower
##=========================================================================================================

## need these before call to total.age.retro.predictive.performance.expsmooth.plus.simplelogpower.regression

SIMPLELOGPOWER$result.expsmooth.youngest <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.expsmooth.youngest(
                                    datalist = SIMPLELOGPOWER$datalist,
                                    forecastingyear = SIMPLELOGPOWER$forecastingyear,
                                    boxcoxtransform = SIMPLELOGPOWER$boxcoxtransform,
                                    index =  SIMPLELOGPOWER$index.year)


SIMPLELOGPOWER$res.expsmooth.simplelogpower.regression <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.simplelogpower.regression.youngest(
                                                                        SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                                                        SIMPLELOGPOWER$index.year)

## call to total.age.retro.predictive.performance.expsmooth.plus.simplelogpower.regression
SIMPLELOGPOWER$rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression <-
SIMPLELOGPOWER$total.age.retro.predictive.performance.expsmooth.plus.simplelogpower.regression(
      SIMPLELOGPOWER$result.expsmooth.youngest,
      SIMPLELOGPOWER$res.expsmooth.simplelogpower.regression)




##=========================================================================================================
## choosing the measure of retro performance (i.e., rmse) which is "best" for forecasting total age
## among avgfive + simplelogpower, arima + simplelogpower, expsmooth + simplelogpower
##=========================================================================================================

SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower <-  SIMPLELOGPOWER$best.rmse.results.youngest.age.simplelogpower(
                                                          SIMPLELOGPOWER$rmse.results.youngest.age.avgfive.plus.simplelogpower.regression,
                                                          SIMPLELOGPOWER$rmse.results.youngest.age.arima.plus.simplelogpower.regression,
                                                          SIMPLELOGPOWER$rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression)

SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower


## rmse.results.youngest.age.avgfive.plus.simplelogpower.regression = SIMPLELOGPOWER$rmse.results.youngest.age.avgfive.plus.simplelogpower.regression

## rmse.results.youngest.age.arima.plus.simplelogpower.regression = SIMPLELOGPOWER$rmse.results.youngest.age.arima.plus.simplelogpower.regression

## rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression = SIMPLELOGPOWER$rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression



###
###  "Cool" plots for the youngest age
###

SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower$method   # "naive forecasting (i.e., average of previous five years)"
                                # "ARIMA forecasting"
                                # "exponential smoothing forecasting"

## youngest.age.retro.plot.avgfive(youngest.age.retro.plot.info.avgfive, stockabundance)
## youngest.age.retro.plot.arima(youngest.age.retro.plot.info.arima, stockabundance)
## youngest.age.retro.plot.expsmooth(youngest.age.retro.plot.info.expsmooth, stockabundance)



###
### Density Plot of Retrospective Forecast Errors: Individual Ages
###

SIMPLELOGPOWER$plot.density.retrospective.forecast.errors.individual.ages.simplelogpower.regression(
      SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower,
      SIMPLELOGPOWER$stockabundance)


###
### Density Plot of Retrospective Forecast Errors: Total Age
###

SIMPLELOGPOWER$plot.density.retrospective.forecast.errors.total.age.simplelogpower.regression(
     SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower,
     SIMPLELOGPOWER$stockabundance)



################################################################################

SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower

## best.rmse.youngest.age <-  best.rmse.results.youngest.age(rmse.results.youngest.age.avgfive.plus.simple.sibling.regression,
##                                                          rmse.results.youngest.age.arima.plus.simple.sibling.regression,
##                                                          rmse.results.youngest.age.expsmooth.plus.simple.sibling.regression)
##
## best.rmse.youngest.age




#*******************************************************************************
#
# Gary's Plot for Individual Ages: Youngest + Older
#
#*******************************************************************************


## COME BACK HERE - November 4, 2014

## j <- 3

SIMPLELOGPOWER$gary.plot.individual.ages.simplelogpower.regression(SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower,
                                                       SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,   # youngest age prediction: avgfive
                                                       SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest,     # youngest age prediction: arima
                                                       SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest, # youngest age prediction: expsmooth
                                                       SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression, # older ages prediction: log power regression (best model)
                                                       SIMPLELOGPOWER$forecastingyear,
                                                       j=3)




#*******************************************************************************
#
# Gary's Plot for Total Age:
#
#*******************************************************************************

SIMPLELOGPOWER$gary.plot.total.age.simplelogpower.regression(SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower,
                                                 SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models,  # total age prediction
                                                 SIMPLELOGPOWER$forecastingyear)




#===============================================================================================================================

##
## Table of results for candidate models for youngest age: avgfive, arima, expsmooth
##


SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest
SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest
SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest


SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest <- list()
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$Model <- c("Naive (Average of Previous Five Years)",
                                                             "ARIMA",
                                                             "Exponential Smoothing")

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.ctr <- c( round(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.ctr),
                                                                      round(SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.ctr),
                                                                      round(SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.ctr))

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr <- c( round(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.lwr),
                                                                     round(SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.lwr),
                                                                     round(SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.lwr))
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr <- as.numeric(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr)

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr <- c(round(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.upr),
                                                               round(SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.upr),
                                                               round(SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.upr))
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr <- as.numeric(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLELOGPOWER$rmse.total.age.avgfive <- SIMPLELOGPOWER$rmse.results.youngest.age.avgfive.plus.simplelogpower.regression$rmse.total
SIMPLELOGPOWER$rmse.total.age.arima  <- SIMPLELOGPOWER$rmse.results.youngest.age.arima.plus.simplelogpower.regression$rmse.total
SIMPLELOGPOWER$rmse.total.age.expsmooth  <- SIMPLELOGPOWER$rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression$rmse.total

SIMPLELOGPOWER$rmse.total.age <- c(SIMPLELOGPOWER$rmse.total.age.avgfive, SIMPLELOGPOWER$rmse.total.age.arima, SIMPLELOGPOWER$rmse.total.age.expsmooth)

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$rmse.total.age <- SIMPLELOGPOWER$rmse.total.age  ## recall that this rmse is optimized for
                                                                                    ## prediction of total age!!!


SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest <- do.call(cbind.data.frame, SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest)

usePackage("scales")
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.ctr <- comma(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.ctr)
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr <- comma(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr)
SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr <- comma(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.int <- paste0(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.lwr,
                                                                   " - ",
                                                                   SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest$PI.upr)

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest <- subset(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest,
                                                            select=c(Model, PI.ctr,  PI.int, rmse.total.age))
names(SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest) <-  c("Model", "Point Forecast", "Interval Forecast", "RMSE")

SIMPLELOGPOWER$table.results.individual.ages.all.models.youngest



#=====================================================================================================================================
#
# Best RMSE
#
#######################################################################################################################################


SIMPLELOGPOWER$best.rmse.youngest.age <-  SIMPLELOGPOWER$best.rmse.results.youngest.age.simplelogpower(SIMPLELOGPOWER$rmse.results.youngest.age.avgfive.plus.simplelogpower.regression,
                                                          SIMPLELOGPOWER$rmse.results.youngest.age.arima.plus.simplelogpower.regression,
                                                          SIMPLELOGPOWER$rmse.results.youngest.age.expsmooth.plus.simplelogpower.regression)

SIMPLELOGPOWER$total.index.simplelogpower <- SIMPLELOGPOWER$best.rmse.youngest.age$index.min.rmse.total.age



#========================================================================================================================================

###
### plot forecast vs. actual (individual ages, log power regression)
###

SIMPLELOGPOWER$plot.results.afe.individual.ages.retro.simplelogpower.regression(SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower)


#==============================================================================================================================

###
### plot forecasted vs. actual (total age, log power regression)
###

SIMPLELOGPOWER$plot.results.afe.total.age.retro.simplelogpower.regression(
    SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower, stockabundance)

