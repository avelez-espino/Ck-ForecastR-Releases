# Script to test new modules PART 6: Test the full sequence for NoAge data

# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")





############################################################
# Read in Sample Data Files and prep the Data
############################################################

samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")
names(samplefile.withage)
head(samplefile.withage)


samplefile.noage <- read.csv("../inst/extdata/SampleFile_WithoutAge.csv")
names(samplefile.noage)
head(samplefile.noage)

source.modules("../R/")
sample.dat.age <-  prepData(samplefile.withage,out.labels="v2")
sample.dat.age

source.modules("../R/")
sample.dat.noage <-  prepData(samplefile.noage,out.labels="v2")
sample.dat.noage



###############################################################
# test the estimation functions
##############################################################

source.modules("../R/")
data.in <- sample.dat.noage$data$Total[,"Total"]

estimation.functions[["Naive"]]$estimator(model.data = data.in,avg.yrs=3)
estimation.functions[["TimeSeriesArima"]]$estimator(model.data = data.in,settings=list(BoxCox=FALSE))
estimation.functions[["TimeSeriesExpSmooth"]]$estimator(model.data = data.in,settings=list(BoxCox=FALSE))



###############################################################
# test the fitModel() and plotModelFit() functions
##############################################################


source.modules("../R/")
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat.noage$data, settings = list(avg.yrs=3),tracing=FALSE)
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat.noage$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat.noage$data, settings = list(BoxCox=FALSE),tracing=FALSE)

# just to show that error message works
fitModel(model= "SibRegSimple", data = sample.dat.noage$data, settings = list(avg.yrs=3),tracing=FALSE)


source.modules("../R/")
plotModelFit(sample.fit.naive, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
plotModelFit(sample.fit.arima, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))


###############################################################
# test the calcFC() functions (and components)
##############################################################

source.modules("../R/")
sub.fcdata(fit = sample.fit.naive,data = sample.dat.noage$data, fc.yr=2017)
sub.fcdata(fit = sample.fit.arima,data = sample.dat.noage$data, fc.yr=2017)
sub.fcdata(fit = sample.fit.expsmooth,data = sample.dat.noage$data, fc.yr=2017)



source.modules("../R/")
sub.pt.fc(fit=sample.fit.naive,data.source=sample.dat.noage$data ,fc.yr = 2017)
sub.pt.fc(fit=sample.fit.arima,data.source=sample.dat.noage$data ,fc.yr = 2017)
sub.pt.fc(fit=sample.fit.expsmooth,data.source=sample.dat.noage$data ,fc.yr = 2017)


source.modules("../R/")
calcFC(fit.obj= sample.fit.naive,data = sample.dat.noage$data, fc.yr= 2017,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)
calcFC(fit.obj= sample.fit.arima,data = sample.dat.noage$data, fc.yr= 2017,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	
calcFC(fit.obj= sample.fit.expsmooth,data = sample.dat.noage$data, fc.yr= 2017,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	

	
		
###############################################################
# test the doRetro() function
##############################################################


source.modules("../R/")
tmp <- doRetro(model= "Naive", data = sample.dat.noage$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(avg.yrs=3), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 



tmp <- doRetro(model= "TimeSeriesArima", data = sample.dat.noage$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(BoxCox=FALSE), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 




tmp <- doRetro(model= "TimeSeriesExpSmooth", data = sample.dat.noage$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(BoxCox=FALSE), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 




###############################################################
# RUNNING THE FULL SEQUENCE FOR MULTIPLE MODELS


#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")

# Inputs
data.use <- read.csv("../inst/extdata/SampleFile_WithoutAge.csv")  # read in raw data

settings.use <- list(Naive = list(model.type="Naive", settings=list(avg.yrs=3)),
                     TimeSeriesArima = list(model.type="TimeSeriesArima", settings=list(BoxCox=FALSE)),
                     TimeSeriesExpSmooth = list(model.type="TimeSeriesExpSmooth", settings=list(BoxCox=FALSE))
				)

# multiresults.ptfconly <- multiFC(data.file=data.use,settings.list=settings.use,out.type="ptfconly")
# multiresults.ptfconly

source.modules("../R/")
multiresults.retro <- multiFC(data.file=data.use,settings.list=settings.use,out.type="short", do.retro = TRUE)

names(multiresults.retro)
names(multiresults.retro$retro.pm)

str(multiresults.retro)

multiresults.retro$retro.pm

saveRDS(multiresults.retro, "../OUTPUT/multiresults.retro.rds")




