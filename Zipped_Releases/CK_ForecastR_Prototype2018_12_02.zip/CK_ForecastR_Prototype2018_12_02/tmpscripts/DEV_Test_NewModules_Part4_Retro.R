# testing the retrospective calcs

#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")




# read in and prep the data
samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

# test the data extract function
data.extract(sample.dat$data,yrs=2005:2017,option="obs")
data.extract(sample.dat$data,yrs=2009,option="retro")


source.modules("../R/")
tmp <- doRetro(model= "SibRegSimple", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = NULL, 
				fc.settings = list(boot=NULL),
				tracing=FALSE,out.type="short")

names(tmp)


tmp <- doRetro(model= "SibRegSimple", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = NULL, 
				fc.settings = list(boot=NULL),
				tracing=FALSE,out.type="full")

names(tmp)
names(tmp$retro.fits)
names(tmp$retro.fits$FC2007)
names(tmp$retro.fits$FC2007$"Age 5")


tmp <- doRetro(model= "SibRegLogPower", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = NULL, 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 




tmp <- doRetro(model= "SibRegKalman", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = NULL, 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 





tmp <- doRetro(model= "Naive", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(avg.yrs=3), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 



tmp <- doRetro(model= "TimeSeriesArima", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(BoxCox=FALSE), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 




tmp <- doRetro(model= "TimeSeriesExpSmooth", data = sample.dat$data, 
				retro.settings = list(min.yrs=15), 
				fit.settings = list(BoxCox=FALSE), 
				fc.settings = list(boot=NULL),
				tracing=FALSE)

tmp 

