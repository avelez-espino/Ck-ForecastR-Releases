# Script to plot the  FC Calcs: first 2 parts replicate steps in script 3

#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")



############################################################
# Read in Sample Data File, prep the data, and fit alternative models
############################################################
# For detailed tests of each step: check DEV_Test_NewModules_Part1_ModelFitting.R

# read in data
samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")


# prep dat for model fitting
source("../R/Module_prepData.R")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

# fit the models
source("../R/Module_Sub_EstimationFunctions.R")
source("../R/Module_fitModel.R")

sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)
sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat$data, settings = NULL,tracing=FALSE)
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat$data, settings = list(avg.yrs=3),tracing=FALSE)
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
source.modules("../R/")
sample.fit.sibregkalman <- fitModel(model= "SibRegKalman", data = sample.dat$data, settings = NULL,tracing=FALSE)


#########################################################
#  Calculate the Forecasts
#########################################################


# testing the full module - pt fc only

source("../R/Module_calcFC.R")

fc.simplesibreg <- calcFC(fit.obj= sample.fit.simplesibreg,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE, settings = NULL, tracing=FALSE)

fc.logpower <- calcFC(fit.obj= sample.fit.logpower,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=FALSE)

fc.naive <- calcFC(fit.obj= sample.fit.naive,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)


fc.arima <- calcFC(fit.obj= sample.fit.arima,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	



fc.expsmooth <- calcFC(fit.obj= sample.fit.expsmooth,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	


fc.sibregkalman <- calcFC(fit.obj= sample.fit.sibregkalman,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE, settings = NULL, tracing=FALSE)



names(sample.fit.sibregkalman$"Age 5")
sample.fit.sibregkalman$"Age 5"$data
sample.fit.sibregkalman$"Age 5"$obs.values
sample.fit.sibregkalman$"Age 5"$fitted.values
sample.fit.sibregkalman$"Age 5"$run.yrs


names(sample.fit.naive$"Age 5")
sample.fit.naive$"Age 5"$data
sample.fit.naive$"Age 5"$obs.values
sample.fit.naive$"Age 5"$fitted.values
sample.fit.naive$"Age 5"$run.yrs




#######################
# building blocks

source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")

fit.in <- sample.fit.logpower
fc.in <-  fc.logpower
age.in <- "all"
plot.in <- "fitted_ts"   # "fitted_ts"  "resid_ts"  "resid_hist"   "resid_qq"


#plotModelFit(fit.in, options= list(plot.which = plot.in,age.which=age.in,plot.add=FALSE), fc.add= NULL)
plotModelFit(fit.in, options= list(plot.which = plot.in,age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 


plotModelFit(fit.in, options= list(plot.which = "resid_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 

















		
