# Script to test new modules PART 3: FC Calcs

#########
# Read in all the modules
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


############################################################
# Read in Sample Data File, prep the data, and fit alternative models
############################################################
# For detailed tests of each step: check DEV_Test_NewModules_Part1_ModelFitting.R

# read in data
samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")


# prep dat for model fitting
source("../R/Module_prepData.R")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

# fit the models
source("../R/Module_Sub_EstimationFunctions.R")
source("../R/Module_fitModel.R")

sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)
sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat$data, settings = NULL,tracing=FALSE)
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat$data, settings = list(avg.yrs=3),tracing=FALSE)
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
source.modules("../R/")
sample.fit.sibregkalman <- fitModel(model= "SibRegKalman", data = sample.dat$data, settings = NULL,tracing=FALSE)




names(sample.fit.simplesibreg)
names(sample.fit.simplesibreg$"Age 5")
summary(sample.fit.simplesibreg$"Age 5"$fit.obj)
summary(sample.fit.simplesibreg$"Age 5"$fit.obj)$sigma

sample.fit.sibregkalman$"Age 5"

#########################################################
#  Calculate the Forecasts
#########################################################


# testing the input data extraction subroutine
source.modules("../R/")
sub.fcdata(fit = sample.fit.simplesibreg,data = sample.dat$data, fc.yr=2018)
sub.fcdata(fit = sample.fit.logpower,data = sample.dat$data, fc.yr=2018)
sub.fcdata(fit = sample.fit.naive,data = sample.dat$data, fc.yr=2018)
sub.fcdata(fit = sample.fit.arima,data = sample.dat$data, fc.yr=2018)
sub.fcdata(fit = sample.fit.expsmooth,data = sample.dat$data, fc.yr=2018)
sub.fcdata(fit = sample.fit.sibregkalman,data = sample.dat$data, fc.yr=2018)



# testing the point forecast calculation subroutine
source.modules("../R/")
sub.pt.fc(fit=sample.fit.simplesibreg,data.source=sample.dat$data ,fc.yr = 2018)
sub.pt.fc(fit=sample.fit.logpower,data.source=sample.dat$data ,fc.yr = 2018)
sub.pt.fc(fit=sample.fit.naive,data.source=sample.dat$data ,fc.yr = 2018)

source.modules("../R/")
sub.pt.fc(fit=sample.fit.sibregkalman,data.source=sample.dat$data ,fc.yr = 2018)



data.tmp <- sample.dat$data$"Age 6"[,3]
data.tmp 

arima.test <- auto.arima(data.tmp, allowmean=TRUE, allowdrift=FALSE)
predict(arima.test,n.ahead=1)


arima.fit.test <- estimation.functions[["TimeSeriesArima"]]$estimator(model.data = data.tmp,settings=list(BoxCox=FALSE))
names(arima.fit.test)
arima.fit.test
as.numeric(predict(arima.fit.test$fit.obj,n.ahead=1)$pred)


sub.pt.fc(fit=sample.fit.arima,data.source=sample.dat$data ,fc.yr = 2018)
sub.pt.fc(fit=sample.fit.expsmooth,data.source=sample.dat$data ,fc.yr = 2018)

source("../R/Module_fitModel.R")
sub.pt.fc(fit=sample.fit.expsmooth,data.source=sample.dat$data ,fc.yr = 2018)




# testing the full module - pt fc only

source("../R/Module_calcFC.R")

calcFC(fit.obj= sample.fit.simplesibreg,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE, settings = NULL, tracing=FALSE)

calcFC(fit.obj= sample.fit.logpower,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=FALSE)

calcFC(fit.obj= sample.fit.naive,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)


calcFC(fit.obj= sample.fit.arima,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	



calcFC(fit.obj= sample.fit.expsmooth,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE,  settings = NULL, tracing=TRUE)	


calcFC(fit.obj= sample.fit.sibregkalman,data = sample.dat$data, fc.yr= 2018,  
		do.boot=FALSE, settings = NULL, tracing=FALSE)

		
