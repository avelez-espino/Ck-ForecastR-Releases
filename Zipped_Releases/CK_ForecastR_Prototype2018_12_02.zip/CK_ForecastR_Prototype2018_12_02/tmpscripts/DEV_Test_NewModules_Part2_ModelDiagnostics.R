# Script to test new modules PART 2: Model Diagnostics


############################################################
# Read in Sample Data File, prep the data, and fit alternative models
############################################################
# Fore detailed tests of each step: check DEV_Test_NewModules_Part1_ModelFitting.R

# read in data
samplefile.withage <- read.csv("../inst/extdata/SampleFile_WithAge.csv")


# prep dat for model fitting
source("../R/Module_prepData.R")
sample.dat <-  prepData(samplefile.withage,out.labels="v2")

# fit the models
source("../R/Module_Sub_EstimationFunctions.R")
source("../R/Module_fitModel.R")
source("../R/Module_Sub_PerformanceMeasures.R")

sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)
names(sample.fit.simplesibreg)
names(sample.fit.simplesibreg$"Age 6")
sample.fit.simplesibreg$"Age 3"
sample.fit.simplesibreg$"Age 3"$residuals
sample.fit.simplesibreg$"Age 3"$obs.values


sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat$data, settings = NULL,tracing=FALSE)

sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)




############################################################
# plot model diagnostics : Illustrate plotting options
############################################################

source("../R/Module_plotModelFit.R")
# options for plot.which: "all","fitvsobs","fitted_ts", Not yet: "curvefit"
# options for age.which: "all" or string vector like this c("Age 5","Age 6")

# some examples 
# To see on screen: skip the pdf() call and run these 1 at a time

pdf("../OUTPUT/TEST_ModelDiagnosticPlots.pdf",onefile=TRUE,height=8.5,width=11)

# fitted vs observed scatterplot
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitvsobs",age.which="Age 6",plot.add=FALSE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))



par(mfrow=c(2,2))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitvsobs",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitvsobs",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitvsobs",age.which="Age 6",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitvsobs",age.which="Age 6",plot.add=TRUE))



# fitted time series
source("../R/Module_plotModelFit.R")
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitted_ts",age.which="Age 6",plot.add=FALSE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))

par(mfrow=c(2,2))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitted_ts",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitted_ts",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitted_ts",age.which="Age 6",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitted_ts",age.which="Age 6",plot.add=TRUE))


# residual time series
source("../R/Module_plotModelFit.R")
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_ts",age.which="Age 6",plot.add=FALSE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))


par(mfrow=c(2,2))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_ts",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_ts",age.which="Age 5",plot.add=TRUE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_ts",age.which="Age 6",plot.add=TRUE))
plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_ts",age.which="Age 6",plot.add=TRUE))



# residual histogram
source("../R/Module_plotModelFit.R")
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_hist",age.which="Age 6",plot.add=FALSE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))



# residual qqplot
source("../R/Module_plotModelFit.R")
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_qq",age.which="Age 6",plot.add=FALSE))
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))

plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))

dev.off()




############################################################
# plot model diagnostics : test for all models
############################################################

# source the functions 
source("../R/3c_HelperFunctions_ModelSetup.R")
source.modules("../R/")


pdf("../OUTPUT/TEST_ModelDiagnosticPlots_ModelTesting.pdf",onefile=TRUE,height=8.5,width=11)

# Fit and plot the Simple SibReg model
sample.fit.simplesibreg <- fitModel(model= "SibRegSimple", data = sample.dat$data, settings = NULL,tracing=FALSE)
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="Simple Sib Reg",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="Simple Sib Reg",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="Simple Sib Reg",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="Simple Sib Reg",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.simplesibreg, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="Simple Sib Reg",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)



# Fit and plot the LOGPOWER model
sample.fit.logpower <- fitModel(model= "SibRegLogPower", data = sample.dat$data, settings = NULL,tracing=FALSE)
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="Simple Log Power",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.logpower, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="Simple Log Power",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="Simple Log Power",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="Simple Log Power",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.logpower, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="Simple Log Power",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)

# Fit and plot the NAIVE model
sample.fit.naive <- fitModel(model= "Naive", data = sample.dat$data, settings = list(avg.yrs=3),tracing=FALSE)
plotModelFit(sample.fit.naive, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="Naive",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.naive, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="Naive",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.naive, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="Naive",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.naive, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="Naive",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.naive, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="Naive",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)


# Fit and plot the ARIMA model	
sample.fit.arima <- fitModel(model= "TimeSeriesArima", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
names(sample.fit.arima[[1]])
plotModelFit(sample.fit.arima, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="ARIMA",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.arima, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="ARIMA",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.arima, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="ARIMA",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.arima, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="ARIMA",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.arima, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="ARIMA",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)



sample.fit.expsmooth <- fitModel(model= "TimeSeriesExpSmooth", data = sample.dat$data, settings = list(BoxCox=FALSE),tracing=FALSE)
names(sample.fit.expsmooth[[1]])
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="Exp Smooth",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="Exp Smooth",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="Exp Smooth",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="Exp Smooth",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.expsmooth, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="Exp Smooth",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)



sample.fit.sibregKF <- fitModel(model= "SibRegKalman", data = sample.dat$data, settings = list(X=NA),tracing=FALSE)
names(sample.fit.sibregKF[[1]])
plotModelFit(sample.fit.sibregKF, options= list(plot.which = "fitvsobs",age.which="all",plot.add=FALSE))
title(main="Sib Reg Kalman",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.sibregKF, options= list(plot.which = "fitted_ts",age.which="all",plot.add=FALSE))
title(main="Sib Reg Kalman",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.sibregKF, options= list(plot.which = "resid_qq",age.which="all",plot.add=FALSE))
title(main="Sib Reg Kalman",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.sibregKF, options= list(plot.which = "resid_hist",age.which="all",plot.add=FALSE))
title(main="Sib Reg Kalman",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)
plotModelFit(sample.fit.sibregKF, options= list(plot.which = "resid_ts",age.which="all",plot.add=FALSE))
title(main="Sib Reg Kalman",outer=TRUE,line=-2,col.main="darkblue",cex.main=1.8)








dev.off()


