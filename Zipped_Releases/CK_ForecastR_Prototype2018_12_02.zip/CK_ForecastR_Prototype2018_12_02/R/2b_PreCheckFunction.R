# FUNCTION CALL FOR MODEL PRE_CHECK IN FORECASTR GUI

# This file uses model fitting functions extracted from the original model source code pieces
# The model fitting functions are combined into a single source in "3a_HelperFunctions_ModelFitting.R"

# the steps are here organized inside a single umbrella function that
# accepts a single input object from the GUI.

# Note: Michael Folkes is concurrently reworking the core model code
# (e.g. streamlining, extensions). At some point, the 2 pieces will be merged,
# but for now this is set up to communicate with the original code and retains
# the current variable names etc.


forecastR_ModelPrecheck <- function(input.obj){

	source("3a_HelperFunctions_ModelFitting.R")
	source("3b_HelperFunctions_ReportCreation.R")











}
