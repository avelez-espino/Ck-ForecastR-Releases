# THIS IS A REPOSITORY OF MODEL FITTING FUNCTIONS EMBEDDED IN THE ORIGINAL FORECASTR CODE
# These are from within each of the sub-folders within "R Code"



model.functions <- list(Title="Inventory of Model Fitting Functions")



##################################################################################################
# n3
#--------- helper function for computing the average of the past n years of a time series -----
# source: "R code / n3 / Review Code - Average Three.r" and corresponding versions for Avg1 and Avg 5


model.functions$naive.avgret  <- function(series) {

	 # series is  a vector of abundance values (CHECK DETAILS)
     # n = length of time series 
     # n must be strictly greater than 3!!
     
     n <- length(series)
     
     fitted <- rep(NA,n)
     residuals <- rep(NA,n)
     
     for (k in 4:n) {
          fitted[k] <- (series[k-3] + series[k-2] + series[k-1])/3
          residuals[k] <- series[k] - fitted[k]
     }
      
     fcast <- (series[n-2] + series[n-1] + series[n])/3   # point-forecast for series[n+1]   
     
     out <- list()
     out$x <- series
     out$mean <- fcast
     out$fitted <- fitted
     out$residuals <- residuals 
     
     return(out)
           
} 





#---------  fit naive model (average of past 5 years) -----------------------------------------

model.functions$n5.fit  <- function(series) {


     # n = length of time series
     # n must be strictly greater than 5!!

     n <- length(series)

     fitted <- rep(NA,n)
     residuals <- rep(NA,n)

     for (k in 6:n) {
          fitted[k] <- (series[k-5] + series[k-4] + series[k-3] + series[k-2] + series[k-1])/5
          residuals[k] <- series[k] - fitted[k]
     }

     fcast <- (series[n-4]+ series[n-3] + series[n-2] + series[n-1] + series[n])/5   # point-forecast for series[n+1]

     out <- list()
     out$x <- series
     out$mean <- fcast
     out$fitted <- fitted
     out$residuals <- residuals

     return(out)

}






