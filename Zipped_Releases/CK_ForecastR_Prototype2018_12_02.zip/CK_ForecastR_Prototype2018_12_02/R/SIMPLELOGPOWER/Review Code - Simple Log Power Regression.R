######################################################################################################
# Simple Log Power Regression Models - Prediction Results
# Date Stamp: February 10, 2017
######################################################################################################
source("R/simplelogpower/Review Code - Simple Log Power Regression_functions.R")

cat("Review Code - Simple Log Power Regression.R", "\n\n")

######################################################################################################

## SIMPLELOGPOWER <- new.env()

## SIMPLELOGPOWER$datafile_original <-

## SIMPLELOGPOWER$datafile <- SIMPLELOGPOWER$datafile_original

## SIMPLELOGPOWER$stockabundance <- SIMPLELOGPOWER$datafile$Stock_Abundance[1]
## SIMPLELOGPOWER$stockname <- SIMPLELOGPOWER$datafile$Stock_Name[1]
## SIMPLELOGPOWER$stockspecies <- SIMPLELOGPOWER$datafile$Stock_Species[1]
## SIMPLELOGPOWER$forecastingyear <- SIMPLELOGPOWER$datafile$Forecasting_Year[1]

## usePackage("stringr")
## SIMPLELOGPOWER$forecastingyear <- str_replace_all(SIMPLELOGPOWER$forecastingyear, "\n","")
## SIMPLELOGPOWER$forecastingyear <- as.numeric(SIMPLELOGPOWER$forecastingyear)


SIMPLELOGPOWER$datafile <- datafile_original

SIMPLELOGPOWER$stockabundance <- SIMPLELOGPOWER$datafile$Stock_Abundance[1]
SIMPLELOGPOWER$stockname <- SIMPLELOGPOWER$datafile$Stock_Name[1]
SIMPLELOGPOWER$stockspecies <- SIMPLELOGPOWER$datafile$Stock_Species[1]
SIMPLELOGPOWER$forecastingyear <- SIMPLELOGPOWER$datafile$Forecasting_Year[1]

#=======================================================================================================


SIMPLELOGPOWER$datafile_variables <- SIMPLELOGPOWER$datafile_extract_age_class(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$stockabundance)


#=======================================================================================================


# prepare data and model formulas for simple log power regressions without environmental covariates

SIMPLELOGPOWER$datafile_variables <- SIMPLELOGPOWER$datafile_extract_age_class(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$stockabundance)

SIMPLELOGPOWER$data_and_model_formulas_simplelogpower <-  SIMPLELOGPOWER$prepare_data_and_model_formulas_simplelogpower(SIMPLELOGPOWER$datafile_variables)

SIMPLELOGPOWER$data_and_model_formulas_simplelogpower

#================================================================================


SIMPLELOGPOWER$fits.simplelogpower <-  SIMPLELOGPOWER$simplelogpower_regression_model_fits(SIMPLELOGPOWER$data_and_model_formulas_simplelogpower)

#===============================================================================


## Important Reference on working with AIC:
## http://theses.ulaval.ca/archimede/fichiers/21842/apa.html

## Reference on differences in computing AIC values and on AICcmodavg package
## http://r.789695.n4.nabble.com/R-s-AIC-values-differ-from-published-values-td4384952.html



SIMPLELOGPOWER$results_model_selection_simplelogpower <-  SIMPLELOGPOWER$model_selection_results_simplelogpower(SIMPLELOGPOWER$fits.simplelogpower)

SIMPLELOGPOWER$results_model_selection_simplelogpower


#=================================================================================================


SIMPLELOGPOWER$model_selection_table_updated_simplelogpower(SIMPLELOGPOWER$results_model_selection_simplelogpower)


#============================================================================================

## not sure yet how to handle model selection - single best model or model averaging?
## For now: choose the model with Delta AIC = 0 and with largest Akaike weight

SIMPLELOGPOWER$model_weights_simplelogpower <- SIMPLELOGPOWER$model_selection_delta_AIC_and_Akaike_weights_simplelogpower(SIMPLELOGPOWER$results_model_selection_simplelogpower)

## usePackage("stringr")
## SIMPLELOGPOWER$model_weights_simplelogpower$Model <- str_replace_all(SIMPLELOGPOWER$model_weights_simplelogpower$Model,"NA ","")
## SIMPLELOGPOWER$model_weights_simplelogpower$Model <- str_replace_all(SIMPLELOGPOWER$model_weights_simplelogpower$Model," NA","")

#===============================================================================================

## select the best log power regression model for each age class

## not sure yet how to handle model selection - single best model or model averaging?
## For now: choose the model with Delta AIC = 0 and with largest Akaike weight

SIMPLELOGPOWER$best_fitting_model_for_each_age_class_simplelogpower <-  SIMPLELOGPOWER$select_best_fitting_model_for_each_age_class_simplelogpower(SIMPLELOGPOWER$results_model_selection_simplelogpower)

SIMPLELOGPOWER$best_fitting_model_for_each_age_class_simplelogpower

#====================================================================================


## model summary for "best fitting model" for each age class

SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower <- SIMPLELOGPOWER$summary_output_best_fitting_model_for_each_age_class_simplelogpower(
                                                                            SIMPLELOGPOWER$fits.simplelogpower,
                                                                            SIMPLELOGPOWER$results_model_selection_simplelogpower)


SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower

SIMPLELOGPOWER$format_results_best_fitting_model_for_each_age_class_simplelogpower(SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower,i=1)

SIMPLELOGPOWER$best.fits.simplelogpower <- SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower




#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm


SIMPLELOGPOWER$point_forecast_best_model_for_each_age_class_simplelogpower <- SIMPLELOGPOWER$point.forecast.best.fitting.model.for.each.age.class.simplelogpower(
                                                                     SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower,
                                                                     SIMPLELOGPOWER$forecastingyear,
                                                                     SIMPLELOGPOWER$datafile_variables)


SIMPLELOGPOWER$point_forecast_best_model_for_each_age_class_simplelogpower



#-----------------------------------------------------------------------------------------
# Barplot and time series plot representation of point forecast of age-specific abundance (individual age, simplelogpower)
#-----------------------------------------------------------------------------------------

#bug here
SIMPLELOGPOWER$barplot.forecasted.values.individual.ages.simplelogpower(SIMPLELOGPOWER$point_forecast_best_model_for_each_age_class_simplelogpower, SIMPLELOGPOWER$forecastingyear, i=2)




#====================================================================================
# Compute Interval Forecasts
#====================================================================================


#---- "best: sibling regression model forecast -----------------------------------------------------------------


## B <- 9999

SIMPLELOGPOWER$B <- B

SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression <- SIMPLELOGPOWER$best.simplelogpower.regression.model.forecast(SIMPLELOGPOWER$datafile_variables,
                                                                                                 SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower,
                                                                                                 SIMPLELOGPOWER$forecastingyear,
                                                                                                 B = SIMPLELOGPOWER$B)


#================================================================================================



SIMPLELOGPOWER$PI.ctr <- NULL
SIMPLELOGPOWER$PI.lwr <- NULL
SIMPLELOGPOWER$PI.upr <- NULL
# PI.med <- NULL
SIMPLELOGPOWER$PI.sim <- NULL
SIMPLELOGPOWER$nms <- NULL

for (k in 1:length(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression)){

     SIMPLELOGPOWER$PI.ctr <- c(SIMPLELOGPOWER$PI.ctr,
                          SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression[[k]]$p)

     SIMPLELOGPOWER$PI.lwr <- c(SIMPLELOGPOWER$PI.lwr,
                          SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression[[k]]$p.lwr)

     SIMPLELOGPOWER$PI.upr <- c(SIMPLELOGPOWER$PI.upr,
                          SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression[[k]]$p.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.expsmooth[[k]]$PI.median)

     SIMPLELOGPOWER$PI.sim <- cbind(SIMPLELOGPOWER$PI.sim, SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression[[k]]$y.star.boot)

     SIMPLELOGPOWER$form <-  as.formula(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression[[k]]$model.formula)
     usePackage("formula.tools")

     SIMPLELOGPOWER$nms <- c(SIMPLELOGPOWER$nms, lhs.vars(SIMPLELOGPOWER$form))

}

colnames(SIMPLELOGPOWER$PI.sim) <- SIMPLELOGPOWER$nms


SIMPLELOGPOWER$PI.lwr[SIMPLELOGPOWER$PI.lwr < 0] <- 0
SIMPLELOGPOWER$PI.upr[SIMPLELOGPOWER$PI.upr < 0] <- 0

SIMPLELOGPOWER$PI.ctr <- round(SIMPLELOGPOWER$PI.ctr)
SIMPLELOGPOWER$PI.lwr <- round(SIMPLELOGPOWER$PI.lwr)
SIMPLELOGPOWER$PI.upr <- round(SIMPLELOGPOWER$PI.upr)


SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression <- data.frame(PI.ctr = SIMPLELOGPOWER$PI.ctr,
                                                              PI.lwr = SIMPLELOGPOWER$PI.lwr,
                                                              PI.upr = SIMPLELOGPOWER$PI.upr)

SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression.no.comma <- data.frame(PI.ctr = SIMPLELOGPOWER$PI.ctr,
                                                                       PI.lwr = SIMPLELOGPOWER$PI.lwr,
                                                                       PI.upr = SIMPLELOGPOWER$PI.upr)


## PI.individual.ages.complex.sibling.regression

usePackage("scales")

SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression <- comma(SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression)

## PI.individual.ages.complex.sibling.regression

SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression.sim <- SIMPLELOGPOWER$PI.sim



#=============================================================================================================
# simplelogpower: Visual representation of interval forecast of age-specific abundance (individual age, sibreg)
#==============================================================================================================

## bestfits <- results_best_fitting_model_for_each_age_class
## pointforecasts <- point_forecast_best_model_for_each_age_class
## intervalforecasts <-   PI.individual.ages.complex.sibling.regression.no.comma

SIMPLELOGPOWER$scatterplot.forecasted.values.and.forecast.intervals.individual.ages.simplelogpower.regression(
   bestfits = SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower,
   pointforecasts = SIMPLELOGPOWER$point_forecast_best_model_for_each_age_class_simplelogpower,
   intervalforecasts = SIMPLELOGPOWER$PI.individual.ages.simplelogpower.regression.no.comma,
   forecastingyear = SIMPLELOGPOWER$forecastingyear,
   i=1)


#######################################################################################################
#######################################################################################################
##
## Model Diagnostics for "Best" Fitting Models
##
#######################################################################################################
#######################################################################################################



###
### Plot of Residuals vs. Fitted Values: Best Fitting Models
###

SIMPLELOGPOWER$plot.residuals.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)


###
### Histogram of Residuals: Best Fitting Models
###

SIMPLELOGPOWER$plot.histresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

###
### Density Plots of Residuals: Best Fitting Models
###


SIMPLELOGPOWER$plot.densresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

###
### ACF Plots of Residuals: Best Fitting Models
###

SIMPLELOGPOWER$plot.acfresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

###
### PACF Plots of Residuals : Best Fitting Models
###


SIMPLELOGPOWER$plot.pacfresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

## http://docs.ggplot2.org/0.9.3.1/geom_vline.html

###
### Time Series Plot of Residuals: Best Fitting Models
###

SIMPLELOGPOWER$plot.timeresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

###
### Index Plot of Leverage Values: Best Fitting Models
###

SIMPLELOGPOWER$plot.hatvalues.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)

###
### Index Plots of Studentized Residuals: Best Fitting Models
###

SIMPLELOGPOWER$plot.studentresid.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)


###
### Index Plot of Cook's Distances:  Best Fitting Models
###

SIMPLELOGPOWER$plot.cooks.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)


###
### Influence Plots:  Best Fitting Models
###

SIMPLELOGPOWER$plot.cooks.bubble.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower)
