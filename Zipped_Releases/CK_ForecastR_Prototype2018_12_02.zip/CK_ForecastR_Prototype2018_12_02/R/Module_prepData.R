# This function takes replicates the steps from two  functions
# 	 datalist.XYZ.pre()
#    datalist.XYZ()

# NOTES
# datafile_extract_age_class() from  simple sibreg does the same as the 
# datalist.XYZ() from the naive models and the pre=code for that which is now in a new
# function	 datalist.XYZ.pre()
# However for SimpleSibReg (and SimpleLogPower?) the labels are different
# => handling all this in the new prepData() module, with an options on the labels.


# it also incorporates a new data converter function for
#  old and new data formats



prepData <- function(datafile,out.labels = "v1"){
# datafile is a csv file in either the old format (withage differs from withoutage)
# or the new format (all files have the same basic format)

# out.labels = "v1" to match what the old code uses for N1,N3,N5
# 				"v2" to match what old code uses for SIMPLESIBREG, SIMPLELOGPOWER
# This is necessary to retain old functions where possible.
# Over the long-term, should fix this!


# old format required columns: TBI
# new format required columns: TBI

# Check file to identify format
# 3 possibilities: OldWithAge, OldWithoutAge, New
# Only OldWithAge and OldWithoutAge being implemented for now

if(sum(c("Age_Class","Brood_Year") %in% names(datafile))==2){file.type <- "OldWithAge"}
if(sum(c("Age_Class","Brood_Year") %in% names(datafile))==0){file.type <- "OldWithoutAge"}

library(stringr)


####################################
# OLD FILE STYLE WITHOUT AGE
####################################

if(file.type == "OldWithoutAge"){

stockabundance <- gsub("[[:space:]]", "_", datafile$Stock_Abundance[1])
stockname <- datafile$Stock_Name[1]
stockspecies <- datafile$Stock_Species[1]
forecastingyear <- as.numeric(str_replace_all(datafile$Forecasting_Year[1], "\n",""))

datafile_new <- NA



tmpsub <-  datafile[,c("Run_Year",paste("Average_",stockabundance,sep=""))]
names(tmpsub) <- c("Run_Year","Total")

# merge into data obj
data.obj <- list(data=list(Total=tmpsub) , output.pre = datafile_new,specs = list(stockabundance=stockabundance, 
						stockname=stockname, stockspecies=stockspecies , forecastingyear=forecastingyear))


} # end old file without age



####################################
# OLD FILE STYLE WITH AGE
####################################

if(file.type == "OldWithAge"){

# Note: if any other year.labels are added here, they need to be also included in Module_fitModel.R
# NOTE: alternative labels for age cannot have any numbers other than the age!
if(out.labels == "v1"){ age.prefix <- "age" ; age.sep <- "" ; year.labels <- c("CY","BY") ; age.col.prefix <- "T"}
if(out.labels == "v2"){ age.prefix <- "Age" ; age.sep <- " " ;  year.labels <- c("Run_Year","Brood_Year") ; age.col.prefix <- "Age_" }



# Should these library calls be here, or in the umbrella function?
library("stringr")



# Data file conversion step goes here


# Steps from datalist.XYZ.pre ---------------------------------------------------
# extract specs
stockabundance <- gsub("[[:space:]]", "_", datafile$Stock_Abundance[1])
stockname <- datafile$Stock_Name[1]
stockspecies <- datafile$Stock_Species[1]
forecastingyear <- as.numeric(str_replace_all(datafile$Forecasting_Year[1], "\n",""))
extract_ages <- sort(unique(datafile$Age_Class))
extract_names <- c(year.labels[2],paste(age.col.prefix,extract_ages,sep=""))



tmpsub <- list()
for (i in 1:length(extract_ages)){
    tmpsub[[i]] <- subset(datafile, datafile$Age_Class==extract_ages[i])[,c("Brood_Year",paste0("Average","_",stockabundance))]
	
		
	# rename the new data sets by age
	dimnames(tmpsub[[i]])[[2]] <- c(year.labels[2],paste(age.col.prefix,extract_ages[i], sep=""))
	
}


names(tmpsub) <- paste(age.prefix,extract_ages, sep= age.sep)




# NOTE: tmpsub is already split out by brood year. Old code then merged it using Reduce(), then split it again in a loop
# just skipping all that back and forth now,  just renaming tmpsub components  above and adding run year col below 
# ( but leaving the old bits below for cross-reference with old code)


# extract just the original dataset
datafile_new  <- Reduce(function(...) merge(...,by=year.labels[2], all=T), tmpsub)
names(datafile_new) <- extract_names

datafile_new <- cbind(datafile_new,Total = rowSums(datafile_new))

# adding run year columns
for(age.use in extract_ages){
	idx.use <- match(paste(age.prefix,age.use, sep= age.sep),names(tmpsub))
	tmpsub[[idx.use]] <- cbind(X = tmpsub[[idx.use]][,year.labels[2]] + age.use,tmpsub[[idx.use]])
	names(tmpsub[[idx.use]])[1] <- year.labels[1]
	}


# DO WE NEED TO INCLUDE THE BY < BYmax STEP FROM CODE BELOW?
# -> YES, see https://github.com/avelez-espino/forecastR_phase4/issues/55
# need to do this for each age class

warning("BY < BYMax step not yet implemented")



# --------------------------------------
# Starting obsolete old code
						
# # Steps from datalist.XYZ ---------------------------------------------------

#cols <- colnames(data.obj$output.pre)


#data <- list()
#nms <- NULL

# need to check what this is actually doing
#for (i in 1:(length(cols)-1)) {
		
#         pattern <- paste("c(",cols[1],",",cols[i+1],")",sep="")
#	     data[[i]] <- subset(data.obj$output.pre,select=eval(parse(text=pattern)))
# 		 data[[i]][data[[i]]<0] <- NA
#         age <- as.numeric(str_extract(cols[i+1],"[[:digit:]]+"))
#		 data[[i]][[year.labels[1]]]<- data[[i]][[year.labels[2]]] + age
#         data[[i]] <- data[[i]][,c(3,1,2)]
#         BYmax <- forecastingyear - age
#		 data[[i]] <- subset(data[[i]], data[[i]][,year.labels[2]] <BYmax)
#         nms <- c(nms, paste(age.prefix,age, sep= age.sep))
#    }
#names(data) <- nms

# End of obsolete old code
# ----------------------------------



# merge into data obj
data.obj <- list(data=tmpsub , output.pre = datafile_new,specs = list(stockabundance=stockabundance, 
						stockname=stockname, stockspecies=stockspecies , forecastingyear=forecastingyear))


						
						
						
} # End if old file with age						
						
						
						
						
						
########
return(data.obj)


} # end function prepData