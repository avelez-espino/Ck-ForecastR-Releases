source(Review Code - ARIMA_functions.r)

######################################################################################################
# ARIMA Time Series - Prediction Results
# Date Stamp: June 25, 2014
######################################################################################################

## Predictive Analytics: Microsoft Excel
## By Conrad Carlberg
## Page 259

ARIMA$datafile <- datafile_original

ARIMA$stockabundance <- ARIMA$datafile$Stock_Abundance[1]
ARIMA$stockabundance <- gsub("[[:space:]]", "_", ARIMA$stockabundance)

ARIMA$stockname <- ARIMA$datafile$Stock_Name[1]
ARIMA$stockspecies <- ARIMA$datafile$Stock_Species[1]
ARIMA$forecastingyear <- ARIMA$datafile$Forecasting_Year[1]


usePackage("stringr")
ARIMA$forecastingyear <- str_replace_all(ARIMA$forecastingyear, "\n","")
ARIMA$forecastingyear <- as.numeric(ARIMA$forecastingyear)


ARIMA$datafilesub <- ARIMA$datafile

#######################################################################################################

ARIMA$extract_ages <- sort(unique(ARIMA$datafilesub$Age_Class))
ARIMA$extract_names <- paste("T",ARIMA$extract_ages,sep="")
ARIMA$extract_names <- c("BY",ARIMA$extract_names)


ARIMA$tmpsub <- list()
for (i in 1:length(ARIMA$extract_ages)){
    ARIMA$tmpsub[[i]] <- subset(ARIMA$datafilesub, Age_Class==ARIMA$extract_ages[i])[,c("Brood_Year",paste0("Average","_",ARIMA$stockabundance))]
}


ARIMA$list.of.data.frames <- ARIMA$tmpsub
ARIMA$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), ARIMA$list.of.data.frames)

ARIMA$datafile_new <- ARIMA$merged.data.frame
names(ARIMA$datafile_new) <- ARIMA$extract_names

## datafile <<- datafile_new
ARIMA$datafile <- ARIMA$datafile_new


#-----  add calendar year to age extracted from name of
#-----  response variable for sibling regression


ARIMA$datalist <- ARIMA$datalist.arima(ARIMA$datafile, ARIMA$forecastingyear)  # CY refers to the T variable with highest age


#--------- prepare data table for reporting --------------------------------------------------

ARIMA$datafile.report <-  ARIMA$datafile

ARIMA$datafile.report[ARIMA$datafile.report <0] <- "NA"


#--------- plot data to be used for time series arima modeling ---------------------------


# https://rstudio-pubs-static.s3.amazonaws.com/126854_e21376aaeb324fbc802efc98ad17201c.html

#--------- plot data to be used for arima forecasting (uses ggplot) ---------------------------

ARIMA$plot.data.arima(ARIMA$datalist)



#---------  fit time series ARIMA model -----------------------------------------

if (is.null(ARIMA$boxcoxtransform)) {ARIMA$boxcoxtransform <- boxcoxtransform}

ARIMA$arima.model.fits  <- ARIMA$arima.model(ARIMA$datalist, ARIMA$boxcoxtransform)

ARIMA$fits <- ARIMA$arima.model.fits

#---------  Plot fitted time series ARIMA model --------------------------------
# Plot fit time series ARIMA model
#-------------------------------------------------------------------------------

## fits <- arima.model.fits
## plot.fitted.arima(fits)

ARIMA$plot.fitted.arima(ARIMA$arima.model.fits, ARIMA$boxcoxtransform)

#-------------------------------------------------------------------------------
# Report ARIMA Model Results for A Specific Age Class
#-------------------------------------------------------------------------------

## j <- 1
## arima.model.results(fits,j=1)


#-------------------------------------------------------------------------------
# Model Diagnostics for a Specific Arima Model
#-------------------------------------------------------------------------------

## diagnostics.arima.model.fit(fits,i)

ARIMA$diagnostics.arima.model.fit(ARIMA$fits, ARIMA$boxcoxtransform, i=1)



#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$fits, ARIMA$boxcoxtransform)


ARIMA$results.point.forecast.arima <- NULL
for (j in 1:length(ARIMA$arima.model.fits)){

       ARIMA$tmp_list <- ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$arima.model.fits, ARIMA$boxcoxtransform)[[j]]

       # list2 <- unlist(list1)

       # point.pred.asslr <- rbind(point.pred.asslr, list2)

       ARIMA$tmp_df <- do.call(cbind.data.frame, ARIMA$tmp_list)

       ARIMA$results.point.forecast.arima <- rbind(ARIMA$results.point.forecast.arima, ARIMA$tmp_df)

}

ARIMA$results.point.forecast.arima$Model <- as.character(ARIMA$results.point.forecast.arima$Model)

## results.point.forecast.arima

## str(results.point.forecast.arima)




#--------- retrospective evaluation for each individual age ----------------------------------


ARIMA$results.individual.ages.retro.predictive.performance.arima  <-
     ARIMA$individual.ages.retro.predictive.performance.arima(ARIMA$datalist, boxcoxtransform=ARIMA$boxcoxtransform, index=ARIMA$index.year)

ARIMA$individual.ages.retro.plot(ARIMA$individual.ages.retro.plot.info, ARIMA$stockabundance, j=1)

### report retrospective performance measures for individual ages in a nicer format

ARIMA$MIA <- ARIMA$measures.individual.ages.retro.arima(results = ARIMA$results.individual.ages.retro.predictive.performance.arima)

## MIA

##
## Total Age
##

#--------- retrospective evaluation for the total age ----------------------------------------

ARIMA$results.total.age.retro.predictive.performance.arima <-
      ARIMA$total.age.retro.predictive.performance.arima(ARIMA$datalist, ARIMA$boxcoxtransform, ARIMA$index.year)

## results.total.age.retro.predictive.performance.arima

## names(results.total.age.retro.predictive.performance.arima)

### report retrospective performance measures for total age in a nicer format


ARIMA$total.age.retro.plot(ARIMA$total.age.retro.plot.info, ARIMA$stockabundance)

ARIMA$MTA <- ARIMA$measures.total.age.retro.arima(ARIMA$results.total.age.retro.predictive.performance.arima)

## M <- merge(MIA, MTA, by = intersect(names(MIA), names(MTA)), sort=FALSE)

ARIMA$M <- merge(ARIMA$MIA, ARIMA$MTA, by = c("Measure"), sort=FALSE)

ARIMA$M <- subset(ARIMA$M, select=-Model.y)

## M

names(ARIMA$M)[names(ARIMA$M)=="Model.x"] <- "Model"

## M

ARIMA$M.arima <- ARIMA$M


### report actual, forecasted and error values for total age in a nicer format

ARIMA$results.afe.total.age.retro.arima <-
 ARIMA$afe.total.age.retro.arima(ARIMA$results.total.age.retro.predictive.performance.arima)

## results.afe.total.age.retro.arima


## usePackage("scales")
## cbind(results.afe.total.age.retro.arima[,1],
##      comma(round(results.afe.total.age.retro.arima[,"Actual"])),
##      comma(round(results.afe.total.age.retro.arima[,"Forecast"])),
##      comma(round(results.afe.total.age.retro.arima[,"Error"]))
## )

###########################################################################################
#
# Modified version of forecast.Arima
#
###########################################################################################



#---- meboot2 function for bootstrapping positive time series ----------------------------------------

## meboot2 bootstrap for a specific age

# forecast.arima.modified.meboot

## fit <- arima.model.fits[[1]]
## debug <- forecast.arima.modified.stlboot(fit, boxcoxtransform, level=80, npaths=B)

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

## fit <- arima.model.fits[[1]]
## debug <- forecast.arima.modified.stlboot(fit,  boxcoxtransform, level=80, npaths=B)


#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

ARIMA$fits <- ARIMA$arima.model.fits
ARIMA$pred.int.individual.ages.arima <- ARIMA$prediction.intervals.individual.ages.arima(ARIMA$fits, ARIMA$boxcoxtransform, ARIMA$bootmethod, level=80, npaths=ARIMA$B)

ARIMA$pred.int.individual.ages.arima

#----------------------------------------------------------------------------

ARIMA$PI.ctr <- NULL
ARIMA$PI.lwr <- NULL
ARIMA$PI.upr <- NULL
## PI.med <- NULL
ARIMA$PI.sim <- NULL
ARIMA$nms <- NULL

for (k in 1:length(ARIMA$pred.int.individual.ages.arima)){

     ARIMA$PI.ctr <- c(ARIMA$PI.ctr,
                 ARIMA$pred.int.individual.ages.arima[[k]]$PI.ctr)

     ARIMA$PI.lwr <- c(ARIMA$PI.lwr,
                 ARIMA$pred.int.individual.ages.arima[[k]]$PI.lwr)

     ARIMA$PI.upr <- c(ARIMA$PI.upr,
                 ARIMA$pred.int.individual.ages.arima[[k]]$PI.upr)

     ## PI.med <- c(PI.med,
     ##            pred.int.individual.ages.arima[[k]]$PI.median)

     ARIMA$PI.sim <- cbind(ARIMA$PI.sim, ARIMA$pred.int.individual.ages.arima[[k]]$sim)

     ARIMA$nms <- c(ARIMA$nms, ARIMA$pred.int.individual.ages.arima[[k]]$age)

}

colnames(ARIMA$PI.sim) <- ARIMA$nms


ARIMA$PI.lwr[ARIMA$PI.lwr < 0] <- 0
ARIMA$PI.upr[ARIMA$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

ARIMA$PI.ctr <- round(ARIMA$PI.ctr)
ARIMA$PI.lwr <- round(ARIMA$PI.lwr)
ARIMA$PI.upr <- round(ARIMA$PI.upr)



## PI.med <- round(PI.med)

ARIMA$PI.individual.ages.arima <- data.frame(PI.ctr=ARIMA$PI.ctr, ## PI.med=PI.med,
                                       PI.lwr=ARIMA$PI.lwr, PI.upr=ARIMA$PI.upr)

ARIMA$PI.individual.ages.arima.no.comma <- data.frame(PI.ctr=ARIMA$PI.ctr, ## PI.med=PI.med,
                                                PI.lwr=ARIMA$PI.lwr, PI.upr=ARIMA$PI.upr)


## PI.individual.ages.arima

usePackage("scales")

ARIMA$PI.individual.ages.arima <- comma(ARIMA$PI.individual.ages.arima)

## PI.individual.ages.arima

ARIMA$PI.individual.ages.arima.sim <- ARIMA$PI.sim

##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - individual ages
#
##########################################################################################

ARIMA$plot.distribution.bootstrapped.point.forecasts.individual.ages.arima(ARIMA$PI.individual.ages.arima.sim,
                                                                       ARIMA$PI.individual.ages.arima.no.comma,
                                                                       ARIMA$arima.model.fits,
                                                                       ARIMA$boxcoxtransform,
                                                                       ARIMA$extract_ages,
                                                                       ARIMA$stockabundance)



############################################################################################
#*******************************************************************************************
#
#------------ compute prediction interval for point forecast of total age       -----------
#
#*******************************************************************************************

ARIMA$arima.sim.total.age <- NULL
ARIMA$nms <- NULL
ARIMA$arima.PI.ctr.total.age <- 0
for (k in 1:length(ARIMA$pred.int.individual.ages.arima)){
     ARIMA$arima.sim.total.age <- cbind(ARIMA$arima.sim.total.age, ARIMA$pred.int.individual.ages.arima[[k]]$sim)
     ARIMA$nms <- c(ARIMA$nms, ARIMA$pred.int.individual.ages.arima[[k]]$age)
     ARIMA$arima.PI.ctr.total.age <- ARIMA$arima.PI.ctr.total.age + ARIMA$pred.int.individual.ages.arima[[k]]$PI.ctr
}

colnames(ARIMA$arima.sim.total.age) <- ARIMA$nms



ARIMA$PI.total.age.arima <- NULL

ARIMA$sim <- apply(ARIMA$arima.sim.total.age, 1, sum)

ARIMA$PI.total.age.arima$PI.ctr <- ARIMA$arima.PI.ctr.total.age
## PI.total.age.arima$PI.med <- quantile(sim, 0.500)
ARIMA$PI.total.age.arima$PI.lwr <- quantile(ARIMA$sim, 0.10)  # need to automate this!
ARIMA$PI.total.age.arima$PI.upr <- quantile(ARIMA$sim, 0.90)  # need to automate this!

# PI.total.age.arima <- unlist(PI.total.age.arima)

ARIMA$PI.total.age.arima <- data.frame(ARIMA$PI.total.age.arima)

names(ARIMA$PI.total.age.arima) <- c("PI.ctr", ## "PI.med",
                               "PI.lwr","PI.upr")

## PI.total.age.arima

rownames(ARIMA$PI.total.age.arima) <- NULL

## PI.total.age.arima

ARIMA$PI.total.age.arima.no.comma <- ARIMA$PI.total.age.arima

# hist(sim)

#-----------------------------------------------------------------------------------------------


ARIMA$PI.total.age.arima$PI.lwr[ARIMA$PI.total.age.arima$PI.lwr < 0] <- 0
ARIMA$PI.total.age.arima$PI.upr[ARIMA$PI.total.age.arima$PI.upr < 0] <- 0
## PI.total.age.arima$PI.med[PI.total.age.arima$PI.med < 0] <- 0

ARIMA$PI.total.age.arima$PI.ctr <- round(ARIMA$PI.total.age.arima$PI.ctr)
ARIMA$PI.total.age.arima$PI.lwr <- round(ARIMA$PI.total.age.arima$PI.lwr)
ARIMA$PI.total.age.arima$PI.upr <- round(ARIMA$PI.total.age.arima$PI.upr)
## PI.total.age.arima$PI.med <- round(PI.total.age.arima$PI.med)

usePackage("scales")


ARIMA$PI.total.age.arima$PI.ctr <- comma(ARIMA$PI.total.age.arima$PI.ctr)

ARIMA$PI.total.age.arima$PI.lwr <- comma(ARIMA$PI.total.age.arima$PI.lwr)

ARIMA$PI.total.age.arima$PI.upr <- comma(ARIMA$PI.total.age.arima$PI.upr)

## PI.total.age.arima$PI.med <- comma(PI.total.age.arima$PI.med)

## PI.total.age.arima

ARIMA$PI.total.age.arima.sim <- ARIMA$sim


##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - total age
#
##########################################################################################

ARIMA$plot.distribution.bootstrapped.point.forecasts.total.age.arima(ARIMA$PI.total.age.arima.sim,
                                                               ARIMA$PI.total.age.arima.no.comma,
                                                               ARIMA$stockabundance)


#-----------------------------------------------------------------------------------------
# plot forecast vs. actual (individual ages, arima)
#-----------------------------------------------------------------------------------------

ARIMA$results <- ARIMA$results.individual.ages.retro.predictive.performance.arima
ARIMA$scatter.plot.results.afe.individual.ages.retro.arima(ARIMA$results, ARIMA$stockname, ARIMA$stockabundance)


#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values (individual ages, arima)
#-----------------------------------------------------------------------------------------

ARIMA$results <- ARIMA$results.individual.ages.retro.predictive.performance.arima
ARIMA$timeseries.plot.results.afe.individual.ages.retro.arima(ARIMA$results, ARIMA$stockabundance)



#*******************************************************************************
# scatter plot of retrospectively forecasted vs. actual abundance (total age, arima)
#
#*******************************************************************************

ARIMA$results <- ARIMA$results.total.age.retro.predictive.performance.arima

ARIMA$scatter.plot.results.afe.total.age.retro.arima(ARIMA$results, ARIMA$stockabundance)


#*******************************************************************************
# Time series plot of retrospectively forecasted vs. actual abundance (total age, arima)
#
#*******************************************************************************
ARIMA$results <- ARIMA$results.total.age.retro.predictive.performance.arima

ARIMA$timeseries.plot.results.afe.total.age.retro.arima(ARIMA$results, ARIMA$stockabundance)


#*******************************************************************************
# Density of Retrospective Forecast Errors - Individual Ages
#*******************************************************************************

# fits <- arima.model.fits
# results <- results.individual.ages.retro.predictive.performance.arima

# hist.results.afe.individual.ages.retro.arima(arima.model.fits,
#                                              results.individual.ages.retro.predictive.performance.arima)

ARIMA$dens.results.afe.individual.ages.retro.arima(ARIMA$arima.model.fits,
                                                   ARIMA$boxcoxtransform,
                                                   ARIMA$results.individual.ages.retro.predictive.performance.arima)



## results <- results.individual.ages.retro.predictive.performance.arima


## par(mfrow=c(4,1), mar=c(4,4,3,2))
## hist.results.afe.individual.ages.retro.arima(
##    arima.model.fits,
##    results.individual.ages.retro.predictive.performance.arima
## )


#*******************************************************************************
#
# Density of retrospective forecast errors (total age, arima)
#
#*******************************************************************************

## results <- results.afe.total.age.retro.arima

## hist.results.afe.total.age.retro.arima(results)

## dens.results.afe.total.age.retro.arima(results.afe.total.age.retro.arima)

#*******************************************************************************
#  barplot forecasted values (specific ages)
#
#*******************************************************************************

ARIMA$fits <- ARIMA$arima.model.fits

ARIMA$pointforecasts <- ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$arima.model.fits, ARIMA$boxcoxtransform)

ARIMA$barplot.forecasted.values.individual.ages.arima(ARIMA$fits, ARIMA$boxcoxtransform, ARIMA$pointforecasts,i=1)


#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************
ARIMA$results <- ARIMA$results.total.age.retro.predictive.performance.arima

ARIMA$pointforecasts <- ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$arima.model.fits, ARIMA$boxcoxtransform)

ARIMA$barplot.forecasted.values.total.age.arima(ARIMA$results, ARIMA$pointforecasts)


#*******************************************************************************
#
# plot forecasted values:  scatterplot (individual ages)
#
#*******************************************************************************

ARIMA$fits <- ARIMA$arima.model.fits
ARIMA$pointforecasts <- ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$arima.model.fits, ARIMA$boxcoxtransform)
ARIMA$intervalforecasts <-   ARIMA$PI.individual.ages.arima.no.comma

## i <- 1
ARIMA$scatterplot.forecasted.values.and.forecast.intervals.individual.ages.arima(ARIMA$fits, ARIMA$boxcoxtransform, ARIMA$pointforecasts, ARIMA$intervalforecasts,i=1)

#---- plot forecasted values:  scatterplot (total age) ------------------------------------------------------
ARIMA$results <- ARIMA$results.total.age.retro.predictive.performance.arima

ARIMA$pointforecasts <- ARIMA$point.forecast.arima(ARIMA$datalist, ARIMA$arima.model.fits, ARIMA$boxcoxtransform)

ARIMA$intervalforecasts <-  ARIMA$PI.total.age.arima.no.comma


ARIMA$scatterplot.forecasted.values.and.forecast.intervals.total.age.arima(ARIMA$results, ARIMA$pointforecasts, ARIMA$intervalforecasts)


#*******************************************************************************
#
# Gary's Plot for Individual Ages
#
#*******************************************************************************

ARIMA$results.retro <- ARIMA$results.individual.ages.retro.predictive.performance.arima
names(ARIMA$results.retro)

ARIMA$results.pred <- ARIMA$pred.int.individual.ages.arima

## par(mfrow=c(1,1))
## j <- 1
ARIMA$gary.plot.individual.ages(ARIMA$results.retro, ARIMA$results.pred, j=1)


#*******************************************************************************
#
# Gary's Plot for "Total Age"
#
#*******************************************************************************

ARIMA$results.retro <- ARIMA$results.total.age.retro.predictive.performance.arima
names(ARIMA$results.retro)
ARIMA$results.pred <- ARIMA$PI.total.age.arima.no.comma

## str(results.retro)
## str(results.pred)

ARIMA$gary.plot.total.age(ARIMA$results.retro, ARIMA$results.pred)


#=============================================================================================

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - individual ages
#
##########################################################################################

## fits <- arima.model.fits
ARIMA$fits <- ARIMA$arima.model.fits
ARIMA$results <- ARIMA$results.individual.ages.retro.predictive.performance.arima

windows()
ARIMA$bias.coefficients.afe.individual.ages.retro.arima(ARIMA$arima.model.fits,
                                                       ARIMA$results.individual.ages.retro.predictive.performance.arima,
                                                        ARIMA$boxcoxtransform,
                                                        ARIMA$stockabundance)

ARIMA$bias.coeff.afe.individual.ages.retro.arima

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################
windows()

ARIMA$results <- ARIMA$results.total.age.retro.predictive.performance.arima

ARIMA$bias.coefficient.afe.total.age.retro.arima(ARIMA$results,ARIMA$stockabundance)

ARIMA$bias.coeff.afe.total.age.retro.arima

cat("========================================================","\n\n")
cat("ARIMA$bias.coeff.afe.total.age.retro.arima = ", ARIMA$bias.coeff.afe.total.age.retro.arima, "\n\n")
cat("========================================================","\n\n")
