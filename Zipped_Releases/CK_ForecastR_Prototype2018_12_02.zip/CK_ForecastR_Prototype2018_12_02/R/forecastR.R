openforecastR = function(){
  runApp(system.file('forecastR', package='forecastR'))
}
