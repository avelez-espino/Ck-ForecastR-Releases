# Naive Time Series Forecasting (Average of Past 5 Years) - Forecasting Results for Youngest Age

source("R/simplesibreg/Youngest Age - Simple Sibling Regression_functions.R")

cat("Youngest Age - Sibling Regression.R", "\n\n")

## datafile <- read.csv("SPR_thousands.csv", as.is=TRUE)

SIMPLESIBREG$datafile <- datafile_original
SIMPLESIBREG$datafilesub <- SIMPLESIBREG$datafile
SIMPLESIBREG$extract_ages <- sort(unique(SIMPLESIBREG$datafilesub$Age_Class))
SIMPLESIBREG$extract_names <- paste("T",SIMPLESIBREG$extract_ages,sep="")
SIMPLESIBREG$extract_names <- c("BY",SIMPLESIBREG$extract_names)
SIMPLESIBREG$tmpsub <- list()

for (i in 1:length(SIMPLESIBREG$extract_ages)){
     if (SIMPLESIBREG$stockabundance=="Terminal Run"){
     SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Terminal_Run")]
     } else if (SIMPLESIBREG$stockabundance=="Escapement") {
      SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Escapement")]
     } else if (SIMPLESIBREG$stockabundance=="Production") {
      SIMPLESIBREG$tmpsub[[i]] <- subset(SIMPLESIBREG$datafilesub, Age_Class==SIMPLESIBREG$extract_ages[i])[,c("Brood_Year","Average_Production")]
     }
}

SIMPLESIBREG$list.of.data.frames <- SIMPLESIBREG$tmpsub
SIMPLESIBREG$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), SIMPLESIBREG$list.of.data.frames)

SIMPLESIBREG$datafile_new <- SIMPLESIBREG$merged.data.frame
names(SIMPLESIBREG$datafile_new) <- SIMPLESIBREG$extract_names

## SIMPLESIBREG$datafile <<- SIMPLESIBREG$datafile_new
SIMPLESIBREG$datafile <- SIMPLESIBREG$datafile_new

cat("Working data file is: ","\n")
print(SIMPLESIBREG$datafile)
cat("\n")


#### add calendar year to age extracted from name of ####
#### response variable for naive forecasting (average of past 5 years) ####

# CY refers to the T variable with highest age
SIMPLESIBREG$datalist <- datalist.avgfive(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)

# retain only the data for the youngest ages:
SIMPLESIBREG$datalist <- SIMPLESIBREG$datalist[[1]]


#### plot data to be used for naive forecasting (average of past 5 years) (uses ggplot) ####

plot.data.avgfive.youngest(SIMPLESIBREG$datalist)
#### helper function for computing the average of the past 5 years of a time series ####
#### fit naive model (average of past 5 years) ####

SIMPLESIBREG$avgfive.model.fit.youngest  <- avgfive.model.youngest(SIMPLESIBREG$datalist)
SIMPLESIBREG$fit <- SIMPLESIBREG$avgfive.model.fit.youngest

#### Plot naive model (average of past 5 years) ####
#### Plot fitted naive model (ggplot) ####

SIMPLESIBREG$fit <- SIMPLESIBREG$avgfive.model.fit.youngest
plot.fitted.avgfive.youngest(SIMPLESIBREG$fit)

#### point forecast for each individual age and for the total age ####
# http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

point.forecast.avgfive.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$fit)
SIMPLESIBREG$tmp_list <- point.forecast.avgfive.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$avgfive.model.fit.youngest)

SIMPLESIBREG$tmp_df <- do.call(cbind.data.frame, SIMPLESIBREG$tmp_list)

SIMPLESIBREG$results.point.forecast.avgfive.youngest <- SIMPLESIBREG$tmp_df

SIMPLESIBREG$results.point.forecast.avgfive.youngest$Model <- as.character(SIMPLESIBREG$results.point.forecast.avgfive.youngest$Model)

## results.point.forecast.avgfive.youngest
## str(results.point.forecast.avgfive.youngest)

#### compute prediction intervals for point forecasts of individual ages ####
# meboot2 bootstrap for a specific age
SIMPLESIBREG$fit <- SIMPLESIBREG$avgfive.model.fit.youngest
# forecast.avgfive.modified.youngest(fit, level=80, npaths=B)

SIMPLESIBREG$fit <- SIMPLESIBREG$avgfive.model.fit.youngest
SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest <- prediction.intervals.individual.ages.avgfive.youngest(SIMPLESIBREG$fit, level=80, npaths=SIMPLESIBREG$B)

SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest

SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.ctr
SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.lwr
SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.upr
SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$sim

#### ARIMA Forecasting  - Forecasting Results for Youngest Age ####
#### add calendar year to age extracted from name of ####
#### response variable for sibling regression ####

SIMPLESIBREG$datalist <- datalist.arima(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)  # CY refers to the T variable with highest age

SIMPLESIBREG$datalist <- SIMPLESIBREG$datalist[[1]]   # retain only the data for the youngest age

#### fit time series ARIMA model ####
## SIMPLESIBREG$boxcoxtransform <- SIMPLESIBREG$boxcoxtransform

if(is.null(SIMPLESIBREG$boxcoxtransform)) {SIMPLESIBREG$boxcoxtransform <- boxcoxtransform}

SIMPLESIBREG$arima.model.fit.youngest  <- arima.model.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$boxcoxtransform)

SIMPLESIBREG$fit <- SIMPLESIBREG$arima.model.fit.youngest

#### Plot fitted time series ARIMA model ####
# Plot fit time series ARIMA model

SIMPLESIBREG$fit <- SIMPLESIBREG$arima.model.fit.youngest
plot.fitted.arima.youngest(SIMPLESIBREG$fit, SIMPLESIBREG$boxcoxtransform)

#### Report ARIMA Model Results for Youngest Age Class ####
arima.model.results.youngest(SIMPLESIBREG$fit)

#### point forecast for the youngest age ####
# http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

point.forecast.arima.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$fit)

SIMPLESIBREG$tmp_list <- point.forecast.arima.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$arima.model.fit.youngest)

SIMPLESIBREG$tmp_df <- do.call(cbind.data.frame, SIMPLESIBREG$tmp_list)

SIMPLESIBREG$results.point.forecast.arima.youngest <- SIMPLESIBREG$tmp_df

SIMPLESIBREG$results.point.forecast.arima.youngest$Model <- as.character(SIMPLESIBREG$results.point.forecast.arima.youngest$Model)

SIMPLESIBREG$results.point.forecast.arima.youngest

str(SIMPLESIBREG$results.point.forecast.arima.youngest)

## SIMPLESIBREG$fit <- SIMPLESIBREG$arima.model.fits[[1]]
## debug <- SIMPLESIBREG$forecast.arima.modified.stlboot(SIMPLESIBREG$fit, SIMPLESIBREG$boxcoxtransform, level=80, npaths=SIMPLESIBREG$B)

## fit <- arima.model.fits[[1]]
## debug <- forecast.arima.modified.stlboot(fit,  boxcoxtransform, level=80, npaths=B)


## ISSUES WITH lower and upper values being too close to each other!

SIMPLESIBREG$fit <- SIMPLESIBREG$arima.model.fit.youngest

## Hard-code prediction interval for youngest age (ARIMA) to use "stlboot", since stlboot had better performance than meboot for our test data sets
SIMPLESIBREG$pred.int.individual.ages.arima.youngest <- prediction.interval.youngest.age.arima(SIMPLESIBREG$fit, SIMPLESIBREG$boxcoxtransform, bootmethod="stlboot", level=80, npaths=SIMPLESIBREG$B)

#### Exponential Smoothing - Forecasting Results for Youngest Age ####
#### add calendar year to age extracted from name of ####
#### response variable for sibling regression ####

SIMPLESIBREG$datalist <-  datalist.expsmooth(SIMPLESIBREG$datafile, SIMPLESIBREG$forecastingyear)  # CY refers to the T variable with highest age

SIMPLESIBREG$datalist <- SIMPLESIBREG$datalist[[1]]

#### fit exponential smoothing model ####
SIMPLESIBREG$expsmooth.model.fit.youngest  <- expsmooth.model(SIMPLESIBREG$datalist, SIMPLESIBREG$boxcoxtransform)

SIMPLESIBREG$fit <- SIMPLESIBREG$expsmooth.model.fit.youngest

#### Plot fitted exponential smoothing model ####
####Plot fitted exponential smoothing model (ggplot) ####
#SIMPLESIBREG$fit <- expsmooth.model.fit.youngest

# plot.fitted.expsmooth.youngest(fit, boxcoxtransform)

####Report Exponential Smoothing Model Results for A Specific Age Class ####
# SIMPLESIBREG$expsmooth.model.results.youngest(SIMPLESIBREG$fit)

#### point forecast for the youngest age ####
# http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm
# point.forecast.expsmooth.youngest(datalist, fit)

SIMPLESIBREG$tmp_list <- point.forecast.expsmooth.youngest(SIMPLESIBREG$datalist, SIMPLESIBREG$expsmooth.model.fit.youngest)

SIMPLESIBREG$tmp_df <- do.call(cbind.data.frame, SIMPLESIBREG$tmp_list)

SIMPLESIBREG$results.point.forecast.expsmooth.youngest <- SIMPLESIBREG$tmp_df

SIMPLESIBREG$results.point.forecast.expsmooth.youngest$Model <- as.character(SIMPLESIBREG$results.point.forecast.expsmooth.youngest$Model)

# results.point.forecast.expsmooth.youngest
# str(results.point.forecast.expsmooth.youngest)

#### meboot bootstrapping for EXPSMOOTH ####
# fit <- expsmooth.model.fit.youngest
# SIMPLESIBREG$forecast.expsmooth.modified.meboot(SIMPLESIBREG$fit, SIMPLESIBREG$boxcoxtransform, level=0.8, SIMPLESIBREG$npaths=B)

#### stlboot bootstrapping for EXPSMOOTH ####
# fit <- expsmooth.model.fit.youngest

#### compute prediction intervals for point forecasts of individual ages ####
# fit <- expsmooth.model.fit.youngest
# Hard code "stlboot" as the bootstrap method of choice for EXPSMOOTH, since it worked better than meboot on the test data sets with considered for stocks with age

SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest <- prediction.interval.youngest.age.expsmooth(fit = SIMPLESIBREG$expsmooth.model.fit.youngest, boxcoxtransform = SIMPLESIBREG$boxcoxtransform, bootmethod = "stlboot", level = 80, npaths = SIMPLESIBREG$B)

# SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest
# str(SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest)

#### Putting it all together to compute the Total Abundance ####
# SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest
# SIMPLESIBREG$pred.int.individual.ages.arima.youngest
# SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest
# SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression

# SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models

SIMPLESIBREG$pred.total.age.avgfive.youngest <- list()
SIMPLESIBREG$pred.total.age.avgfive.youngest[[1]] <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$age
SIMPLESIBREG$pred.total.age.avgfive.youngest[[2]] <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.ctr
SIMPLESIBREG$pred.total.age.avgfive.youngest[[3]] <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.lwr
SIMPLESIBREG$pred.total.age.avgfive.youngest[[4]] <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.upr
SIMPLESIBREG$pred.total.age.avgfive.youngest[[5]] <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$sim
names(SIMPLESIBREG$pred.total.age.avgfive.youngest) <- c("age","p","pi.lwr","pi.upr","sim")

SIMPLESIBREG$pred.total.age.arima.youngest <- list()
SIMPLESIBREG$pred.total.age.arima.youngest[[1]] <- SIMPLESIBREG$pred.int.individual.ages.arima.youngest$age
SIMPLESIBREG$pred.total.age.arima.youngest[[2]] <- SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.ctr
SIMPLESIBREG$pred.total.age.arima.youngest[[3]] <- SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.lwr
SIMPLESIBREG$pred.total.age.arima.youngest[[4]] <- SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.upr
SIMPLESIBREG$pred.total.age.arima.youngest[[5]] <- SIMPLESIBREG$pred.int.individual.ages.arima.youngest$sim
names(SIMPLESIBREG$pred.total.age.arima.youngest) <- c("age","p","pi.lwr","pi.upr","sim")

SIMPLESIBREG$pred.total.age.expsmooth.youngest <- list()
SIMPLESIBREG$pred.total.age.expsmooth.youngest[[1]] <- SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$age
SIMPLESIBREG$pred.total.age.expsmooth.youngest[[2]] <- SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.ctr
SIMPLESIBREG$pred.total.age.expsmooth.youngest[[3]] <- SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.lwr
SIMPLESIBREG$pred.total.age.expsmooth.youngest[[4]] <- SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.upr
SIMPLESIBREG$pred.total.age.expsmooth.youngest[[5]] <- SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$sim
names(SIMPLESIBREG$pred.total.age.expsmooth.youngest) <- c("age","p","pi.lwr","pi.upr","sim")


## str(pred.int.individual.ages.simple.sibling.regression[[1]])

SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models <- list()

## youngest age

SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models$age <- SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$age

## point forecasts for total abundance

SIMPLESIBREG$p.total.age.avgfive.youngest.plus.oldest <-  round(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$PI.ctr) +
                                 sum(unlist(lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,
                                     function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                  # as produced by simple sibling regression,
                                                                  # and sum them up

SIMPLESIBREG$p.total.age.arima.youngest.plus.oldest  <-  round(SIMPLESIBREG$pred.int.individual.ages.arima.youngest$PI.ctr) +
                                 sum(unlist(lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,
                                     function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                  # as produced by simple sibling regression,
                                                                  # and sum them up

SIMPLESIBREG$p.total.age.expsmooth.youngest.plus.oldest  <-  round(SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$PI.ctr) +
                                     sum(unlist(lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,
                                         function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                      # as produced by simple sibling regression,
                                                                      # and sum them up


SIMPLESIBREG$p.list <- list(avgfive = SIMPLESIBREG$p.total.age.avgfive.youngest.plus.oldest ,
               arima = SIMPLESIBREG$p.total.age.arima.youngest.plus.oldest ,
               expsmooth = SIMPLESIBREG$p.total.age.expsmooth.youngest.plus.oldest)


SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models$p <- SIMPLESIBREG$p.list


## simulated values from bootstrap for avgfive

SIMPLESIBREG$sim.total.age.avgfive.oldest <- lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,
                                              function(xl) xl$y.star.boot)
SIMPLESIBREG$sim.total.age.avgfive.oldest <- Reduce("+", SIMPLESIBREG$sim.total.age.avgfive.oldest)

SIMPLESIBREG$sim.total.age.avgfive.youngest.plus.oldest <-  SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest$sim + SIMPLESIBREG$sim.total.age.avgfive.oldest

## simulated values from bootstrap for arima

SIMPLESIBREG$sim.total.age.arima.oldest <- lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression,
                                              function(xl) xl$y.star.boot)
SIMPLESIBREG$sim.total.age.arima.oldest <- Reduce("+", SIMPLESIBREG$sim.total.age.arima.oldest)

SIMPLESIBREG$sim.total.age.arima.youngest.plus.oldest <-  SIMPLESIBREG$pred.int.individual.ages.arima.youngest$sim + SIMPLESIBREG$sim.total.age.arima.oldest

## simulated values from bootstrap for exponential smoothing

SIMPLESIBREG$sim.total.age.expsmooth.oldest <- lapply(SIMPLESIBREG$pred.int.individual.ages.simple.sibling.regression, function(xl) xl$y.star.boot)
SIMPLESIBREG$sim.total.age.expsmooth.oldest <- Reduce("+", SIMPLESIBREG$sim.total.age.expsmooth.oldest)

SIMPLESIBREG$sim.total.age.expsmooth.youngest.plus.oldest <-  SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest$sim + SIMPLESIBREG$sim.total.age.expsmooth.oldest

SIMPLESIBREG$sim.list <- list(avgfive=SIMPLESIBREG$sim.total.age.avgfive.youngest.plus.oldest, arima=SIMPLESIBREG$sim.total.age.arima.youngest.plus.oldest, expsmooth=SIMPLESIBREG$sim.total.age.expsmooth.youngest.plus.oldest)

SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models$sim <- SIMPLESIBREG$sim.list

#======================================================================================================================

## str(SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models)

#=======================================================================================================================
# Retrospective Evaluation of Point Forecasts for Total Age
#=======================================================================================================================

## SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models

## avgfive

level <- 80

## lower.total.age.avgfive <- as.numeric(quantile(sim.total.age.avgfive.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLESIBREG$lower.total.age.avgfive <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.avgfive.youngest.plus.oldest, (1-level/100)/2, type = 8))

SIMPLESIBREG$lower.total.age.avgfive <- max(0, round(SIMPLESIBREG$lower.total.age.avgfive))

## upper.total.age.avgfive <- as.numeric(quantile(sim.total.age.avgfive.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLESIBREG$upper.total.age.avgfive <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.avgfive.youngest.plus.oldest, (1-level/100)/2 + level/100, type = 8))
SIMPLESIBREG$upper.total.age.avgfive <- round(SIMPLESIBREG$upper.total.age.avgfive)

## arima

## lower.total.age.arima <- as.numeric(quantile(sim.total.age.arima.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLESIBREG$lower.total.age.arima <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.arima.youngest.plus.oldest, (1-level/100)/2, type = 8))
SIMPLESIBREG$lower.total.age.arima <- max(0, round(SIMPLESIBREG$lower.total.age.arima))

## upper.total.age.arima <- as.numeric(quantile(sim.total.age.arima.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLESIBREG$upper.total.age.arima <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.arima.youngest.plus.oldest, (1 - level/100)/2 + level/100, type = 8))
SIMPLESIBREG$upper.total.age.arima <- round(SIMPLESIBREG$upper.total.age.arima)

# expsmooth

# lower.total.age.expsmooth <- as.numeric(quantile(sim.total.age.expsmooth.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLESIBREG$lower.total.age.expsmooth <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.expsmooth.youngest.plus.oldest, (1 - level/100)/2, type = 8))
SIMPLESIBREG$lower.total.age.expsmooth <- max(0, round(SIMPLESIBREG$lower.total.age.expsmooth))

# upper.total.age.expsmooth <- as.numeric(quantile(sim.total.age.expsmooth.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLESIBREG$upper.total.age.expsmooth <- as.numeric(quantile(SIMPLESIBREG$sim.total.age.expsmooth.youngest.plus.oldest, (1 - level/100)/2 + level/100, type = 8))
SIMPLESIBREG$upper.total.age.expsmooth <- round(SIMPLESIBREG$upper.total.age.expsmooth)

# add prediction intervals to pred.int.total.age.simple.sibling.regression.all.models
SIMPLESIBREG$lower.list <- list(avgfive=SIMPLESIBREG$lower.total.age.avgfive, arima=SIMPLESIBREG$lower.total.age.arima, expsmooth=SIMPLESIBREG$lower.total.age.expsmooth)

SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models$p.lwr <- SIMPLESIBREG$lower.list


SIMPLESIBREG$upper.list <- list(avgfive=SIMPLESIBREG$upper.total.age.avgfive, arima=SIMPLESIBREG$upper.total.age.arima, expsmooth=SIMPLESIBREG$upper.total.age.expsmooth)

SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models$p.upr <- SIMPLESIBREG$upper.list


#### Plot fitted values for the youngest age: avgfive, arima and expsmooth ####
plot.fitted.value.youngest(SIMPLESIBREG$avgfive.model.fit.youngest, SIMPLESIBREG$arima.model.fit.youngest, SIMPLESIBREG$expsmooth.model.fit.youngest)

