source("R/simplesibreg/Misc - Simple Sibling Regression_functions.R")

cat("Misc - Sibling Regression.R", "\n\n")

#*******************************************************************************
#  barplot forecasted values (youngest age)
#
#*******************************************************************************

## total.index

## pred.int.individual.ages.avgfive.youngest
## pred.int.individual.ages.arima.youngest
## pred.int.individual.ages.expsmooth.youngest

SIMPLESIBREG$barplot.forecasted.values.youngest.age.simplesib(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest, SIMPLESIBREG$pred.int.individual.ages.arima.youngest, SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest, SIMPLESIBREG$result.avgfive.youngest, SIMPLESIBREG$result.arima.youngest, SIMPLESIBREG$result.expsmooth.youngest, SIMPLESIBREG$forecastingyear, SIMPLESIBREG$total.index, SIMPLESIBREG$stockabundance)


#*******************************************************************************
#  scatterplot of forecasted value with superimposed forecast interval (youngest age)
#
#*******************************************************************************

SIMPLESIBREG$scatterplot.forecasted.values.and.forecast.intervals.youngest.age.simple.sibling.regression(
                       SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest,
                       SIMPLESIBREG$pred.int.individual.ages.arima.youngest,
                       SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest,
                       SIMPLESIBREG$result.avgfive.youngest,
                       SIMPLESIBREG$result.arima.youngest,
                       SIMPLESIBREG$result.expsmooth.youngest,
                       SIMPLESIBREG$forecastingyear,
                       SIMPLESIBREG$total.index,
                       SIMPLESIBREG$stockabundance)



#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************

SIMPLESIBREG$barplot.forecasted.values.total.age.simplesib(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest, SIMPLESIBREG$pred.int.individual.ages.arima.youngest, SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest, SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models,
                                                           SIMPLESIBREG$best.fits,
                                                           SIMPLESIBREG$result.avgfive.youngest,
                                                           SIMPLESIBREG$result.arima.youngest,
                                                           SIMPLESIBREG$result.expsmooth.youngest,
                                                           SIMPLESIBREG$forecastingyear,
                                                           SIMPLESIBREG$total.index,
                                                           SIMPLESIBREG$stockabundance)

#*******************************************************************************
#  scatterplot of forecasted value with superimposed forecast interval (total age)
#
#*******************************************************************************

SIMPLESIBREG$scatterplot.forecasted.values.and.forecast.intervals.total.age.simple.sibling.regression(
                     SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest,
                     SIMPLESIBREG$pred.int.individual.ages.arima.youngest,
                     SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest,
                     SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models,
                     SIMPLESIBREG$best.fits,
                     SIMPLESIBREG$result.avgfive.youngest,
                     SIMPLESIBREG$result.arima.youngest,
                     SIMPLESIBREG$result.expsmooth.youngest,
                     SIMPLESIBREG$forecastingyear,
                     SIMPLESIBREG$total.index,
                     SIMPLESIBREG$stockabundance)

##
## Retro Measures for Youngest Age and Older Ages
##

## need to use this!
## best.rmse.youngest.age

SIMPLESIBREG$retro.measures.all.ages.simple.sibling(SIMPLESIBREG$best.rmse.youngest.age)


##
## Model Diagnostics for Naive Model (Average of Previous Five Years) for Youngest Age
##

SIMPLESIBREG$diagnostics.avgfive.model.fit.youngest.age(SIMPLESIBREG$avgfive.model.fit.youngest)

##
## Model Diagnostics for ARIMA Model for Youngest Age
##

SIMPLESIBREG$diagnostics.arima.model.fit.youngest.age(SIMPLESIBREG$arima.model.fit.youngest)

##
## Model Diagnostics for Exponential Smoothing Model for Youngest Age
##

SIMPLESIBREG$diagnostics.expsmooth.model.fit.youngest.age(SIMPLESIBREG$expsmooth.model.fit.youngest)

## pred.int.individual.ages.avgfive.youngest
## pred.int.individual.ages.arima.youngest
## pred.int.individual.ages.expsmooth.youngest

###
### Histogram of Bootstrap Predictions: Best Model for Youngest Age
###

SIMPLESIBREG$plot.yboot.simple.sibling.regression.youngest.age(SIMPLESIBREG$pred.int.individual.ages.avgfive.youngest,SIMPLESIBREG$pred.int.individual.ages.arima.youngest, SIMPLESIBREG$pred.int.individual.ages.expsmooth.youngest, SIMPLESIBREG$total.index, SIMPLESIBREG$stockabundance)


###
### Histogram of Bootstrap Predictions: Best Model for Total Age
###

SIMPLESIBREG$plot.yboot.simple.sibling.regression.total.age(
                         SIMPLESIBREG$pred.int.total.age.simple.sibling.regression.all.models,
                         SIMPLESIBREG$total.index,
                         SIMPLESIBREG$stockabundance)


