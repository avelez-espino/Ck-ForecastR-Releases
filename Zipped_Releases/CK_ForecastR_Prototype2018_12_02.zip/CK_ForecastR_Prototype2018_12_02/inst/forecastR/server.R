



function(input, output, session) {

  source("../../R/2_MainFunctionCall.R")
	source("../../R/3a_HelperFunctions_ModelFitting.R")
	source("../../R/3b_HelperFunctions_ReportCreation.R")


# THink it needs these here for the server deployment
	library("ggplot2")
	library("DT")
	library("markdown")
	library("rmarkdown")
	
	library("shiny")
	library("shinydashboard")
	library("shinyjqui")
	library("shinyFiles")
	
	
	
	volumes.use <- getVolumes()
	shinyDirChoose(input,"repdir",roots=getVolumes())
	reports.path.use <- reactive(input$repdir)
	output$reports.path.use <- renderPrint({   parseDirPath(roots=volumes.use, selection =reports.path.use())  })

		

	
	#############################
	# have this in the launchForecastR() function in the original structure
	# but think it needs to be here for the server deployment
	# read in all ".R" files and ".r" files in /R, and all files with "_functions.r" from the subfolders"
# -------------------

fun.path <- "../../R"

for(dir.use in list.dirs(path=fun.path,full.names = TRUE, recursive = TRUE)){
	print("------------------")
	print(dir.use)
	
	if(dir.use == fun.path){pattern.list <- c("*[.]R$","*[.]r$") } 
	if(dir.use != fun.path){pattern.list <- c("_functions.R","_functions.r") } 	

	for(pattern.use in pattern.list){
		fn.file.list <- list.files(path=dir.use,pattern=pattern.use) # get all .R files 
		#print(fn.file.list)
		print("-------")
		for(file.source in fn.file.list){
			print(paste("Sourcing: ",file.source))
			source(paste(dir.use,file.source,sep="/"))
			} # end looping through files
		} # end looping through patterns
	} # end looping through folders
	
	
	
	
		
	



# temporary kludge -> see comments in ui.R
#ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")
ages.menu.list <- c("all","Age 3","Age 4","Age 5","Age 6")

  # Reactive expression to create data frame of all input values ----
  fc.settings <- reactive({

     data.frame(
      Name = c("boots.method",
			   "set.seed",
               "index.year",
			   "B",
               "boxcoxtransform",
			   "Retro-MRE",
			   "Retro-MAE",
			   "Retro-MPE",
			   "Retro-MAPE",
			   "Retro-MASE",
			   "Retro-RMSE"
			   ),
      Value = as.character(c(input$boots.method,
                             input$set.seed,
							 input$index.year ,
                             input$B,
                             input$boxcoxtransform,
							 input$retromeasureMRE ,
							 input$retromeasureMAE,
							 input$retromeasureMPE ,
							 input$retromeasureMAPE ,
							 input$retromeasureMASE,
							 input$retromeasureRMSE
							 )),
      stringsAsFactors = FALSE)

  })



	# Read in user-selected input file
    data.file <- reactive({
		inFile <- input$file.name.2
		if(is.null(inFile)){ data.use <- matrix(NA,ncol=2,nrow=5)}
		if(!is.null(inFile)){ 
				
			data.file.tmp <- read.csv(inFile$datapath, stringsAsFactors=FALSE)  
			
					
			# doing this here for now, but it's a kludge -> see https://github.com/avelez-espino/forecastR_phase4/issues/39			
			settings.cols <- c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")
			settings.tmp <- data.file.tmp[,settings.cols]
			data.use <- data.file.tmp[,!(dimnames(data.file.tmp)[[2]] %in% settings.cols)]
			
			yrs.window <- min(data.use$Run_Year) : max(data.use$Run_Year) # need this for all the other tabs -> just keep all the records
			if(input$MainTab == "precheck"){yrs.window <- input$yr.range.precheck[1]:input$yr.range.precheck[2]}
			if(input$MainTab == "compare"){yrs.window <- input$yr.range.compare[1]:input$yr.range.compare[2]}			
			if(input$MainTab == "report.withage"){yrs.window <- input$yr.range.report.withage[1]:input$yr.range.report.withage[2]}
			if(input$MainTab == "report.withoutage"){yrs.window <- input$yr.range.report.withoutage[1]:input$yr.range.report.withoutage[2]}
		
						
			records.keep <-  data.use$Run_Year %in% yrs.window
			data.use <- data.use[records.keep,]
			data.use <- cbind(settings.tmp[1:dim(data.use)[1],],data.use)
			}
		
	return(data.use)
			
	})


	 settings.basic <- reactive({
			data.file.tmp <- data.file()
	
			settings.list <- list(Stock = data.file.tmp[1,"Stock_Name"],
								Species = data.file.tmp[1,"Stock_Species"],
								Abundance = data.file.tmp[1,"Stock_Abundance"],
								FCYear = data.file.tmp[1,"Forecasting_Year"]
								)
					
			return(settings.list)
	
	
			})
	
	
######################################################################  
# MODEL PRE_CHECK PIECES ("Explore" Tab)	
######################################################################  


	precheck.settings  <- reactive({
	
					# extract settings (should streamline)
				if(input$model.use.precheck  %in% c("TimeSeriesArima","TimeSeriesExpSmooth")){settings.use <- list(BoxCox= input$precheck.boxcox)}
				if(input$model.use.precheck  %in% c("Naive")){settings.use <- list(avg.yrs= input$precheck.avgyrs)}
				if(input$model.use.precheck  %in% c("SibRegKalman")){settings.use <- list(int.avg= input$precheck.intavg)}
				if(input$model.use.precheck  %in% c( "SibRegSimple","SibRegLogPower")){settings.use <- NULL}
				
				return(settings.use)
				
					})
	
	precheck.modelfit  <- reactive({
				data.file.tmp <- data.file()	
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")
				settings.use <- precheck.settings()

				fit.obj <- fitModel(model= input$model.use.precheck, data = sample.dat$data, settings = settings.use ,tracing=FALSE)

				return(fit.obj)
			})
	
	
    precheck.fc <- reactive({
				data.file.tmp <- data.file()	
				settings.basic.use <- settings.basic()
				fit.obj <- precheck.modelfit()
				settings.use <- precheck.settings()
				sample.dat <-  prepData(data.file.tmp,out.labels="v2")	
				fc.obj <- calcFC(fit.obj= fit.obj,data = sample.dat$data, fc.yr= settings.basic.use$FCYear,  do.boot=FALSE, settings = settings.use, tracing=FALSE)
				return(fc.obj)
				
				})

   

	output$precheck.plot.fitandfc <- renderPlot({
				
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "fitted_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   	output$precheck.plot.resid_ts <- renderPlot({
					
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_ts",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   	output$precheck.plot.resid_hist<- renderPlot({
					
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_hist",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
   
   
   	output$precheck.plot.resid_qq <- renderPlot({
				
				fit.in <- precheck.modelfit()
				fc.in <-  precheck.fc()
				age.in <- input$precheck.ageclass
				plotModelFit(fit.in, options= list(plot.which = "resid_qq",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
				})
   
   
     
  output$"downloadPreCheckRep" <- downloadHandler(
    filename = function() {
      paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck,"_",  gsub(" ","",input$precheck.ageclass),"_",  Sys.Date(), ".pdf", sep="")
    },
    content = function(file) {
		
	pdf(file,onefile=TRUE,width=11,height=8.5)  

		fit.in <- precheck.modelfit()
		fc.in <-  precheck.fc()
		age.in <- input$precheck.ageclass
		plotModelFit(fit.in, options= list(plot.which = "precheck.report",age.which=age.in,plot.add=FALSE), fc.add= fc.in ) 
			
		dev.off()
    }
  )
   
   
   
######################################################################  
# MODEL COMPARISON PIECES ("Compare" Tab)	
######################################################################  
   
     
   
	compare.multifit  <- reactive({
				data.file.tmp <- data.file()
      
				settings.use <- list(Naive1 = list(model.type="Naive",settings=list(avg.yrs=1)),
					Naive3 = list(model.type="Naive",settings=list(avg.yrs=3)),
					Naive5 = list(model.type="Naive",settings=list(avg.yrs=5)),
					SibRegSimple = list(model.type="SibRegSimple",settings=NULL),
					SibRegLogPower =  list(model.type="SibRegLogPower",settings=NULL),
					SibRegKalman =  list(model.type="SibRegKalman",settings=NULL),
					TSArimaBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=TRUE)),
					TSArimaNoBC = list(model.type="TimeSeriesArima",settings=list(BoxCox=FALSE)),
					TSExpSmoothBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=TRUE)),
					TSExpSmoothNoBC = list(model.type="TimeSeriesExpSmooth",settings=list(BoxCox=FALSE))
				)
   
				multiresults.retro <- multiFC(data.file=data.file.tmp,settings.list=settings.use,
								do.retro=TRUE,do.boot=FALSE,out.type="short",
								retro.min.yrs=15,tracing=FALSE)
   
				
   
				print(multiresults.retro)
				return(multiresults.retro)
				
				
				})
   
   
   

   
   
  
  
  
  
		compare.ptfc.table <- reactive({
					multifit.out <- compare.multifit() 
					multi.ptfc <- round(multifit.out[["table.ptfc"]])
					model.names <- dimnames(multi.ptfc )[[1]]
					multi.ptfc <- sapply(multi.ptfc , FUN=function(x) prettyNum(x, big.mark=","))
										
					dimnames(multi.ptfc )[[1]] <- model.names
					return(multi.ptfc)
					})
   
#		output$table.multi.ptfc  <- renderTable(
#				compare.ptfc.table(), rownames= TRUE, digits=0 , stripes = TRUE, hover = TRUE
#				)   

# obsolete, because using version with rank added in below   
#     output$table.multi.ptfc <- DT::renderDataTable(
#	 				DT::datatable(compare.ptfc.table(), options = list(paging = FALSE))
#					) 
   
     	output$compare.ptfc <- renderPlot({
				
					multifit.out <- compare.multifit() 
					rank.table <- compare.ranking.table()
					
					if(input$compare.plotsort == "AvgRank") {order.idx  <- order(rank.table[,"average.rank"])}
					if(input$compare.plotsort == "Forecast") {order.idx  <- order(multifit.out[["table.ptfc"]][,input$compare.ageclass])}
					if(input$compare.plotsort == "None") {order.idx  <- 1: dim(multifit.out[["table.ptfc"]])[1] }
					
					
					multi.ptfc <- multifit.out[["table.ptfc"]][order.idx,]
									
					model.names <- paste0(dimnames(multi.ptfc )[[1]]," (",round(rank.table[order.idx,"average.rank"],1),")")
									 
					
					n.models <- length(model.names)
					vec.plot <- multi.ptfc[,input$compare.ageclass]
					
					par(mai=c(1,2.5,1,1))
					plot(vec.plot , n.models:1, axes=FALSE,xlim = c(0,max(vec.plot)), xlab="Forecast",ylab="",
							pch=19,type="p",cex=1.5,col="red",cex.lab=1.4,main=input$compare.ageclass,col.main="darkblue")
					abline(h=1:n.models,col="lightgrey")
					points(vec.plot , n.models:1, pch=19,type="p",cex=1.5,col="red")
					text(vec.plot , (n.models:1)+0.2, labels=prettyNum(round(vec.plot),big.mark=","),cex=1,col="red")
					axis(2,at=n.models:1,labels=model.names,las=2,cex.axis=1.2)
	
			})
   
   
		compare.rankingpm <- reactive({input$compare.pm})
		   
   
		compare.retropm.table <- reactive({
					multifit.out <- compare.multifit() 
					multi.retropm <- multifit.out[["retro.pm"]][[input$retrotype.compare]][,,input$compare.ageclass]
					return(multi.retropm)
					})

		compare.ranking.table <- reactive({
					ranking.pm.use <- compare.rankingpm()
					multi.retropm <- compare.retropm.table()
					ranking.out <- getRanks(as.data.frame(multi.retropm), columnToRank = ranking.pm.use)
					ranking.out <- ranking.out[ , grep("rank",dimnames(ranking.out)[[2]])]   # extract only the rank columns
					
					# can't sort here, b/c will screw up the merge below!!!
					#ranking.out <- ranking.out[order(ranking.out$average.rank),]
					
					return(ranking.out)
					})
					
		compare.ptfc.table.merged <- reactive({		
						
					fc.table <-  compare.ptfc.table()
					rank.table <- compare.ranking.table()
					
					merged.table <- cbind(AvgRank = round(rank.table[,"average.rank"],2),fc.table)
				
					return(merged.table)
					
					})					

					
     output$table.multi.ptfc <- DT::renderDataTable(
	 				DT::datatable(compare.ptfc.table.merged(), options = list(paging = FALSE))
					) 
					
					
     output$table.retropm <- DT::renderDataTable(
	 				DT::datatable(compare.retropm.table(), options = list(paging = FALSE))
					) 

				
	
				
      output$table.ranking <- DT::renderDataTable(
	 				DT::datatable(compare.ranking.table(), options = list(paging = FALSE))
					)   
   
   
	output$downloadComparisonRepWord <- downloadHandler(
	# using template from https://shiny.rstudio.com/articles/generating-reports.html
			filename =   paste0("WordTest",Sys.Date(),".doc"),
			content = function(file) {
	        # Copy the report file to a temporary directory before processing it, in
			# case we don't have write permissions to the current working dir (which
			# can happen when deployed).
        tempReport <- file.path(tempdir(), "ShortCompRep.Rmd")
        file.copy("Markdown/ShortCompRep.Rmd", tempReport, overwrite = TRUE)

		settings.basic.use <- settings.basic()
        params <- c(settings.basic.use,
					list(Table_Multi_Pt_FC = compare.ptfc.table.merged())
					)
		
        # Knit the document, passing in the `params` list, and eval it in a
        # child of the global environment (this isolates the code in the document
        # from the code in this app).
        rmarkdown::render(tempReport, output_file = file,
          params = params,
          envir = new.env(parent = globalenv())
			) # end render()
      } # end content
    ) # end downloadHandler()

 
   
   
   
   
   
   
	# not working for some reason
   	#	compare.fittedpm.table <- reactive({
	#				multifit.out <- compare.multifit() 
	#				multi.fittedpm <- multifit.out[["retro.pm"]][["fitted.pm.last"]][,,input$compare.ageclass]
	#				return(multi.fittedpm)
	#				})
   
	#	output$table.fittedpm <- renderTable(
	#			compare.fittedpm.table(), rownames= TRUE, stripes = TRUE, hover = TRUE
	#			)   
   
   
   
######################################################################  
# OTHER STUFF
######################################################################   
   
	output$inputheader.table <- renderTable({ data.file() })  # masking issue with package DT? shiny::renderTable doesn't fix it



	output$settings.table <- renderTable({   fc.settings() })
	#output$settings.table <- renderText({   fc.settings()})







	# create precheck summary report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected
    # THIS IS OBSOLETE
	# Doing this above with  output$"downloadPreCheckRep" <- downloadHandler(
  	#observeEvent(input$create.precheck.summary.withoutage, {
	#				print("-----------------------")

		# FOR NOW, THIS REPLICATES ALL THE STEPS FROM THE PRE-CHECK PLOTS ABOVE
	#	data.file.tmp <- data.file()	
		
		
	
	#	if(input$model.use.precheck.withage=="n1.model"){
					#pdf("../../OUTPUT/Naive1_WithAge_Precheck.pdf",onefile=TRUE,width=8.5,height=11) # Need to make this dynamic to include file name 
					
					#data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
					#data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
					#n1.fit.tmp <- naiveone.model(data.input.tmp)
					#n1.pointfc.tmp <- point.forecast.naiveone(data.input.tmp, n1.fit.tmp)

					
					# these 2 not showing up in output. Why? ggplot issue?
					#plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					#plot.fitted.naiveone(n1.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)					
							
					#plot(1:5,1:5) # this one shows up
	
					#for(i in 1:length(data.input.tmp)){
					#	barplot.forecasted.values.individual.ages.naiveone(n1.fit.tmp, n1.pointfc.tmp, i,abd=data.preprocess.tmp$specs$stockabundance)
					#	}
						

						
						
					#dev.off()
	#				}
	
			# fitted plot 1 for other models to be added


	#						})


	
	
	# create report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected
    # THIS IS THE ORIGINAL VERSION. IT WORKS WHEN LAUNCHING THE GUI LOCALLY
	# Have 2 options for server-based GUI
	#  		1) find a way to input a local path then write to that
	# 		2) use the downloadHandler approach like for the the pre-check pdf
	# -> not sure if option can work with ReportRs, so trying option 1 first
	
	
	
	# this version opens, but doesn't seem to link to anythin
	# shinyDirChoose(input, id= "rep.dir", roots=c(wd='.'), filetypes=c("docx"))   # or roots = c(home = '~')
	# rep.dir.use <- reactive(input$dir)
	# print(rep.dir.use)
	
	# not working either
	#volumes <- c("R Installation" = R.home())	
	#shinyDirChoose(input, id = "rep.dir", roots = volumes, session = session, restrictions = system.file(package = "base"))
	
	# trying it this way: https://stackoverflow.com/questions/46281137/reporters-package-to-download-docx-report-from-shiny
	
	
  	#observeEvent(input$CreateReportWithAge, {
	#			    print("-----------------------")

					
	#				rep.path <- parseDirPath(roots=volumes.use, selection =reports.path.use())
	#				print(rep.path)
					
					# temporary here until fixed GUI such that "With Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)
	#				print(input$file.name.2)
					# Why is this necessary?
	#				input.use <- list(model.type="WithAge",
	#								file.name= input$file.name.2$datapath,
	#								boots.method = input$boots.method,
	#								set.seed = input$set.seed,
	#								index.year = input$index.year ,
	#								B = input$B,
	#								boxcoxtransform =input$boxcoxtransform,
	#								model.use.withage = input$model.use.withage
	#								)

	#				print("-----------------------")
	#				print(input.use)
	#				print("-----------------------")

					#pdf("Test_Withage.pdf",onefile=TRUE,width=8.5,height=11)
	#				forecastR_Main(input.obj=input.use,
	#						path.Rfolder="R",
	#						path.reports=  rep.path ,  #"../../ForecastRReports",   #reports.path.use,
	#						path.template="../extdata/TemplateReport")
					
					#dev.off (not needed, b/c device turned off before at some point
	#						})

	
	
	
	output$"CreateReportWithAge" <- downloadHandler(
    filename =  "file.docx", 
		# dynamic name
	#function() {
    #  paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck.withage,"_", Sys.Date(), ".pdf", sep="")
    #},
    
	content = function(file) {
		

		input.use <- list(model.type="WithAge",
								file.name= input$file.name.2$datapath,
								boots.method = input$boots.method,
								set.seed = input$set.seed,
								index.year = input$index.year ,
								B = input$B,
								boxcoxtransform =input$boxcoxtransform,
								model.use.withage = input$model.use.withage
								)

				forecastR_Main(input.obj=input.use,
						path.Rfolder="../../R",
						path.reports=  "N1_Report_Test" ,  # just send it to the filename, and the file gets passed to downloadHandler
						path.template="../extdata/TemplateReport")
		       # note: this function call includes:
			   #    - call to startReport(), which includes doc <<- docx(template = template, empty_template=TRUE)
			   #    - sources the specified Report.R script (e.g. "n1/Report - Naive One.R")
			   #    - call to endReport(), which includes  writeDoc(doc, file = docx.file)
		
		
		
		
    }
  )









	
							
							
							
							

	# create report - Without Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected

  	observeEvent(input$create.report.withoutage, {
					print("-----------------------")


					
					# temporary here until fixed GUI such that "Without Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)


					#print(file.name.2)

					# Why is this necessary?
					input.use <- list(model.type="WithoutAge",
									file.name= input$file.name.2,
									boots.method = input$boots.method,
									set.seed = input$set.seed,
									index.year = input$index.year ,
									B = input$B,
									boxcoxtransform =input$boxcoxtransform,
									model.use.withoutage = input$model.use.withage
									)



					print("-----------------------")
					print("input.use")
					print(input.use)
					print("-----------------------")

					#pdf("Test_Withoutage.pdf", onefile=TRUE,width=8.5,height=11)

					forecastR_Main(input.obj=input.use)
					#dev.off (not needed, b/c device turned off before at some point
							})











}

