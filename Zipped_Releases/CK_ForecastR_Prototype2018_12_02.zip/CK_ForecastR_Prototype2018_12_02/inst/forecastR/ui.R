

# Think it needs these here for the server deployment
	library("ggplot2")
	library("DT")
	library("markdown")
	library("rmarkdown")
	
	library("shiny")
	library("shinydashboard")
	library("shinyjqui")
	library("shinyFiles")


model.types <- c("Naive", "TimeSeriesArima","TimeSeriesExpSmooth", "SibRegSimple","SibRegLogPower", "SibRegKalman")
	
# for reports using old code
fc.model.list.withage <-  c("n1.model","n3.model","n5.model","ARIMA.model","EXPSMOOTH.model",
						"SIMPLESIBREG.model","SIMPLELOGPOWER.model")
fc.model.list.withoutage <- c("noagemodelnaiveone","noagemodelavgthree","noagemodelavgfive",
								"noagemodelarima","noagemodelexpsmooth")
										




				
# This is a kludge, until can dynamically link the dropdown and the tabset to the ages in the input file
#ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")
ages.menu.list <- c("all","Age 3","Age 4","Age 5","Age 6")
ages.menu.list.multi <- c("Total","Age 3","Age 4","Age 5","Age 6")





retro.types <- c("retro.pm.bal", "retro.pm.all.constantyrs", "retro.pm.all.varyrs","fitted.pm.last")   
names(retro.types) <- c("Balanced","Constant Years","Variable Years","Fitted")
				
boots.method.list <-  c("meboot", "stlboot") #meboot = max entropy, stlboot = loess")
			
report.type.list <- c("Pdf - Key Plots Only","Pdf - Long","Word - Short","Word - Long")			
				
navbarPage("ForecastR", id = "MainTab",


	 tabPanel("Disclaimer",

fluidPage(

  titlePanel("Disclaimer"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/disclaimer.md")
    )
  )
)


	
	  ),  # end Help tab panel


  

#######  
 tabPanel("Data Loading", value= "data.loading",
    
pageWithSidebar(
  headerPanel("Data Loading"),
    
  sidebarPanel(
			  tags$h4("Data File"),
			  tags$hr(),
			  #shinyFilesButton(id="file.name.2", label="File select", title="Please select a file", multiple=FALSE)	, 
			  fileInput("file.name.2", "Choose CSV File", accept = c("text/csv","text/comma-separated-values,text/plain", ".csv")    ),
			  tags$hr() ,
			  tags$a("Get Some Sample Data",href="https://www.dropbox.com/sh/3fouksm7p1pxrzv/AABQjY74uuHa0Gd8a7MHyUoUa?dl=0",target="_blank")
			  #textInput("file.name", "File Name", value = "Data/SampleFile_WithAge.csv", placeholder = "Enter a file name")
			) # end sidebar
  ,
   

     mainPanel(			
	     
			div(style = 'overflow: scroll', tableOutput("inputheader.table"),height = "400px")
			
	   
		) # end main panel
  
		) #end page with side bar for  data loading
  ),  # end  second tab panel
    

#################### MODEL PRE CHECK ######################################	

  
    tabPanel("Explore", value= "precheck",

	pageWithSidebar(
	headerPanel("Explore Models"),
    
	sidebarPanel(
		selectizeInput("model.use.precheck", "Model Type", choices = model.types, selected=model.types[1]),
		selectizeInput("precheck.ageclass", "Age Class", choices = ages.menu.list, selected=ages.menu.list[1]),
		#numericInput("fc.yr", "FC Year", value=2018),  # comes from data file for now
		sliderInput("yr.range.precheck", "Data (Run Years)", sep="",min = 1960, max = 2020, value = c(1985,2017)),
		checkboxInput("precheck.boxcox", label="Box-Cox Transform (TS Models)", value = FALSE ),
		# change below to inline layout: https://github.com/rstudio/shiny/issues/1737
		numericInput("precheck.avgyrs", label=h5("Avg Years (Naive)"), value = 3 , min = 1, max = 10, step = 1,   width = "50%"),
		numericInput("precheck.intavg", label=h5("Avg n Est (Kalman)"), value = 5, min = 1, max = 10, step = 1,   width = "50%"),
		downloadButton("downloadPreCheckRep", "Download PDf report")
		#actionButton("create.precheck.summary.withoutage", "Create PDF Report")	
					  
		) # end sidebar
  ,
   

     mainPanel(			
	     
 
		 tabsetPanel(type = "tabs",
                  tabPanel("Fits & Forecast", plotOutput("precheck.plot.fitandfc",width = "100%", height = "600px")),
                  tabPanel("Residuals - Pattern",plotOutput("precheck.plot.resid_ts",width = "100%", height = "600px") ),
                  tabPanel("Residuals - Histogram",plotOutput("precheck.plot.resid_hist",width = "100%", height = "600px") ),
				  tabPanel("Residuals - QQ Norm",plotOutput("precheck.plot.resid_qq",width = "100%", height = "600px") )
				  )
		 
		 
		
	   
		) # end main panel
  
		) #end page with side bar for model pre-check

		
		
	),


	
	
	

####################################
	 tabPanel("Compare" , value= "compare",

	pageWithSidebar(
	headerPanel("Compare Models"),
    
	sidebarPanel(
		
		# https://stackoverflow.com/questions/43973863/keep-datatable-sort-between-tabs-in-shiny
		# try to link table sorting to the plot order

		actionButton("addmodel.compare", "x Add a Model"),
		actionButton("resetmodel.compare", "x Reset Models"),
		tags$p("Note: Running a new batch of models takes a little time"),
		selectizeInput("compare.ageclass", "Age Class", choices = ages.menu.list.multi, selected=ages.menu.list[1]),
		selectizeInput("compare.plotsort", "Sort Plot By", choices = c("None","AvgRank","Forecast"), selected="None"),
		selectizeInput("retrotype.compare", "Retrospective Type", choices = retro.types, selected=retro.types[1]),
		#numericInput("fc.yr", "FC Year", value=2018),  # comes from data file for now
		sliderInput("yr.range.compare", "Data (Run Years)", sep="",min = 1960, max = 2020, value = c(1985,2017)),
		checkboxGroupInput("compare.pm", label="Perf. Measures for Model Ranking", 
				choices=c("MRE","MAE","MPE","MAPE","MASE","RMSE")   , 
					selected = c("MRE","MAE","MPE","MAPE","MASE","RMSE") , inline = TRUE),
		downloadButton("downloadComparisonTxt", "x Download text file"),
		downloadButton("downloadComparisonCsv", "x Download csv files"),
		downloadButton("downloadComparisonRep", "x Download pdf report"),
		downloadButton("downloadComparisonRepWord", "Download short MSWord report")
		#actionButton("create.precheck.summary.withoutage", "Create PDF Report")	
			

			
		) # end sidebar
  ,
   

     mainPanel(			
	     
 
		 tabsetPanel(type = "tabs",
                  tabPanel("Point Forecast Table",  DT::dataTableOutput("table.multi.ptfc")),
				  tabPanel("Forecast Plot - By Age Class",plotOutput("compare.ptfc",width = "100%", height = "600px") ),
				  tabPanel("Performance", DT::dataTableOutput("table.retropm")) ,
				  tabPanel("Ranking", DT::dataTableOutput("table.ranking")) 
				  )
		 
		 
		
	   
		) # end main panel
  
		) #end page with side bar for model pre-check

	),

	
######### REPORTS	#############
  navbarMenu("Report",
 

 ##### REPORTS WITH AGE
 
 
 
 tabPanel("Basic Settings",
  
# FLUIDPAGE VERSION - NEW

fluidPage(

  titlePanel("Basic Settings"),

      
  fluidRow(
    column(4,
			tags$h4("Bootstrap Settings"),
			selectInput("boots.method", "Bootstrap Method", boots.method.list,   selected=boots.method.list[1]),
			numericInput("B", "# of Bootstrap Samples", value=2500),
			numericInput("set.seed", "Random Seed", value=1700)
			),

    column(4,
		tags$h4("Retrospective Settings"),
		numericInput("index.year", "Min # years for retrospective", value=20), 
		checkboxInput("retromeasureMRE", label="MRE", value = TRUE ),
		checkboxInput("retromeasureMAE", label="MAE", value = TRUE ),
        checkboxInput("retromeasureMPE", label="MPE", value = TRUE ),
		checkboxInput("retromeasureMAPE", label="MAPE", value = TRUE ),  
        checkboxInput("retromeasureMASE", label="MASE", value = TRUE ),
		checkboxInput("retromeasureRMSE", label="RMSE", value = TRUE ),
		selectInput("model.ranking", "Model Ranking (With Age)", c("Age-Specific","Across Ages"),   selected="Age-Specific")
		), 
  
   column(4,
		tags$h4("Box-Cox Transformation"),
		checkboxInput("boxcoxtransform", label="Do Box-Cox Transform (when applicable)", value = FALSE)
		)
 
	), # end fluid row with menus
	
  fluidRow( column(12,tags$hr() ))	,	
  fluidRow( column(12,mainPanel(tableOutput("settings.table")) ))	

  ) # end fluid page for basic settings
  
  ),  # end  settings tab panel
 
 
 
 tabPanel("With Age",value= "report.withage",
	  	pageWithSidebar(
			headerPanel("Report - With Age"),
    			sidebarPanel("", value= "report.withage",
				selectizeInput("model.use.withage", "FC Model", choices = fc.model.list.withage, multiple = TRUE ,selected=fc.model.list.withage[1]),
				sliderInput("yr.range.withage", "Years", sep="",min = 1960, max = 2020, value = c(1985,2017)),
				selectizeInput("report.type.withage","Report Type",choices = report.type.list,selected=report.type.list[1]),
				# Dirbuttons and action button work locally, but haven't figured out how to make these work from server
				# but found an example with ReporteRs and downloadHandler at https://stackoverflow.com/questions/46281137/reporters-package-to-download-docx-report-from-shiny
				#shinyDirButton(id="repdir", label="Reports Folder", title="Upload"), # Note: seems that id can't have a period (i.e. rep.dir)
				#shinyDirButton('button2',label='Directories',title='Choose Path'),
				#actionButton("create.report.withage", "Create Report")
				downloadButton("CreateReportWithAge", "Generate Report")
		),
		
	mainPanel(			
	     
		 verbatimTextOutput("reports.path.use")
		 #textOutput("fit.track")	
	   
		) # end main panel
  
		) #end page with side bar for  report without age
	
	
	
	
	), # end tabpanel for report with age
		
  tabPanel("Without Age",value= "y" #,
  	#pageWithSidebar(
	#headerPanel("Report - Without Age"),
    
	#sidebarPanel("", value= "report.withoutage",
	#	selectizeInput("model.use.withoutage", "FC Model", choices = fc.model.list.withoutage, multiple = TRUE ,selected=fc.model.list.withoutage[2]),
	#	sliderInput("yr.range.withoutage", "Years", sep="",min = 1960, max = 2020, value = c(1985,2017)),
	#	selectizeInput("report.type.withoutage","Report Type",choices = report.type.list,selected=report.type.list[1]),
	#	actionButton("create.report.withoutage", "Create Report")
	#	),
		
	#mainPanel(			
	     
	#	 textOutput("fit.track")	
	   
	#	) # end main panel
  
	#	) #end page with side bar for  report without age
	
	) #end tab panel for report without age
	
	
	),	# end navbar menu for reports
	
	
	
	 tabPanel("Help",  value= "help.panel",

fluidPage(

  titlePanel("Help Page"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/help.md")
    )
  )
)


	
	  ),  # end Help tab panel
	
	tabPanel("About",
	
fluidPage(

  titlePanel("About ForecastR"),

  fluidRow(
    column(8,
      includeMarkdown("Markdown/about.md")
    )
  )	
)	
	  )  # end about tab panel
	
	
	
) # end navbar Page


