### PROTOTYPE WARNING

THIS IS A PRELIMINARY PROTOTYPE FOR TESTING.

Do not use these data or plots, and check back often
to follow the evolutions of the tools.

For more information about the app, check the *Help* and *About* tabs.

To check a list of know bugs/issues with this prototype, 
and to add any new bugs/issues with this prototype,
go to 

**[this github thread](https://github.com/avelez-espino/Ck-ForecastR-Releases/issues/3)**


