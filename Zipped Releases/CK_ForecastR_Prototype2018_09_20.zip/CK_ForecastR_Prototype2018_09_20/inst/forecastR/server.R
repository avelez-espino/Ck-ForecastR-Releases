



function(input, output, session) {

  source("../../R/2_MainFunctionCall.R")
	source("../../R/3a_HelperFunctions_ModelFitting.R")
	source("../../R/3b_HelperFunctions_ReportCreation.R")

	# THink it needs these here for the server deployment
	library("ggplot2")
	library("DT")
	library("markdown")
	library("rmarkdown")
	
	
	
	#############################
	# have this in the launchForecastR() function in the original structure
	# but think it needs to be here for the server deployment
	# read in all ".R" files and ".r" files in /R, and all files with "_functions.r" from the subfolders"
# -------------------

fun.path <- "../../R"

for(dir.use in list.dirs(path=fun.path,full.names = TRUE, recursive = TRUE)){
	print("------------------")
	print(dir.use)
	
	if(dir.use == fun.path){pattern.list <- c("*[.]R$","*[.]r$") } 
	if(dir.use != fun.path){pattern.list <- c("_functions.R","_functions.r") } 	

	for(pattern.use in pattern.list){
		fn.file.list <- list.files(path=dir.use,pattern=pattern.use) # get all .R files 
		#print(fn.file.list)
		print("-------")
		for(file.source in fn.file.list){
			print(paste("Sourcing: ",file.source))
			source(paste(dir.use,file.source,sep="/"))
			} # end looping through files
		} # end looping through patterns
	} # end looping through folders
	
	
	
	
	
	
	

	# Basic check of required programs and 64 vs32 bit installs (is this the place for this?)

	# check if Java is installed
	# as per https://stackoverflow.com/questions/14964457/check-if-a-program-is-installed

	# Check which R version ins being used (64 or 32 bit)
	# as per SBC CK DB extraction code


	# ALMOST WORKING
	#shinyFileChoose(input, "file.name.2", session=session,roots=c(wd="."))

	#observeEvent(input$file.name.2, {
	#		file.name.2 <- parseFilePaths(roots=c(wd='.'), input$file.name.2)
    #    })


# temporary kludge -> see comments in ui.R
	ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")

  # Reactive expression to create data frame of all input values ----
  fc.settings <- reactive({

     data.frame(
      Name = c("boots.method",
			   "set.seed",
               "index.year",
			   "B",
               "boxcoxtransform",
			   "Retro-MRE",
			   "Retro-MAE",
			   "Retro-MPE",
			   "Retro-MAPE",
			   "Retro-MASE",
			   "Retro-RMSE"
			   ),
      Value = as.character(c(input$boots.method,
                             input$set.seed,
							 input$index.year ,
                             input$B,
                             input$boxcoxtransform,
							 input$retromeasureMRE ,
							 input$retromeasureMAE,
							 input$retromeasureMPE ,
							 input$retromeasureMAPE ,
							 input$retromeasureMASE,
							 input$retromeasureRMSE
							 )),
      stringsAsFactors = FALSE)

  })


	age4 <- reactive({ sample(4000,20)  })
	age5 <- reactive({ age4 + sample(800,20) })

  # this crashing because report.trigger is not recognized as a logical variable
  #report.trigger <- eventReactive(input$create.rep, {  TRUE  })
  #report.trigger <- observe(input$create.rep, {  TRUE  })
  #print(report.trigger)
  #if(isTRUE(report.trigger)){ forecastR_Main(input.obj=input) 	}

 # TESTING
 	#file.name <- reactive({input$file.name})
 	observeEvent(input$test.button, {
					write.csv(matrix(1:6,ncol=2), file="Test.csv")
							})


	# Shiny Files version: not working
	#shinyFileChoose(input,"file.name.2", session=session,roots=c(wd="."))

	#observeEvent(input$file, {
	#		inFile <- parseFilePaths(roots=c(wd='.'), input$file.name.2)
	#		load(as.character(inFile$datapath), envir=.GlobalEnv)
    #})

	#data.file <- reactive({ read.csv(input$file.name.2,stringsAsFactors=FALSE)})


	# Read in user-selected input file
    data.file <- reactive({
		inFile <- input$file.name.2
		if(is.null(inFile)){ data.use <- matrix(NA,ncol=2,nrow=5)}
		if(!is.null(inFile)){ 
				
			data.file.tmp <- read.csv(inFile$datapath, stringsAsFactors=FALSE)  
			
					
			# doing this here for now, but it's a kludge -> see https://github.com/avelez-espino/forecastR_phase4/issues/39			
			settings.cols <- c("Stock_Name","Stock_Species","Stock_Abundance","Forecasting_Year")
			settings.tmp <- data.file.tmp[,settings.cols]
			data.use <- data.file.tmp[,!(dimnames(data.file.tmp)[[2]] %in% settings.cols)]
			
			yrs.window <- min(data.use$Run_Year) : max(data.use$Run_Year) # need this for all the other tabs -> just keep all the records
			if(input$MainTab == "precheck.withage"){yrs.window <- input$yr.range.precheck.withage[1]:input$yr.range.precheck.withage[2]}
			if(input$MainTab == "precheck.withoutage"){yrs.window <- input$yr.range.precheck.withoutage[1]:input$yr.range.precheck.withoutage[2]}
			if(input$MainTab == "report.withage"){yrs.window <- input$yr.range.report.withage[1]:input$yr.range.report.withage[2]}
			if(input$MainTab == "report.withoutage"){yrs.window <- input$yr.range.report.withoutage[1]:input$yr.range.report.withoutage[2]}
		
						
			records.keep <-  data.use$Run_Year %in% yrs.window
			data.use <- data.use[records.keep,]
			data.use <- cbind(settings.tmp[1:dim(data.use)[1],],data.use)
			}
		
	return(data.use)
			
	})


	# TO INCLUDE / TRY OUT (May not have to, because doing context sensitive filtering above)
	# link the year sliders on different tabs together ? (so that have to filter only once?)
	# https://shiny.rstudio.com/reference/shiny/latest/updateSliderInput.html
	# https://github.com/rstudio/shiny/issues/867
	
	
	
	
		#read in data file  # OLD WAY
	#data.file <- reactive({ read.csv(input$file.name,stringsAsFactors=FALSE)})
	#test.input <- list(model.type == "WithAge")
	#forecastR_Main(input.obj=test.input)
   #forecastR_Main(input.obj=input)


	# TRIED TO DO IT OUTSIDE THE INDIV FUNCTIONS, BUT SOME STEP NOT WORKING
	# DO IT BELOW INSIDE EACH PLOT/TABLE FOR NOW< AND FIX LATER ->  this works for now, but need to figure out more graceful handling of reactives 
	# As it is currently, the whole fitting process is repeated for each plot and table!!!
   
   # Pre-process the data (e.g. extract FC year and variable names)
   #data.preprocess <- reactive({
	#		if(input$model.use.precheck.withage=="n1.model"){datalist.naiveone.pre(data.file)}
				# data pre-process for other models to be added
	#		})
   
    # Process the input file using the legacy functions
	#data.input <- reactive({ 
	#	data.preprocess.tmp <- data.preprocess()	
	#	if(input$model.use.precheck.withage=="n1.model"){datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	}
	#	# data prep for other models to be added
	#	})
	
   
   	output$precheck.plot.data <- renderPlot({
	     		 
			data.file.tmp <- data.file()	 


			# all these will be replace with generic data plot function, once it is ready	
			# why would they be different? look the same in quick check
			# using the n1 version that I modified to work outside env (abd=NULL argument)
			
			#if(input$model.use.precheck.withage %in% c("n1.model","n3.model","n5.model")){
					data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
					data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
					plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance)
			#		}
	
				
			
   
		})
   

   
   
   
	output$precheck.plot.fit1  <- renderPlot({
	
		data.file.tmp <- data.file()	
	
		# so far the datalist.XYZ.pre() and datalist.XYZ functions seem identical
		# therefore have not made all the corresponding changes in the other ones
		# just using the naiveone version for now, then will replace with generic function 
		# when it is ready`
	
		data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
		data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)
	
		if(input$model.use.precheck.withage=="n1.model"){
					n1.fit.tmp <- naiveone.model(data.input.tmp)
					plot.out <- plot.fitted.naiveone(n1.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}
	
		if(input$model.use.precheck.withage=="n3.model"){
					n3.fit.tmp <- avgthree.model(data.input.tmp)
					plot.out <- plot.fitted.avgthree(n3.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}
	
		if(input$model.use.precheck.withage=="n5.model"){
					n5.fit.tmp <- avgfive.model(data.input.tmp)
					plot.out <- plot.fitted.avgfive(n5.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}		

		if(input$model.use.precheck.withage=="ARIMA.model"){
					arima.fit.tmp <- arima.model(data.input.tmp,input$boxcoxtransform)
					plot.out <- plot.fitted.arima(arima.fit.tmp, input$boxcoxtransform,abd=data.preprocess.tmp$specs$stockabundance)
					}			

		if(input$model.use.precheck.withage=="EXPSMOOTH.model"){
					expsmooth.fit.tmp <- expsmooth.model(data.input.tmp,input$boxcoxtransform)
					plot.out <- plot.fitted.expsmooth(expsmooth.fit.tmp, input$boxcoxtransform,abd=data.preprocess.tmp$specs$stockabundance)
					}	
				
				
		plot.out
		
		
	
	})
   
   
   
   
   
 	output$precheck.plot.fit2  <- renderPlot({
	
		data.file.tmp <- data.file()	
	
		age.class.tmp <- match(input$precheck.withage.ageclass, ages.menu.list)
	
		data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
		data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
	
		if(input$model.use.precheck.withage=="n1.model"){
					n1.fit.tmp <- naiveone.model(data.input.tmp)
					n1.pointfc.tmp <- point.forecast.naiveone(data.input.tmp, n1.fit.tmp)
					plot.out <- barplot.forecasted.values.individual.ages.naiveone(n1.fit.tmp, n1.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}
	
	   if(input$model.use.precheck.withage=="n3.model"){
					n3.fit.tmp <- avgthree.model(data.input.tmp)
					n3.pointfc.tmp <- point.forecast.avgthree(data.input.tmp, n3.fit.tmp)
					plot.out <- barplot.forecasted.values.individual.ages.avgthree(n3.fit.tmp, n3.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}

	   if(input$model.use.precheck.withage=="n5.model"){
					n5.fit.tmp <- avgfive.model(data.input.tmp)
					n5.pointfc.tmp <- point.forecast.avgfive(data.input.tmp, n5.fit.tmp)
					plot.out <- barplot.forecasted.values.individual.ages.avgfive(n5.fit.tmp, n5.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}

	   if(input$model.use.precheck.withage=="ARIMA.model"){
					arima.fit.tmp <- arima.model(data.input.tmp,input$boxcoxtransform)
					arima.pointfc.tmp <- point.forecast.arima(data.input.tmp, arima.fit.tmp,input$boxcoxtransform)
					plot.out <- barplot.forecasted.values.individual.ages.arima(arima.fit.tmp,input$boxcoxtransform, arima.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}					
					
	   if(input$model.use.precheck.withage=="EXPSMOOTH.model"){
					expsmooth.fit.tmp <- expsmooth.model(data.input.tmp,input$boxcoxtransform)
					expsmooth.pointfc.tmp <- point.forecast.expsmooth(data.input.tmp, expsmooth.fit.tmp,input$boxcoxtransform)
					plot.out <- barplot.forecasted.values.individual.ages.expsmooth(expsmooth.fit.tmp,input$boxcoxtransform, expsmooth.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					}						
					
					
		plot.out
	
	})  
   
   
   
   
     
  output$"downloadPreCheckRep" <- downloadHandler(
    filename = function() {
      paste(gsub(".csv","",input$file.name.2 ),"_" ,input$model.use.precheck.withage,"_", Sys.Date(), ".pdf", sep="")
    },
    content = function(file) {
		
	pdf(file,onefile=TRUE,width=11,height=8.5)  


		# tried to just call the earlier plot here, but didn't work: "calling output object not allowed"
		#output$precheck.plot.data
		# -> need to recalc the fc and recreate the plots
		
		
		data.file.tmp <- data.file()
		
		
		ages.vec <- sort(unique(data.file.tmp$Age_Class))
				
		# plot tests
		# plot(data.file.tmp$Run_Year, data.file.tmp$Average_Escapement)
		# test.plot(data.file.tmp$Run_Year, data.file.tmp$Average_Escapement) # this one works
		
		data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
		data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
		
		
		if(input$model.use.precheck.withage=="n1.model"){
			n1.fit.tmp <- naiveone.model(data.input.tmp)
			n1.pointfc.tmp <- point.forecast.naiveone(data.input.tmp, n1.fit.tmp)
			print(plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance))
			print(plot.fitted.naiveone(n1.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance))
		
			for(age.class.tmp in 1:length(ages.vec)){
					print(barplot.forecasted.values.individual.ages.naiveone(n1.fit.tmp, n1.pointfc.tmp, age.class.tmp ,abd=data.preprocess.tmp$specs$stockabundance))
					}
			} # end n1.model

			
		if(input$model.use.precheck.withage=="n3.model"){
			n3.fit.tmp <- avgthree.model(data.input.tmp)
			n3.pointfc.tmp <- point.forecast.avgthree(data.input.tmp, n3.fit.tmp)
			print(plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance))
			print(plot.fitted.avgthree(n3.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance))
		
			
			for(age.class.tmp in 1:length(ages.vec)){
					print(barplot.forecasted.values.individual.ages.avgthree(n3.fit.tmp, n3.pointfc.tmp, age.class.tmp ,abd=data.preprocess.tmp$specs$stockabundance))
					}
			} # end n3.model			
			
			
		if(input$model.use.precheck.withage=="n5.model"){
			n5.fit.tmp <- avgfive.model(data.input.tmp)
			n5.pointfc.tmp <- point.forecast.avgfive(data.input.tmp, n5.fit.tmp)
			print(plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance))
			print(plot.fitted.avgfive(n5.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance))
		
			
			for(age.class.tmp in 1:length(ages.vec)){
					print(barplot.forecasted.values.individual.ages.avgfive(n5.fit.tmp, n5.pointfc.tmp, age.class.tmp ,abd=data.preprocess.tmp$specs$stockabundance))
					}
			} # end n5.model		
			
	

		if(input$model.use.precheck.withage=="ARIMA.model"){


		arima.fit.tmp <- arima.model(data.input.tmp,input$boxcoxtransform)
		arima.pointfc.tmp <- point.forecast.arima(data.input.tmp, arima.fit.tmp,input$boxcoxtransform)
					
		print(plot.fitted.arima(arima.fit.tmp, input$boxcoxtransform,abd=data.preprocess.tmp$specs$stockabundance))
		print(plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance))
				
			
			for(age.class.tmp in 1:length(ages.vec)){
					print(barplot.forecasted.values.individual.ages.arima(arima.fit.tmp,input$boxcoxtransform, arima.pointfc.tmp, age.class.tmp,abd=data.preprocess.tmp$specs$stockabundance))
					}
			} # end arima.model		
			
	
	
			
		dev.off()
    }
  )
   
   
	output$inputheader.table <- renderTable({ data.file() })  # masking issue with package DT? shiny::renderTable doesn't fix it



	output$settings.table <- renderTable({   fc.settings() })
	#output$settings.table <- renderText({   fc.settings()})


	# plot sample
	# output$fit.plot <- 	renderPlot({
	#		   				par(pty="s")
	#			age4 <- sample(4000,20)
	#			age5 <- age4 + sample(800,20)
	#			plot(age4,age5,xlab="Age4",ylab="Age5", bty="n",pch=21,col="darkblue",bg="lightgrey")
	#			abline(lm(age5~age4),col="red")
	#			})


     # this is just a specific test of the method for passing info back and forth
	 # the actual function will need to be a lot more general to avoid replication
     output$fc.plot.1 <- renderPlot({

			x.full <- data.file()[,"Run_Year"]
			y.full <- data.file()[,"Average_Escapement"]
			fc.yr <- input$fc.yr.precheck.withoutage


			use.range <- input$yr.range.precheck.withoutage
			use.idx <-  x.full >= min(use.range) & x.full <= max(use.range)

			avg.ret.idx <- x.full >= (max(use.range)- input$avg.ret.numyrs)   & x.full <= max(use.range)
			avg.ret.yrs <- x.full[avg.ret.idx]
			avg.ret.fc <- mean(y.full[avg.ret.idx])

			plot(x.full,y.full,xlab="Run Year",ylab="Total Escapement", bty="n",pch=21,
					col="darkblue",bg="white",cex=1.3,xlim=c(min(use.range,x.full,fc.yr),max(use.range,x.full,fc.yr)))

			points(x.full[use.idx],y.full[use.idx], pch=21, col="darkblue",bg="lightgrey",cex=2)
			lines(avg.ret.yrs,rep(avg.ret.fc,length(avg.ret.yrs)) ,col="red",lwd=2)
			points(avg.ret.yrs,y.full[avg.ret.idx], pch=21, col="red",bg="red",cex=2)
			points(fc.yr,avg.ret.fc ,pch=23,col="red",bg="red",cex=5)



      })


	# create precheck summary report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected

  	observeEvent(input$create.precheck.summary.withoutage, {
					print("-----------------------")

		# FOR NOW, THIS REPLICATES ALL TEH STEPS FROM THE PRE-CHECK PLOTS ABOVE
		data.file.tmp <- data.file()	
		
		
	
		if(input$model.use.precheck.withage=="n1.model"){
					#pdf("../../OUTPUT/Naive1_WithAge_Precheck.pdf",onefile=TRUE,width=8.5,height=11) # Need to make this dynamic to include file name 
					
					#data.preprocess.tmp <- datalist.naiveone.pre(data.file.tmp)
					#data.input.tmp <- datalist.naiveone(data.preprocess.tmp$output , data.preprocess.tmp$specs$forecastingyear)	
					#n1.fit.tmp <- naiveone.model(data.input.tmp)
					#n1.pointfc.tmp <- point.forecast.naiveone(data.input.tmp, n1.fit.tmp)

					
					# these 2 not showing up in output. Why? ggplot issue?
					#plot.data.naiveone(data.input.tmp,abd=data.preprocess.tmp$specs$stockabundance)
					#plot.fitted.naiveone(n1.fit.tmp,abd=data.preprocess.tmp$specs$stockabundance)					
							
					#plot(1:5,1:5) # this one shows up
	
					#for(i in 1:length(data.input.tmp)){
					#	barplot.forecasted.values.individual.ages.naiveone(n1.fit.tmp, n1.pointfc.tmp, i,abd=data.preprocess.tmp$specs$stockabundance)
					#	}
						

						
						
					#dev.off()
					}
	
			# fitted plot 1 for other models to be added


							})


	# create report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected

  	observeEvent(input$create.report.withage, {
					print("-----------------------")

					# temporary here until fixed GUI such that "With Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)


					#print(file.name.2)

					# Why is this necessary?
					input.use <- list(model.type="WithAge",
									file.name= input$file.name.2$datapath,
									boots.method = input$boots.method,
									set.seed = input$set.seed,
									index.year = input$index.year ,
									B = input$B,
									boxcoxtransform =input$boxcoxtransform,
									model.use.withage = input$model.use.withage
									)



					print("-----------------------")
					print(input.use)
					print("-----------------------")

					pdf("Test_Withage.pdf",onefile=TRUE,width=8.5,height=11)
					forecastR_Main(input.obj=input.use)
					#dev.off (not needed, b/c device turned off before at some point
							})


	# create report - With Age
    # for now use 2 separate button labels, but should rework it to respond depending on which tab is selected

  	observeEvent(input$create.report.withoutage, {
					print("-----------------------")

					# temporary here until fixed GUI such that "Without Age" report tab
					# automatically sets this (or the whole with/without thing gets more fundamentally handled)


					#print(file.name.2)

					# Why is this necessary?
					input.use <- list(model.type="WithoutAge",
									file.name= input$file.name.2,
									boots.method = input$boots.method,
									set.seed = input$set.seed,
									index.year = input$index.year ,
									B = input$B,
									boxcoxtransform =input$boxcoxtransform,
									model.use.withoutage = input$model.use.withage
									)



					print("-----------------------")
					print("input.use")
					print(input.use)
					print("-----------------------")

					#pdf("Test_Withoutage.pdf", onefile=TRUE,width=8.5,height=11)

					forecastR_Main(input.obj=input.use)
					#dev.off (not needed, b/c device turned off before at some point
							})











}

