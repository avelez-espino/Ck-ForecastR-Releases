### Instructions to use ForecastR Version **X**

#### Running List of things to add to help file
* retrospective measures overview(MRE,MAE,MPE,MAPE,MASE,RMSE)


#### Required Programs / Versions

ForecastR Phase-3 Release **X** has been tested on the following systems:
* Windows 10 Pro 64 Bit / Office 365 / R 3.5.1 32Bit Install /  Java 1.8.0_171-b11 32Bit
* AV system
* MF system

Notes

* Users need to have a Java version 1.6.0 or greater. Java and R architectures (32-bit vs. 64-bit) must be compatible.
The *launchForecastR()* function does a Java vs. R version check before launching. If necessary, manually install [Java](https://java.com/en/download/help/windows_manual_download.xml)

* ForecastR requires MS Office to generate reports as *Word* documents. *Should build/test so that can run model pre-check and pdf reports without having Office*


#### Required R Packages

ForecastR uses many R packages (i.e. dependencies), which are installed automatically from CRAN. However, it also uses 2 packages that are not on CRAN, and are installed via the *devtools()* function from GitHub. These  *{ReporterRs}* and *{ReporteRsjars}* by [David Gohel](http://davidgohel.github.io/ReporteRs/)

Package installation may give some warnings of function overwrite, but the install sequence and function calls have been set up to avoid any conflicts.



#### Using the GUI

* Insert details here









#### Data Files


* Format your data following the .csv example input files.
* *more details here*


#### Statistical Notes

* ForecastR doesn't accept time series with missing data. The inclusion of imputing algorithms was considered in previous developmental phases of ForecastR but the idea was abandoned in favor of external preparation of input files without missing data.

* The presence of  legitimate "zeros" in time series sometimes produces bizarre output and statistics in ForecastR. If this happens, user options are

   * to explore the alternative bootstrapping methods in ForecastR, maximum entropy ('meboot') or loess bootstrapping ('stlboot'),
   * to experiment with and without the inclusion of the Box-Cox transformation, or
   * to aggregate abundance data from two ages into a single age class. Imputing "ones" can sometime improve the quality of the output.

* Users need to be aware that forecasting models, but in particular time series models, require a reasonable number of data points. Time series long enough are necessary to produce reliable forecasts using the ARIMA or Exponential Smoothing modules. "Very" short time series (e.g., less than 15 data points) can be problematic for the operation of these modules.

* Note about *bootstrapping for Simple Sibling Regression* :The bootstrapping for the simple sibling regression model can be done discarding negative point forecasts during the bootstrapping process. However, this ad-hoc process will not necessarily guarantee adequate coverage for the resulting forecasting intervals and may result in a skewed distribution of bootstrapped point forecasts.The version of bootstrapping used in the Simple Sibling Regression in this release is based on resampling residuals and keeping negative point forecasts. Future versions of this module will have the following options:

   * resampling residuals and keeping negative point forecasts (should any be present);
   * resampling residuals but discarding negative point forecasts (should any be present);
   * resampling cases and keeping negative point forecasts  (where a case represents a row of the data set used to fit the model);
   * resampling cases  but discarding negative point forecasts.

* Note about *simple log power regression (SLPR)*:  there is no need to worry about negative point forecasts by virtue of the log transformation of the data.
