
# VARIABLES/ CAPABILITIES TO ADD
# - change the model.use selection dynamically based on model.type using one of the methods in https://shiny.rstudio.com/articles/dynamic-ui.html
# - test alternative layout options: https://shiny.rstudio.com/articles/layout-guide.html
# - design pieces: https://rstudio.github.io/shinydashboard/structure.html
# - https://stackoverflow.com/questions/24240434/r-shiny-error-object-of-type-closure-is-not-subsettable

stk.list <- c("Stock 1","Stock 2","Stock 3","Stock 4")

# NOT USED AT MOMENT (SET BASED ON BUTTON)
model.type.list <- c("WithAge","WithoutAge")


# For now, exactly replicate the existing list of  model options
# During re-design, need to fix the fundamental structure 
# e.g. naive n.yr, rather than n1, n3, n5

fc.model.list.withage <-  c("n1.model","n3.model","n5.model","ARIMA.model","EXPSMOOTH.model",
						"SIMPLESIBREG.model","SIMPLELOGPOWER.model")
fc.model.list.withoutage <- c("noagemodelnaiveone","noagemodelavgthree","noagemodelavgfive",
								"noagemodelarima","noagemodelexpsmooth")
						
# This is a kludge, until can dynamically link the dropdown and the tabset to the ages in the input file
ages.menu.list <- c("First","Second","Third","Fourth","Fifth","Sixth","Seventh","Eighth")
						

#fc.model.list.withage <- c("Sibling - SimpleReg1","Sibling - SimpleReg2",
#				"Sibling - LogPowerReg1","Sibling - LogPowerReg2",
#				"Sibling - ComplexReg1","Sibling - ComplexReg2",
#				"Return - ExpSmoothing","Return - Naive 1yr","Return - Naive 3yr","Return - Naive 5yr")
			
#fc.model.list.withoutage <- c("Return - ExpSmoothing","Return - Naive 1yr","Return - Naive 3yr", "Return - Naive 5yr","ABC")

				
			

				
				
				
boots.method.list <-  c("meboot", "stlboot") #meboot = max entropy, stlboot = loess")
			
			
			
report.type.list <- c("Pdf - Key Plots Only","Pdf - Long","Word - Short","Word - Long")			
				
navbarPage("ForecastR", id = "MainTab",


	 tabPanel("Disclaimer",

fluidPage(

  titlePanel("Disclaimer"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/disclaimer.md")
    )
  )
)


	
	  ),  # end Help tab panel


 tabPanel("Basic Settings",
  
# FLUIDPAGE VERSION - NEW

fluidPage(

  titlePanel("Basic Settings"),

      
  fluidRow(
    column(4,
			tags$h4("Bootstrap Settings"),
			selectInput("boots.method", "Bootstrap Method", boots.method.list,   selected=boots.method.list[1]),
			numericInput("B", "# of Bootstrap Samples", value=2500),
			numericInput("set.seed", "Random Seed", value=1700)
			),

    column(4,
		tags$h4("Retrospective Settings"),
		numericInput("index.year", "Min # years for retrospective", value=20), 
		checkboxInput("retromeasureMRE", label="MRE", value = TRUE ),
		checkboxInput("retromeasureMAE", label="MAE", value = TRUE ),
        checkboxInput("retromeasureMPE", label="MPE", value = TRUE ),
		checkboxInput("retromeasureMAPE", label="MAPE", value = TRUE ),  
        checkboxInput("retromeasureMASE", label="MASE", value = TRUE ),
		checkboxInput("retromeasureRMSE", label="RMSE", value = TRUE ),
		selectInput("model.ranking", "Model Ranking (With Age)", c("Age-Specific","Across Ages"),   selected="Age-Specific")
		), 
  
   column(4,
		tags$h4("Box-Cox Transformation"),
		checkboxInput("boxcoxtransform", label="Do Box-Cox Transform (when applicable)", value = FALSE)
		)
 
	), # end fluid row with menus
	
  fluidRow( column(12,tags$hr() ))	,	
  fluidRow( column(12,mainPanel(tableOutput("settings.table")) ))	

  ) # end fluid page for basic settings
  
  ),  # end  first tab panel
  

#######  
 tabPanel("Data Loading", value= "data.loading",
    
pageWithSidebar(
  headerPanel("Data Loading"),
    
  sidebarPanel(
			  tags$h4("Data File"),
			  tags$hr(),
			  #shinyFilesButton(id="file.name.2", label="File select", title="Please select a file", multiple=FALSE)	, 
			  fileInput("file.name.2", "Choose CSV File", accept = c("text/csv","text/comma-separated-values,text/plain", ".csv")    ),
			  tags$hr() ,
			  tags$a("Get Some Sample Data",href="https://www.dropbox.com/sh/3fouksm7p1pxrzv/AABQjY74uuHa0Gd8a7MHyUoUa?dl=0",target="_blank")
			  #textInput("file.name", "File Name", value = "Data/SampleFile_WithAge.csv", placeholder = "Enter a file name")
			) # end sidebar
  ,
   

     mainPanel(			
	     
			div(style = 'overflow: scroll', tableOutput("inputheader.table"),height = "400px")
			
	   
		) # end main panel
  
		) #end page with side bar for  data loading
  ),  # end  second tab panel
    

#################### MODEL PRE CHECK ######################################	
  navbarMenu("Model Pre-Check",
  
  
### Model Pre-Check With Age  
    tabPanel("With Age", value= "precheck.withage",

	pageWithSidebar(
	headerPanel("Pre-Check - With Age"),
    
	sidebarPanel(
		selectizeInput("model.use.precheck.withage", "FC Model", choices = fc.model.list.withage, selected=fc.model.list.withage[1]),
		selectizeInput("precheck.withage.ageclass", "Age Class (for \"By Age\" plots)", choices = ages.menu.list, selected=ages.menu.list[1]),
		#numericInput("fc.yr", "FC Year", value=2018),  # comes from data file for now
		sliderInput("yr.range.precheck.withage", "Data (Run Years)", sep="",min = 1960, max = 2020, value = c(1985,2017)),	
		downloadButton("downloadPreCheckRep", "Download PDf report")
		#actionButton("create.precheck.summary.withoutage", "Create PDF Report")	
					  
		) # end sidebar
  ,
   

     mainPanel(			
	     
	# to dynamically modify the number of tabpanels is a it trickier
    # https://stackoverflow.com/questions/19470426/r-shiny-add-tabpanel-to-tabsetpanel-dynamically-with-the-use-of-renderui	
	# https://stackoverflow.com/questions/39276104/r-shiny-how-to-add-data-tables-to-dynamically-created-tabs	 
		 
		 tabsetPanel(type = "tabs",
                  tabPanel("Data", plotOutput("precheck.plot.data",width = "100%", height = "600px")),
                  tabPanel("Fitted Values",plotOutput("precheck.plot.fit1",width = "100%", height = "600px") ),
                  tabPanel("Forecast - By Age",plotOutput("precheck.plot.fit2",width = "100%", height = "600px") )
				  )
		 # verbatimTextOutput("summary")
		 # tableOutput("table")
		 
		 
		
	   
		) # end main panel
  
		) #end page with side bar for  data loading

		
		
	),


	
	
### Model Pre-Check Without Age 	
    tabPanel("Without Age", value= "precheck.withoutage",
	
	pageWithSidebar(
	headerPanel("Pre-Check - Without Age"),
    
	sidebarPanel(
	   	selectizeInput("model.use.precheck.withoutage", "x -FC Model", choices = fc.model.list.withoutage, selected=fc.model.list.withoutage[4]),
		numericInput("avg.ret.numyrs", "Avg Return Yrs", value=5,min=1),
		numericInput("fc.yr.precheck.withoutage", "FC Year", value=2018),
		sliderInput("yr.range.precheck.withoutage", "Years", sep="",min = 1960, max = 2020, value = c(1985,2017))
		) # end sidebar
  ,
   

     mainPanel(			
	     
		 plotOutput("fc.plot.1")	
	   
		) # end main panel
  
		) #end page with side bar for  data loading
	
	

		)	# end tab panel	for pre-check without age

	
	
	), # end navbar menu for Model Pre-Check 
	
	
######### REPORTS	#############
  navbarMenu("Reports",
 

 ##### REPORTS WITH AGE
 
 tabPanel("With Age",value= "report.withage",
	  	pageWithSidebar(
			headerPanel("Report - With Age"),
    
			sidebarPanel("", value= "report.withage",
				selectizeInput("model.use.withage", "FC Model", choices = fc.model.list.withage, multiple = TRUE ,selected=fc.model.list.withage[2]),
				sliderInput("yr.range.withage", "Years", sep="",min = 1960, max = 2020, value = c(1985,2017)),
				selectizeInput("report.type.withage","Report Type",choices = report.type.list,selected=report.type.list[1]),
				actionButton("create.report.withage", "Create Report")
		),
		
	mainPanel(			
	     
		 textOutput("fit.track")	
	   
		) # end main panel
  
		) #end page with side bar for  report without age
	
	
	
	
	), # end tabpanel for report with age
		
  tabPanel("Without Age",value= "y" #,
  	#pageWithSidebar(
	#headerPanel("Report - Without Age"),
    
	#sidebarPanel("", value= "report.withoutage",
	#	selectizeInput("model.use.withoutage", "FC Model", choices = fc.model.list.withoutage, multiple = TRUE ,selected=fc.model.list.withoutage[2]),
	#	sliderInput("yr.range.withoutage", "Years", sep="",min = 1960, max = 2020, value = c(1985,2017)),
	#	selectizeInput("report.type.withoutage","Report Type",choices = report.type.list,selected=report.type.list[1]),
	#	actionButton("create.report.withoutage", "Create Report")
	#	),
		
	#mainPanel(			
	     
	#	 textOutput("fit.track")	
	   
	#	) # end main panel
  
	#	) #end page with side bar for  report without age
	
	) #end tab panel for report without age
	
	
	),	# end navbar menu for reports
	
	
	
	 tabPanel("Help",  value= "help.panel",

fluidPage(

  titlePanel("Help Page"),

  fluidRow(
    column(8,
	  includeMarkdown("Markdown/help.md")
    )
  )
)


	
	  ),  # end Help tab panel
	
	tabPanel("About",
	
fluidPage(

  titlePanel("About ForecastR"),

  fluidRow(
    column(8,
      includeMarkdown("Markdown/about.md")
    )
  )	
)	
	  )  # end about tab panel
	
	
	
) # end navbar Page


