source("R/n3/Review Code - Average Three_functions.r")

########################################################################################################
# Naive Time Series Forecasting (Average of Past 3 Years) - Forecasting Results
########################################################################################################


n3$datafile <- datafile_original
n3$datafilesub <- n3$datafile

n3$stockabundance <- n3$datafile$Stock_Abundance[1]
n3$stockabundance <- gsub("[[:space:]]", "_", n3$stockabundance)

n3$stockname <- n3$datafile$Stock_Name[1]
n3$stockspecies <- n3$datafile$Stock_Species[1]
n3$forecastingyear <- n3$datafile$Forecasting_Year[1]

usePackage("stringr")
n3$forecastingyear <- str_replace_all(n3$forecastingyear, "\n","")
n3$forecastingyear <- as.numeric(n3$forecastingyear)


n3$extract_ages <- sort(unique(n3$datafilesub$Age_Class))
n3$extract_names <- paste("T",n3$extract_ages,sep="")
n3$extract_names <- c("BY",n3$extract_names)


n3$tmpsub <- list()
for (i in 1:length(n3$extract_ages)){
    n3$tmpsub[[i]] <- subset(n3$datafilesub, Age_Class==n3$extract_ages[i])[,c("Brood_Year",paste0("Average","_",n3$stockabundance))]
}


n3$list.of.data.frames <- n3$tmpsub
n3$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), n3$list.of.data.frames)

n3$datafile_new <- n3$merged.data.frame
names(n3$datafile_new) <- n3$extract_names

## datafile <<- datafile_new

n3$datafile <- n3$datafile_new

#======================================================================================================
# Change unit of data to 1000 (thousands)
#======================================================================================================

## unit <- 1000

## datafile[,-1] <- datafile[,-1]*unit




cat("Working data file is: ","\n")
print(n3$datafile)
cat("\n")


#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for naive forecasting (average of past 3 years) ---------------------------------

n3$datalist <- n3$datalist.avgthree(n3$datafile, n3$forecastingyear)  # CY refers to the T variable with highest age


#--------- prepare data table for reporting --------------------------------------------------

n3$datafile.report <-  n3$datafile

n3$datafile.report[n3$datafile.report <0] <- "NA"



#--------- plot data to be used for naive forecasting (average of past three years) (uses ggplot) ---------------------------
n3$plot.data.avgthree(n3$datalist)


#--------- helper function for computing the average of the past three years of a time series -----

#---------  fit naive model (average of past three years) -----------------------------------------

n3$avgthree.model.fits  <- n3$avgthree.model(n3$datalist)

n3$fits <- n3$avgthree.model.fits

#---------  Plot naive model (average of past 3 years) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------

## fits <- avgthree.model.fits
n3$plot.fitted.avgthree(n3$avgthree.model.fits)


#-------------------------------------------------------------------------------
# Model Diagnostics for Age-Specific Naive Time Series Model  (Average of Previous 3 Years)
#-------------------------------------------------------------------------------

n3$diagnostics.avgthree.model.fit(n3$fits,i=1)

#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

n3$point.forecast.avgthree(n3$datalist, n3$fits)

n3$results.point.forecast.avgthree <- NULL
for (j in 1:length(n3$avgthree.model.fits)){

       n3$tmp_list <- n3$point.forecast.avgthree(n3$datalist, n3$avgthree.model.fits)[[j]]

       # list2 <- unlist(list1)

       # point.pred.asslr <- rbind(point.pred.asslr, list2)

       n3$tmp_df <- do.call(cbind.data.frame, n3$tmp_list)

       n3$results.point.forecast.avgthree <- rbind(n3$results.point.forecast.avgthree, n3$tmp_df)

}

n3$results.point.forecast.avgthree$Model <- as.character(n3$results.point.forecast.avgthree$Model)

n3$results.point.forecast.avgthree

## str(results.point.forecast.avgthree)


#--------- Naive Model (Average of Previous 3 Years): retrospective evaluation for each individual age ----------------------------------

n3$results.individual.ages.retro.predictive.performance.avgthree  <-
     n3$individual.ages.retro.predictive.performance.avgthree(n3$datalist, n3$index.year)

## results.individual.ages.retro.predictive.performance.avgthree

## names(results.individual.ages.retro.predictive.performance.avgthree)

#---------------------------------------------------------------------------------------


#----------------------------------------------------------------------------------------


### report retrospective performance measures for individual ages in a nicer format

n3$MIA <- n3$measures.individual.ages.retro.avgthree(n3$results.individual.ages.retro.predictive.performance.avgthree)

## MIA


##
## Total Age
##


#---------  Naive Forecast (Average of Previous 3 Years): retrospective evaluation for the total age ----------------------------------------

n3$results.total.age.retro.predictive.performance.avgthree <-
      n3$total.age.retro.predictive.performance.avgthree(n3$datalist, n3$index.year)

n3$results.total.age.retro.predictive.performance.avgthree

## names(results.total.age.retro.predictive.performance.avgthree)

#-------------------------------------------------------------------------------
n3$total.age.retro.plot.avgthree(n3$total.age.retro.plot.info.avgthree, n3$stockabundance)

#-------------------------------------------------------------------------------

### report retrospective performance measures for total age in a nicer format

n3$MTA <- n3$measures.total.age.retro.avgthree(n3$results.total.age.retro.predictive.performance.avgthree)

## M <- merge(MIA, MTA, by = intersect(names(MIA), names(MTA)), sort=FALSE)

n3$M <- merge(n3$MIA, n3$MTA, by = c("Measure"), sort=FALSE)

n3$M <- subset(n3$M, select=-Model.y)

## M

names(n3$M)[names(n3$M)=="Model.x"] <- "Model"

## M

n3$M.avgthree <- n3$M

### report actual, forecasted and error values for total age in a nicer format

n3$results.afe.total.age.retro.avgthree <-
 n3$afe.total.age.retro.avgthree(n3$results.total.age.retro.predictive.performance.avgthree)

## results.afe.total.age.retro.avgthree


## usePackage("scales")
## cbind(results.afe.total.age.retro.avgthree[,1],
##      comma(round(results.afe.total.age.retro.avgthree[,"Actual"])),
##      comma(round(results.afe.total.age.retro.avgthree[,"Forecast"])),
##      comma(round(results.afe.total.age.retro.avgthree[,"Error"]))
## )

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## meboot2 bootstrap for a specific age

## fit <- avgthree.model.fits[[1]]
## forecast.avgthree.modified.meboot(fit, level=80, npaths=9999)

n3$fits <- n3$avgthree.model.fits
n3$pred.int.individual.ages.avgthree <- n3$prediction.intervals.individual.ages.avgthree(n3$fits, n3$bootmethod, level=80, npaths=n3$B)

## pred.int.individual.ages.avgthree


#----------------------------------------------------------------------------

n3$PI.ctr <- NULL
n3$PI.lwr <- NULL
n3$PI.upr <- NULL
# PI.med <- NULL
n3$PI.sim <- NULL
n3$nms <- NULL

for (k in 1:length(n3$pred.int.individual.ages.avgthree)){

     n3$PI.ctr <- c(n3$PI.ctr,
                 n3$pred.int.individual.ages.avgthree[[k]]$PI.ctr)

     n3$PI.lwr <- c(n3$PI.lwr,
                 n3$pred.int.individual.ages.avgthree[[k]]$PI.lwr)

     n3$PI.upr <- c(n3$PI.upr,
                 n3$pred.int.individual.ages.avgthree[[k]]$PI.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.avgthree)[[k]]$PI.median)

     n3$PI.sim <- cbind(n3$PI.sim, n3$pred.int.individual.ages.avgthree[[k]]$sim)

     n3$nms <- c(n3$nms, n3$pred.int.individual.ages.avgthree[[k]]$age)

}

colnames(n3$PI.sim) <- n3$nms


n3$PI.lwr[n3$PI.lwr < 0] <- 0
n3$PI.upr[n3$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

n3$PI.ctr <- round(n3$PI.ctr)
n3$PI.lwr <- round(n3$PI.lwr)
n3$PI.upr <- round(n3$PI.upr)
## PI.med <- round(PI.med)


n3$PI.individual.ages.avgthree <- data.frame(PI.ctr=n3$PI.ctr, PI.lwr=n3$PI.lwr, PI.upr=n3$PI.upr)

n3$PI.individual.ages.avgthree.no.comma <- data.frame(PI.ctr=n3$PI.ctr, PI.lwr=n3$PI.lwr, PI.upr=n3$PI.upr)


## PI.individual.ages.avgthree

usePackage("scales")

n3$PI.individual.ages.avgthree <- comma(n3$PI.individual.ages.avgthree)

n3$PI.individual.ages.avgthree

n3$PI.individual.ages.avgthree.sim <- n3$PI.sim

##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - individual ages
#
##########################################################################################

n3$plot.distribution.bootstrapped.point.forecasts.individual.ages.avgthree(n3$PI.individual.ages.avgthree.sim,
                                                                        n3$PI.individual.ages.avgthree.no.comma, n3$stockabundance)

############################################################################################
#*******************************************************************************************
#
#------------ compute prediction interval for point forecast of total age       -----------
#
#*******************************************************************************************

n3$avgthree.sim.total.age <- NULL
n3$nms <- NULL
n3$avgthree.PI.ctr.total.age <- 0
for (k in 1:length(n3$pred.int.individual.ages.avgthree)){
     n3$avgthree.sim.total.age <- cbind(n3$avgthree.sim.total.age, n3$pred.int.individual.ages.avgthree[[k]]$sim)
     n3$nms <- c(n3$nms, n3$pred.int.individual.ages.avgthree[[k]]$age)
     n3$avgthree.PI.ctr.total.age <- n3$avgthree.PI.ctr.total.age + n3$pred.int.individual.ages.avgthree[[k]]$PI.ctr
}

colnames(n3$avgthree.sim.total.age) <- n3$nms

n3$PI.total.age.avgthree <- NULL


n3$sim <- apply(n3$avgthree.sim.total.age, 1, sum)

n3$PI.total.age.avgthree$PI.ctr <- n3$avgthree.PI.ctr.total.age
## PI.total.age.avgthree$PI.med <- quantile(sim, 0.500)
n3$PI.total.age.avgthree$PI.lwr <- quantile(n3$sim, 0.10, type=8)  # need to automate this!
n3$PI.total.age.avgthree$PI.upr <- quantile(n3$sim, 0.90, type=8)  # need to automate this!

n3$PI.total.age.avgthree <- data.frame(n3$PI.total.age.avgthree)

## names(PI.total.age.avgthree) <- c("PI.ctr","PI.med","PI.lwr","PI.upr")
names(n3$PI.total.age.avgthree) <- c("PI.ctr","PI.lwr","PI.upr")

## PI.total.age.avgthree

rownames(n3$PI.total.age.avgthree) <- NULL

n3$PI.total.age.avgthree


#-----------------------------------------------------------------------------------------------


n3$PI.total.age.avgthree$PI.lwr[n3$PI.total.age.avgthree$PI.lwr < 0] <- 0
n3$PI.total.age.avgthree$PI.upr[n3$PI.total.age.avgthree$PI.upr < 0] <- 0
## PI.total.age.avgthree$PI.med[PI.total.age.avgthree$PI.med < 0] <- 0

n3$PI.total.age.avgthree$PI.ctr <- round(n3$PI.total.age.avgthree$PI.ctr)
n3$PI.total.age.avgthree$PI.lwr <- round(n3$PI.total.age.avgthree$PI.lwr)
n3$PI.total.age.avgthree$PI.upr <- round(n3$PI.total.age.avgthree$PI.upr)
## PI.total.age.avgthree$PI.med <- round(PI.total.age.avgthree$PI.med)

usePackage("scales")

n3$PI.total.age.avgthree.no.comma <- n3$PI.total.age.avgthree

n3$PI.total.age.avgthree$PI.ctr <- comma(n3$PI.total.age.avgthree$PI.ctr)

n3$PI.total.age.avgthree$PI.lwr <- comma(n3$PI.total.age.avgthree$PI.lwr)

n3$PI.total.age.avgthree$PI.upr <- comma(n3$PI.total.age.avgthree$PI.upr)

## PI.total.age.avgthree$PI.med <- comma(PI.total.age.avgthree$PI.med)

## PI.total.age.avgthree

n3$PI.total.age.avgthree.sim <- n3$sim



##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - total age
#
##########################################################################################


###
### Histogram of Bootstrap Predictions
###

n3$plot.distribution.bootstrapped.point.forecasts.total.age.avgthree(n3$PI.total.age.avgthree.sim,
                                                                  n3$PI.total.age.avgthree.no.comma,
                                                                  n3$stockabundance)

#-----------------------------------------------------------------------------------------
# Scatter plot of retrospectively forecasted versus actual values of abundance (individual ages, avgthree)
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.avgthree

## plot.results.afe.individual.ages.retro.avgthree(
##   ## avgthree.model.fits,
##   results.individual.ages.retro.predictive.performance.avgthree
##   )



#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values of abundance (individual ages, avgthree)
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.avgthree
## timeseries.plot.results.afe.individual.ages.retro.avgthree(results, stockabundance)


## timeseries.plot.results.afe.individual.ages.retro.avgthree(results.individual.ages.retro.predictive.performance.avgthree,
##                                                           stockabundance)



#*******************************************************************************
# Scatter plot of forecasted vs. actual abundance (total age, avgthree)
#
#*******************************************************************************

n3$results <- n3$results.total.age.retro.predictive.performance.avgthree

n3$scatter.plot.results.afe.total.age.retro.avgthree(n3$results)



#*******************************************************************************
# Time series plot of forecasted vs. actual abundance (total age, avgthree)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.avgthree
## timeseries.plot.results.afe.total.age.retro.avgthree(results, stockabundance)

n3$timeseries.plot.results.afe.total.age.retro.avgthree(n3$results.total.age.retro.predictive.performance.avgthree, n3$stockabundance)

#*******************************************************************************
# Density of Retrospective Forecast Errors - Individual Ages
#*******************************************************************************


###
### Density of Retrospective Forecast Errors: Individual Ages
###

n3$dens.results.afe.individual.ages.retro.avgthree(n3$avgthree.model.fits,
    n3$results.individual.ages.retro.predictive.performance.avgthree)



#*******************************************************************************
#
# Density of retrospective forecast errors (total age)
#
#*******************************************************************************

## results <- results.afe.total.age.retro.avgthree

n3$dens.results.afe.total.age.retro.avgthree(n3$results.afe.total.age.retro.avgthree)




#*******************************************************************************
#  barplot forecasted values (individual ages)
#
#*******************************************************************************

n3$fits <- n3$avgthree.model.fits

n3$pointforecasts <- n3$point.forecast.avgthree(n3$datalist, n3$avgthree.model.fits)

n3$barplot.forecasted.values.individual.ages.avgthree(n3$fits,n3$pointforecasts,i=1)


#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************

n3$results <- n3$results.total.age.retro.predictive.performance.avgthree

n3$pointforecasts <- n3$point.forecast.avgthree(n3$datalist, n3$avgthree.model.fits)

n3$barplot.forecasted.values.total.age.avgthree(n3$results, n3$pointforecasts)


#*******************************************************************************
#
# Gary's Plot for Individual Ages
#
#*******************************************************************************

n3$results.retro <- n3$results.individual.ages.retro.predictive.performance.avgthree
names(n3$results.retro)

n3$results.pred <- n3$pred.int.individual.ages.avgthree

## par(mfrow=c(1,1))
## j <- 1

n3$gary.plot.individual.ages(n3$results.retro, n3$results.pred, j)


#*******************************************************************************
#
# Gary's Plot for "Total Age"
#
#*******************************************************************************

n3$results.retro <- n3$results.total.age.retro.predictive.performance.avgthree
names(n3$results.retro)
n3$results.pred <- n3$PI.total.age.avgthree.no.comma

n3$gary.plot.total.age(n3$results.retro, n3$results.pred)



###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (individual ages) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

n3$fits <- n3$avgthree.model.fits
n3$pointforecasts <- n3$point.forecast.avgthree(n3$datalist, n3$avgthree.model.fits)
n3$intervalforecasts <-   n3$PI.individual.ages.avgthree.no.comma

## i <- 1
## scatterplot.forecasted.values.and.forecast.intervals.individual.ages.avgthree(fits, pointforecasts, intervalforecasts,i)

#---- plot forecasted values & forecast intervals:  scatterplot (total age) ----------------------------------------

# ----------------------------------------------------------------------------------------------------------------

n3$results <- n3$results.total.age.retro.predictive.performance.avgthree

n3$pointforecasts <- n3$point.forecast.avgthree(n3$datalist, n3$avgthree.model.fits)

n3$intervalforecasts <-  n3$PI.total.age.avgthree.no.comma


n3$scatterplot.forecasted.values.and.forecast.intervals.total.age.avgthree(
     n3$results,
     n3$pointforecasts,
     n3$intervalforecasts)


##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - individual ages
#
##########################################################################################

n3$fits <- n3$avgthree.model.fits
n3$results <- n3$results.individual.ages.retro.predictive.performance.avgthree

windows()
n3$bias.coefficients.afe.individual.ages.retro.avgthree(n3$avgthree.model.fits,
                                                     n3$results.individual.ages.retro.predictive.performance.avgthree,
                                                     n3$stockabundance)

n3$bias.coeff.afe.individual.ages.retro.avgthree

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################
n3$results <- n3$results.total.age.retro.predictive.performance.avgthree

windows()
n3$bias.coefficient.afe.total.age.retro.avgthree(n3$results.total.age.retro.predictive.performance.avgthree,
                                                 n3$stockabundance)

n3$bias.coeff.afe.total.age.retro.avgthree
