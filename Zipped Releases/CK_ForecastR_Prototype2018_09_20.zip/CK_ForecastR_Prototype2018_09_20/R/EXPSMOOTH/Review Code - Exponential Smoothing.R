source("R/expsmooth/Review Code - Exponential Smoothing_functions.r")

#######################################################################################################
# Exponential Smoothing - Forecasting Results
# Last Updated:  June 25, 2014
#######################################################################################################

## function for installing and/or loading R packages

## usePackage <- function(p) {
##    if (!is.element(p, installed.packages()[,1]))
##        install.packages(p, dep = TRUE)
##    require(p, character.only = TRUE)
## }


EXPSMOOTH$datafile <- datafile_original

EXPSMOOTH$stockabundance <- EXPSMOOTH$datafile$Stock_Abundance[1]
EXPSMOOTH$stockabundance <- gsub("[[:space:]]", "_", EXPSMOOTH$stockabundance)


EXPSMOOTH$stockname <- EXPSMOOTH$datafile$Stock_Name[1]
EXPSMOOTH$stockspecies <- EXPSMOOTH$datafile$Stock_Species[1]
EXPSMOOTH$forecastingyear <- EXPSMOOTH$datafile$Forecasting_Year[1]


usePackage("stringr")
EXPSMOOTH$forecastingyear <- str_replace_all(EXPSMOOTH$forecastingyear, "\n","")
EXPSMOOTH$forecastingyear <- as.numeric(EXPSMOOTH$forecastingyear)


EXPSMOOTH$datafilesub <- EXPSMOOTH$datafile


## datafile <- data.frame(BY, T2, T3, T4, T5)   # need to come back here to automate the creation of this data frame!!! [January 13, 2014]

EXPSMOOTH$extract_ages <- sort(unique(EXPSMOOTH$datafilesub$Age_Class))
EXPSMOOTH$extract_names <- paste("T",EXPSMOOTH$extract_ages,sep="")
EXPSMOOTH$extract_names <- c("BY",EXPSMOOTH$extract_names)


EXPSMOOTH$tmpsub <- list()
for (i in 1:length(EXPSMOOTH$extract_ages)){
    EXPSMOOTH$tmpsub[[i]] <- subset(EXPSMOOTH$datafilesub, Age_Class==EXPSMOOTH$extract_ages[i])[,c("Brood_Year",paste0("Average","_",EXPSMOOTH$stockabundance))]
}

EXPSMOOTH$list.of.data.frames <- EXPSMOOTH$tmpsub
EXPSMOOTH$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), EXPSMOOTH$list.of.data.frames)

EXPSMOOTH$datafile_new <- EXPSMOOTH$merged.data.frame
names(EXPSMOOTH$datafile_new) <- EXPSMOOTH$extract_names

## datafile <<- datafile_new

EXPSMOOTH$datafile <- EXPSMOOTH$datafile_new

cat("Working data file is: ","\n")
print(EXPSMOOTH$datafile)
cat("\n")


#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for sibling regression ---------------------------------

EXPSMOOTH$datalist <- EXPSMOOTH$datalist.expsmooth(EXPSMOOTH$datafile, EXPSMOOTH$forecastingyear)  # CY refers to the T variable with highest age


#--------- prepare data table for reporting --------------------------------------------------

EXPSMOOTH$datafile.report <-  EXPSMOOTH$datafile

EXPSMOOTH$datafile.report[EXPSMOOTH$datafile.report <0] <- "NA"


#--------- plot data to be used for exponential smoothing modeling (uses ggplot) ---------------------------

# par(mfrow=c(4,1), mar=c(4,5,2,2))

EXPSMOOTH$datalist <- EXPSMOOTH$datalist.expsmooth(EXPSMOOTH$datafile, EXPSMOOTH$forecastingyear)  # CY refers to the T variable with highest age

## plot.data.expsmooth(datalist)



#---------  fit exponential smoothing model -----------------------------------------


EXPSMOOTH$expsmooth.model.fits  <- EXPSMOOTH$expsmooth.model(EXPSMOOTH$datalist, EXPSMOOTH$boxcoxtransform)

EXPSMOOTH$fits <- EXPSMOOTH$expsmooth.model.fits

#---------  Plot fitted exponential smoothing model --------------------------------
# Plot fitted exponential smoothing model (ggplot)
#-------------------------------------------------------------------------------

EXPSMOOTH$fits <- EXPSMOOTH$expsmooth.model.fits
# plot.fitted.expsmooth(fits)

EXPSMOOTH$plot.fitted.expsmooth(EXPSMOOTH$expsmooth.model.fits, EXPSMOOTH$boxcoxtransform)


#-------------------------------------------------------------------------------
# Report Exponential Smoothing Model Results for A Specific Age Class
#-------------------------------------------------------------------------------

## j <- 1
## expsmooth.model.results(fits,j)


#-------------------------------------------------------------------------------
# Model Diagnostics for a Specific Exponential Smoothing Model
#-------------------------------------------------------------------------------

EXPSMOOTH$diagnostics.expsmooth.model.fit(EXPSMOOTH$fits, EXPSMOOTH$boxcoxtransform, i=1)


#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

EXPSMOOTH$point.forecast.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$fits, EXPSMOOTH$boxcoxtransform)


EXPSMOOTH$results.point.forecast.expsmooth <- NULL
for (j in 1:length(EXPSMOOTH$expsmooth.model.fits)){

       EXPSMOOTH$tmp_list <- EXPSMOOTH$point.forecast.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$expsmooth.model.fits, EXPSMOOTH$boxcoxtransform)[[j]]

       # list2 <- unlist(list1)

       # point.pred.asslr <- rbind(point.pred.asslr, list2)

       EXPSMOOTH$tmp_df <- do.call(cbind.data.frame, EXPSMOOTH$tmp_list)

       EXPSMOOTH$results.point.forecast.expsmooth <- rbind(EXPSMOOTH$results.point.forecast.expsmooth, EXPSMOOTH$tmp_df)

}

EXPSMOOTH$results.point.forecast.expsmooth$Model <- as.character(EXPSMOOTH$results.point.forecast.expsmooth$Model)

## results.point.forecast.expsmooth

## str(results.point.forecast.expsmooth)


#--------- retrospective evaluation for each individual age ----------------------------------

EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth  <-
     EXPSMOOTH$individual.ages.retro.predictive.performance.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$boxcoxtransform, EXPSMOOTH$index.year)

EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth

## names(results.individual.ages.retro.predictive.performance.expsmooth)

EXPSMOOTH$expsmooth.individual.ages.retro.plot(EXPSMOOTH$expsmooth.individual.ages.retro.plot.info, EXPSMOOTH$stockabundance, j=1)

### report retrospective performance measures for individual ages in a nicer format

EXPSMOOTH$MIA <- EXPSMOOTH$measures.individual.ages.retro.expsmooth(EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth)

## MIA


##
## Total Age
##


#--------- retrospective evaluation for the total age ----------------------------------------

EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth <-
      EXPSMOOTH$total.age.retro.predictive.performance.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$boxcoxtransform, EXPSMOOTH$index.year)

EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth

## names(results.total.age.retro.predictive.performance.expsmooth)

EXPSMOOTH$expsmooth.total.age.retro.plot(EXPSMOOTH$expsmooth.total.age.retro.plot.info, EXPSMOOTH$stockabundance)


### report retrospective performance measures for total age in a nicer format

EXPSMOOTH$MTA <- EXPSMOOTH$measures.total.age.retro.expsmooth(EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth)

## M <- merge(MIA, MTA, by = intersect(names(MIA), names(MTA)), sort=FALSE)

EXPSMOOTH$M <- merge(EXPSMOOTH$MIA, EXPSMOOTH$MTA, by = c("Measure"), sort=FALSE)

EXPSMOOTH$M <- subset(EXPSMOOTH$M, select=-Model.y)

## M

names(EXPSMOOTH$M)[names(EXPSMOOTH$M)=="Model.x"] <- "Model"

## M

EXPSMOOTH$M.expsmooth <- EXPSMOOTH$M


### report actual, forecasted and error values for total age in a nicer format

EXPSMOOTH$results.afe.total.age.retro.expsmooth <-
 EXPSMOOTH$afe.total.age.retro.expsmooth(EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth)

## results.afe.total.age.retro.expsmooth


usePackage("scales")
cbind(EXPSMOOTH$results.afe.total.age.retro.expsmooth[,1],
      comma(round(EXPSMOOTH$results.afe.total.age.retro.expsmooth[,"Actual"])),
      comma(round(EXPSMOOTH$results.afe.total.age.retro.expsmooth[,"Forecast"])),
      comma(round(EXPSMOOTH$results.afe.total.age.retro.expsmooth[,"Error"]))
)

#---- meboot2 function for bootstrapping positive time series ----------------------------------------

# fit <- expsmooth.model.fits[[1]]

## EXPSMOOTH$fit <- EXPSMOOTH$expsmooth.model.fits[[1]]
## EXPSMOOTH$debug <- EXPSMOOTH$forecast.expsmooth.modified.meboot(EXPSMOOTH$fit,  EXPSMOOTH$boxcoxtransform, level=80, npaths=EXPSMOOTH$B)


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

## EXPSMOOTH$fit <- EXPSMOOTH$expsmooth.model.fits[[1]]
## EXPSMOOTH$debug <- EXPSMOOTH$forecast.expsmooth.modified.stlboot(EXPSMOOTH$fit,  EXPSMOOTH$boxcoxtransform, level=80, npaths=EXPSMOOTH$B)

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

EXPSMOOTH$fits <- EXPSMOOTH$expsmooth.model.fits
EXPSMOOTH$pred.int.individual.ages.expsmooth <- EXPSMOOTH$prediction.intervals.individual.ages.expsmooth(EXPSMOOTH$expsmooth.model.fits, EXPSMOOTH$boxcoxtransform, EXPSMOOTH$bootmethod, level=80, npaths=EXPSMOOTH$B)

## pred.int.individual.ages.expsmooth

## pred.int.individual.ages.expsmooth

#----------------------------------------------------------------------------

EXPSMOOTH$PI.ctr <- NULL
EXPSMOOTH$PI.lwr <- NULL
EXPSMOOTH$PI.upr <- NULL
# PI.med <- NULL
EXPSMOOTH$PI.sim <- NULL
EXPSMOOTH$nms <- NULL

for (k in 1:length(EXPSMOOTH$pred.int.individual.ages.expsmooth)){

     EXPSMOOTH$PI.ctr <- c(EXPSMOOTH$PI.ctr,
                 EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$PI.ctr)

     EXPSMOOTH$PI.lwr <- c(EXPSMOOTH$PI.lwr,
                 EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$PI.lwr)

     EXPSMOOTH$PI.upr <- c(EXPSMOOTH$PI.upr,
                 EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$PI.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.expsmooth[[k]]$PI.median)

     EXPSMOOTH$PI.sim <- cbind(EXPSMOOTH$PI.sim, EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$sim)

     EXPSMOOTH$nms <- c(EXPSMOOTH$nms, EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$age)

}

colnames(EXPSMOOTH$PI.sim) <- EXPSMOOTH$nms


EXPSMOOTH$PI.lwr[EXPSMOOTH$PI.lwr < 0] <- 0
EXPSMOOTH$PI.upr[EXPSMOOTH$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

EXPSMOOTH$PI.ctr <- round(EXPSMOOTH$PI.ctr)
EXPSMOOTH$PI.lwr <- round(EXPSMOOTH$PI.lwr)
EXPSMOOTH$PI.upr <- round(EXPSMOOTH$PI.upr)
## PI.med <- round(PI.med)

## PI.individual.ages.expsmooth <- data.frame(PI.ctr=PI.ctr, PI.med=PI.med, PI.lwr=PI.lwr, PI.upr=PI.upr)

EXPSMOOTH$PI.individual.ages.expsmooth <- data.frame(PI.ctr=EXPSMOOTH$PI.ctr, PI.lwr=EXPSMOOTH$PI.lwr, PI.upr=EXPSMOOTH$PI.upr)

## PI.individual.ages.expsmooth.no.comma <- data.frame(PI.ctr=PI.ctr, PI.med=PI.med, PI.lwr=PI.lwr, PI.upr=PI.upr)

EXPSMOOTH$PI.individual.ages.expsmooth.no.comma <- data.frame(PI.ctr=EXPSMOOTH$PI.ctr, PI.lwr=EXPSMOOTH$PI.lwr, PI.upr=EXPSMOOTH$PI.upr)


## PI.individual.ages.expsmooth

usePackage("scales")

EXPSMOOTH$PI.individual.ages.expsmooth <- comma(EXPSMOOTH$PI.individual.ages.expsmooth)

## PI.individual.ages.expsmooth

EXPSMOOTH$PI.individual.ages.expsmooth.sim <- EXPSMOOTH$PI.sim


##########################################################################################
#
# Plot distribution of bootstrapped point forecasts - individual ages
#
##########################################################################################

## plot.distribution.bootstrapped.point.forecasts.individual.ages.expsmooth(PI.individual.ages.expsmooth.sim,
##                                                                          PI.individual.ages.expsmooth.no.comma,
##                                                                         expsmooth.model.fits, boxcoxtransform,
##                                                                         extract_ages,
##                                                                         stockabundance)


############################################################################################
#*******************************************************************************************
#
#------------ compute prediction interval for point forecast of total age       -----------
#
#*******************************************************************************************

EXPSMOOTH$expsmooth.sim.total.age <- NULL
EXPSMOOTH$nms <- NULL
EXPSMOOTH$expsmooth.PI.ctr.total.age <- 0
for (k in 1:length(EXPSMOOTH$pred.int.individual.ages.expsmooth)){
     EXPSMOOTH$expsmooth.sim.total.age <- cbind(EXPSMOOTH$expsmooth.sim.total.age, EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$sim)
     EXPSMOOTH$nms <- c(EXPSMOOTH$nms, EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$age)
     EXPSMOOTH$expsmooth.PI.ctr.total.age <- EXPSMOOTH$expsmooth.PI.ctr.total.age + EXPSMOOTH$pred.int.individual.ages.expsmooth[[k]]$PI.ctr
}

colnames(EXPSMOOTH$expsmooth.sim.total.age) <- EXPSMOOTH$nms

EXPSMOOTH$PI.total.age.expsmooth <- NULL

EXPSMOOTH$sim <- apply(EXPSMOOTH$expsmooth.sim.total.age, 1, sum)

EXPSMOOTH$PI.total.age.expsmooth$PI.ctr <- EXPSMOOTH$expsmooth.PI.ctr.total.age
## PI.total.age.expsmooth$PI.med <- quantile(sim, 0.500)
EXPSMOOTH$PI.total.age.expsmooth$PI.lwr <- quantile(EXPSMOOTH$sim, 0.10)  # need to automate this!
EXPSMOOTH$PI.total.age.expsmooth$PI.upr <- quantile(EXPSMOOTH$sim, 0.90)  # need to automate this!

# PI.total.age.arima <- unlist(PI.total.age.arima)

EXPSMOOTH$PI.total.age.expsmooth <- data.frame(EXPSMOOTH$PI.total.age.expsmooth)

## names(PI.total.age.expsmooth) <- c("PI.ctr","PI.med","PI.lwr","PI.upr")
names(EXPSMOOTH$PI.total.age.expsmooth) <- c("PI.ctr","PI.lwr","PI.upr")

## PI.total.age.expsmooth

rownames(EXPSMOOTH$PI.total.age.expsmooth) <- NULL

## PI.total.age.expsmooth

# hist(sim)

#-----------------------------------------------------------------------------------------------


EXPSMOOTH$PI.total.age.expsmooth$PI.lwr[EXPSMOOTH$PI.total.age.expsmooth$PI.lwr < 0] <- 0
EXPSMOOTH$PI.total.age.expsmooth$PI.upr[EXPSMOOTH$PI.total.age.expsmooth$PI.upr < 0] <- 0
## PI.total.age.expsmooth$PI.med[PI.total.age.expsmooth$PI.med < 0] <- 0

EXPSMOOTH$PI.total.age.expsmooth$PI.ctr <- round(EXPSMOOTH$PI.total.age.expsmooth$PI.ctr)
EXPSMOOTH$PI.total.age.expsmooth$PI.lwr <- round(EXPSMOOTH$PI.total.age.expsmooth$PI.lwr)
EXPSMOOTH$PI.total.age.expsmooth$PI.upr <- round(EXPSMOOTH$PI.total.age.expsmooth$PI.upr)
## PI.total.age.expsmooth$PI.med <- round(PI.total.age.expsmooth$PI.med)

usePackage("scales")

EXPSMOOTH$PI.total.age.expsmooth.no.comma <- EXPSMOOTH$PI.total.age.expsmooth

EXPSMOOTH$PI.total.age.expsmooth$PI.ctr <- comma(EXPSMOOTH$PI.total.age.expsmooth$PI.ctr)

EXPSMOOTH$PI.total.age.expsmooth$PI.lwr <- comma(EXPSMOOTH$PI.total.age.expsmooth$PI.lwr)

EXPSMOOTH$PI.total.age.expsmooth$PI.upr <- comma(EXPSMOOTH$PI.total.age.expsmooth$PI.upr)

## PI.total.age.expsmooth$PI.med <- comma(PI.total.age.expsmooth$PI.med)

## PI.total.age.expsmooth

EXPSMOOTH$PI.total.age.expsmooth.sim <- EXPSMOOTH$sim



##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - total age
#
##########################################################################################

## plot.distribution.bootstrapped.point.forecasts.total.age.expsmooth(PI.total.age.expsmooth.sim,
##                                                               PI.total.age.expsmooth.no.comma,
##                                                               stockabundance)



#################################################################################
# Continue On From Here - December 10, 2013
#################################################################################


### plot forecast vs. actual (individual ages, expsmooth)

## results <- results.individual.ages.retro.predictive.performance.expsmooth
## scatter.plot.results.afe.individual.ages.retro.expsmooth(
##   results.individual.ages.retro.predictive.performance.expsmooth,
##   stockabundance
## )


#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values (individual ages, arima)
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.expsmooth
## timeseries.plot.results.afe.individual.ages.retro.expsmooth(results, stockabundance)

#*******************************************************************************
# plot forecast vs. actual (total age, asslr)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.expsmooth
## scatter.plot.results.afe.total.age.retro.expsmooth(results, stockabundance)


#*******************************************************************************
# Time series plot of retrospectively forecasted vs. actual abundance (total age, expsmooth)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.expsmooth
## timeseries.plot.results.afe.total.age.retro.expsmooth(results, stockabundance)

##########################################################################################
#
#  Density plots of retrospective forecast errors - individual ages
#
##########################################################################################

## fits <- expsmooth.model.fits

## fits <- expsmooth.model.fits
## results <- results.individual.ages.retro.predictive.performance.expsmooth
## dens.results.afe.individual.ages.retro.expsmooth(expsmooth.model.fits, results.individual.ages.retro.predictive.performance.expsmooth, boxcoxtransform)

#*******************************************************************************
#
# Density plot of retrospective forecast errors (total age)
#
#*******************************************************************************

## results <- results.afe.total.age.retro.expsmooth

## dens.results.afe.total.age.retro.expsmooth(results.afe.total.age.retro.expsmooth)


#*******************************************************************************
#  barplot forecasted values (specific ages)
#
#*******************************************************************************

EXPSMOOTH$fits <- EXPSMOOTH$expsmooth.model.fits
EXPSMOOTH$pointforecasts <- EXPSMOOTH$point.forecast.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$expsmooth.model.fits, EXPSMOOTH$boxcoxtransform)
EXPSMOOTH$barplot.forecasted.values.individual.ages.expsmooth(EXPSMOOTH$fits, EXPSMOOTH$pointforecasts,i=1)


#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************

EXPSMOOTH$results <- EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth
EXPSMOOTH$pointforecasts <- EXPSMOOTH$point.forecast.expsmooth(EXPSMOOTH$datalist, EXPSMOOTH$expsmooth.model.fits, EXPSMOOTH$boxcoxtransform)
EXPSMOOTH$barplot.forecasted.values.total.age.expsmooth(EXPSMOOTH$results, EXPSMOOTH$pointforecasts)


#*******************************************************************************
#
# Gary's Plot for Individual Ages
#
#*******************************************************************************

EXPSMOOTH$results.retro <- EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth
## names(results.retro)

EXPSMOOTH$results.pred <- EXPSMOOTH$pred.int.individual.ages.expsmooth

## par(mfrow=c(1,1))
## j <- 1

EXPSMOOTH$gary.plot.individual.ages(EXPSMOOTH$results.retro, EXPSMOOTH$results.pred, j=1)


#*******************************************************************************
#
# Gary's Plot for "Total Age"
#
#*******************************************************************************

EXPSMOOTH$results.retro <- EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth
## names(results.retro)
EXPSMOOTH$results.pred <- EXPSMOOTH$PI.total.age.expsmooth.no.comma

EXPSMOOTH$gary.plot.total.age(EXPSMOOTH$results.retro, EXPSMOOTH$results.pred)

###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (individual ages) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## fits <- expsmooth.model.fits
## pointforecasts <- point.forecast.expsmooth(datalist, expsmooth.model.fits, boxcoxtransform)
## intervalforecasts <-   PI.individual.ages.expsmooth.no.comma
## i <- 1
## scatterplot.forecasted.values.and.forecast.intervals.individual.ages.expsmooth(fits, pointforecasts, intervalforecasts,i)


#------------------------------------------------------------------------------------------------------------------

#---- plot forecasted values & forecast intervals:  scatterplot (total age) ----------------------------------------

# ----------------------------------------------------------------------------------------------------------------

## results <- results.total.age.retro.predictive.performance.expsmooth
## pointforecasts <- point.forecast.expsmooth(datalist, expsmooth.model.fits, boxcoxtransform)
## intervalforecasts <-  PI.total.age.expsmooth
## scatterplot.forecasted.values.and.forecast.intervals.total.age.expsmooth(results, pointforecasts, intervalforecasts)


#=============================================================================================

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - individual ages
#
##########################################################################################

## fits <- expsmooth.model.fits

EXPSMOOTH$fits <- EXPSMOOTH$expsmooth.model.fits
EXPSMOOTH$results <- EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth

windows()
EXPSMOOTH$bias.coefficients.afe.individual.ages.retro.expsmooth(EXPSMOOTH$expsmooth.model.fits,
                                                       EXPSMOOTH$results.individual.ages.retro.predictive.performance.expsmooth,
                                                        EXPSMOOTH$boxcoxtransform,
                                                        EXPSMOOTH$stockabundance)

EXPSMOOTH$bias.coeff.afe.individual.ages.retro.expsmooth

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################

EXPSMOOTH$results <- EXPSMOOTH$results.total.age.retro.predictive.performance.expsmooth

windows()
EXPSMOOTH$bias.coefficient.afe.total.age.retro.expsmooth(EXPSMOOTH$results,
                                               EXPSMOOTH$stockabundance)

EXPSMOOTH$bias.coeff.afe.total.age.retro.expsmooth
