# keep this file for now, so that can run old scripts
# this function now migrated to 3_HelperFunctions.R

endReport <- function(docx.file="Report.docx"){

    # Produce report
    writeDoc(doc, file = docx.file)

    # Open report
    # browseURL(docx.file)

}
