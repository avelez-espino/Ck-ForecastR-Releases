source("Misc - Simple Log Power Regression_functions.r")
cat("Misc - Simple Log Power Regression.R", "\n\n")

#*******************************************************************************
#  barplot forecasted values (youngest age)
#
#*******************************************************************************

## total.index

## pred.int.individual.ages.avgfive.youngest
## pred.int.individual.ages.arima.youngest
## pred.int.individual.ages.expsmooth.youngest


SIMPLELOGPOWER$barplot.forecasted.values.youngest.age.simplelogpower(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest, SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest, SIMPLELOGPOWER$result.avgfive.youngest, SIMPLELOGPOWER$result.arima.youngest, SIMPLELOGPOWER$result.expsmooth.youngest, SIMPLELOGPOWER$forecastingyear, SIMPLELOGPOWER$total.index.simplelogpower, SIMPLELOGPOWER$stockabundance)


#*******************************************************************************
#  scatterplot of forecasted value with superimposed forecast interval (youngest age)
#
#*******************************************************************************


SIMPLELOGPOWER$scatterplot.forecasted.values.and.forecast.intervals.youngest.age.simplelogpower.regression(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest,SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest, SIMPLELOGPOWER$result.avgfive.youngest, SIMPLELOGPOWER$result.arima.youngest, SIMPLELOGPOWER$result.expsmooth.youngest, SIMPLELOGPOWER$forecastingyear, SIMPLELOGPOWER$total.index.simplelogpower,
 SIMPLELOGPOWER$stockabundance)


#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************


SIMPLELOGPOWER$barplot.forecasted.values.total.age.simplelogpower(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,
                                                              SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest,
                                                              SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest,
                                                              SIMPLELOGPOWER$pred.int.total.age.simple.sibling.regression.all.models,
                                                              SIMPLELOGPOWER$best.fits.simplelogpower,
                                                              SIMPLELOGPOWER$result.avgfive.youngest,
                                                              SIMPLELOGPOWER$result.arima.youngest,
                                                              SIMPLELOGPOWER$result.expsmooth.youngest,
                                                              SIMPLELOGPOWER$forecastingyear,
                                                              SIMPLELOGPOWER$total.index.simplelogpower,
                                                              SIMPLELOGPOWER$stockabundance)






#*******************************************************************************
#  scatterplot of forecasted value with superimposed forecast interval (total age)
#
#*******************************************************************************

SIMPLELOGPOWER$scatterplot.forecasted.values.and.forecast.intervals.total.age.simplelogpower.regression(
                                                              SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,
                                                              SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest,
                                                              SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest,
                                                              SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models,
                                                              SIMPLELOGPOWER$best.fits.simplelogpower,
                                                              SIMPLELOGPOWER$result.avgfive.youngest,
                                                              SIMPLELOGPOWER$result.arima.youngest,
                                                              SIMPLELOGPOWER$result.expsmooth.youngest,
                                                              SIMPLELOGPOWER$forecastingyear,
                                                              SIMPLELOGPOWER$total.index.simplelogpower,
                                                              SIMPLELOGPOWER$stockabundance)


##
## Retro Measures for Youngest Age and Older Ages
##

## need to use this!
## best.rmse.youngest.age

SIMPLELOGPOWER$retro.measures.all.ages.simplelogpower(SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower)

##
## Model Diagnostics for Naive Model (Average of Previous Five Years) for Youngest Age
##

SIMPLELOGPOWER$diagnostics.avgfive.model.fit.youngest.age(SIMPLELOGPOWER$avgfive.model.fit.youngest)

##
## Model Diagnostics for ARIMA Model for Youngest Age
##

SIMPLELOGPOWER$diagnostics.arima.model.fit.youngest.age(SIMPLELOGPOWER$arima.model.fit.youngest)

##
## Model Diagnostics for Exponential Smoothing Model for Youngest Age
##

SIMPLELOGPOWER$diagnostics.expsmooth.model.fit.youngest.age(SIMPLELOGPOWER$expsmooth.model.fit.youngest)

## pred.int.individual.ages.avgfive.youngest
## pred.int.individual.ages.arima.youngest
## pred.int.individual.ages.expsmooth.youngest


###
### Histogram of Bootstrap Predictions: Best Model for Youngest Age
###

SIMPLELOGPOWER$plot.yboot.simplelogpower.regression.youngest.age(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest,
                                                   SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest,
                                                   SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest,
                                                   SIMPLELOGPOWER$total.index.simplelogpower,
                                                   SIMPLELOGPOWER$stockabundance)


###
### Histogram of Bootstrap Predictions: Best Model for Total Age
###

SIMPLELOGPOWER$plot.yboot.simplelogpower.regression.total.age(SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models,
                                                SIMPLELOGPOWER$total.index.simplelogpower, SIMPLELOGPOWER$stockabundance)

#======================================================================================



###
### Histogram of Bootstrap Predictions: Best Fitting Models
###

plot.yboot.simplelogpower.regression.best.fitting.models <- function(best.fits, pred.int.individual.ages.simplelogpower.regression){

    .e = environment()

    y.star.boot.stacked <- NULL
    labels.stacked <- NULL

      for (j in 1:length(pred.int.individual.ages.simplelogpower.regression)){

           y.star.boot.stacked <- c(y.star.boot.stacked, pred.int.individual.ages.simplelogpower.regression[[j]]$y.star.boot)
           mylabel <-  as.character(formula(best.fits[[j]]$model))
           labels.stacked <- c( labels.stacked, rep(mylabel, length(pred.int.individual.ages.simplelogpower.regression[[j]]$y.star.boot)) )

          }

    data.stacked <- data.frame(y.star.boot=y.star.boot.stacked,
                               labels=labels.stacked)

    usePackage("plyr")

    data.stacked <- ddply(data.stacked, c('labels'))
    data.stacked$labels <- as.factor(data.stacked$labels)

    usePackage("ggplot2")
    usePackage("scales")


    d <- data.stacked

    l <- levels(d$labels)

    breaks <- NULL
    for (j in 1:length(best.fits)){
        h <- hist(data.stacked$y.star.boot[data.stacked$labels==levels(data.stacked$labels)[j]],plot=FALSE, breaks = "Freedman-Diaconis")
        ## breaks[[j]] <- h$breaks
        h.tmp <- seq(from=min(h$breaks), to=max(h$breaks), by = unique(diff(h$breaks)))
        breaks[[j]] <- h.tmp
    }

    ## g <- ggplot(d, aes(x=residuals), environment=.e) +
     g <- ggplot(d, aes(x=y.star.boot),environment=.e) +
           mapply(function(d, b) {geom_histogram(data=d, breaks=b, fill="wheat",colour="black")},
            split(d, d$labels), breaks) +
             facet_wrap(~ labels,  scales="free", ncol=1) +
               expand_limits(x=0, y=0) +
                  scale_y_continuous(paste("Frequency"),labels=comma) +
                   scale_x_continuous(paste("Bootstrapped Point Forecasts"),labels=comma)

      g = g + theme_bw() +
          theme(plot.title=element_text(size=12, hjust=0.5),
                axis.title.x=element_text(size=10,vjust=-0.5),
                axis.title.y=element_text(size=10,vjust=1.5),
                axis.text.x=element_text(size=8),
                axis.text.y=element_text(size=8),
                strip.text.x = element_text(size = 8, colour = "black", angle = 0))

     clim <- NULL
     for (j in 1:length(pred.int.individual.ages.simplelogpower.regression)){

        tmp <- pred.int.individual.ages.simplelogpower.regression[[j]]$p
        tmp <- round(tmp)
        clim <- c(clim, tmp)

     }

     dummy2 <- data.frame(z = clim, labels = levels(data.stacked$labels))

     g = g + geom_vline(aes(xintercept = z), data=dummy2, linetype="dashed",col="red", size=1)

     x <- NULL
     xend <- NULL
     y <- NULL
     yend <- NULL
     for (j in 1:length(pred.int.individual.ages.simplelogpower.regression)){
         x <- c(x, max(0,pred.int.individual.ages.simplelogpower.regression[[j]]$p.lwr))
         xend <- c(xend, round(pred.int.individual.ages.simplelogpower.regression[[j]]$p.upr))
         y <- c(y,0)
         yend <- c(yend,0)
     }

     dummy3 <- data.frame(x=x,xend=xend,y=y,yend=yend, labels = levels(data.stacked$labels))
     g = g + geom_segment(aes(x=x,y=y,xend=xend,yend=yend), data=dummy3, linetype="solid",col="blue", size=1)



     return(g)
}#END plot.yboot.simplelogpower.regression.best.fitting.models

SIMPLELOGPOWER$plot.yboot.simplelogpower.regression.best.fitting.models(SIMPLELOGPOWER$best.fits.simplelogpower,
   SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression)

