##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - youngest age
#
##########################################################################################

windows()

SIMPLELOGPOWER$results <- SIMPLELOGPOWER$best.rmse.youngest.age.simplelogpower

SIMPLELOGPOWER$bias.coefficient.afe.youngest.age.retro.simplelogpower(SIMPLELOGPOWER$results, SIMPLELOGPOWER$stockabundance, SIMPLELOGPOWER$index.year)

SIMPLELOGPOWER$bias.coeff.afe.youngest.age.retro.simplelogpower


## results$$retro$resjoin

## rm(results)

SIMPLELOGPOWER$results <- NULL

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - older ages
#
##########################################################################################

SIMPLELOGPOWER$fits <- SIMPLELOGPOWER$results_best_fitting_model_for_each_age_class_simplelogpower  ## fits

SIMPLELOGPOWER$results <- SIMPLELOGPOWER$individual.ages.retro.predictive.performance.simplelogpower.regression.youngest(
                              SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                              SIMPLELOGPOWER$index.year)  # results


windows()
SIMPLELOGPOWER$bias.coefficients.afe.older.ages.retro.simplelogpower(SIMPLELOGPOWER$fits,
                                                     SIMPLELOGPOWER$results,
                                                     SIMPLELOGPOWER$stockabundance)

## rm(fits)
## rm(results)

SIMPLELOGPOWER$fits <- NULL
SIMPLELOGPOWER$results <- NULL

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################

windows()

SIMPLELOGPOWER$results <- SIMPLELOGPOWER$best.rmse.youngest.age

SIMPLELOGPOWER$bias.coefficient.afe.total.age.retro.simplelogpower(SIMPLELOGPOWER$results, SIMPLELOGPOWER$stockabundance)

SIMPLELOGPOWER$bias.coeff.afe.total.age.retro.simplelogpower

SIMPLELOGPOWER$results <- NULL


##########################################################################################
#
# Time series plot of forecasted vs. actual abundance (older ages, simplelogpower)
#
##########################################################################################


#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values of abundance (individual ages, avgfive)
#-----------------------------------------------------------------------------------------


SIMPLELOGPOWER$results <- SIMPLELOGPOWER$best.rmse.youngest.age
SIMPLELOGPOWER$timeseries.plot.results.afe.individual.ages.retro.simplelogpower(SIMPLELOGPOWER$results,
                                                             SIMPLELOGPOWER$stockabundance)

## rm(results)

SIMPLELOGPOWER$results <- NULL

##########################################################################################
#
# Time series plot of forecasted vs. actual abundance (total age, simplelogpower)
#
##########################################################################################

SIMPLELOGPOWER$results <- SIMPLELOGPOWER$best.rmse.youngest.age

SIMPLELOGPOWER$timeseries.plot.results.afe.total.age.retro.simplelogpower(SIMPLELOGPOWER$results, SIMPLELOGPOWER$stockabundance)

## rm(results)

SIMPLELOGPOWER$results <- NULL
