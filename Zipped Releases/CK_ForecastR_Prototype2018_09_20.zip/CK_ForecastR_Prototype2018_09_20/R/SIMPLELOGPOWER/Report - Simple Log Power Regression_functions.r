
table_interval_forecasts <- function(results_best_fitting_model_for_each_age_class_simplelogpower, PI.individual.ages.simplelogpower.regression.no.comma, forecastingyear, stockabundance){
	# Point and Interval Forecasts
	# this function deals only with forecasts produced by best log power regression models for older ages
    point_forecast_results <-
      SIMPLELOGPOWER$point.forecast.best.fitting.model.for.each.age.class.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower,
                                                           forecastingyear, SIMPLELOGPOWER$datafile_variables)

    interval_forecast_results <- PI.individual.ages.simplelogpower.regression.no.comma

    mytable <- matrix(NA, nrow=length(point_forecast_results), ncol=5)  # add a 5th column for interval forecast
    mytable <- as.data.frame(mytable)
    names(mytable)[-1] <- c("Best Model","Forecasting Year","Point Forecast","Interval Forecast")
    names(mytable)[1] <- paste(stockabundance)
    mytable

    for (i in 1:length(point_forecast_results)){

         mytable[i,1] <- names(point_forecast_results)[i]
         mytable[i,"Best Model"] <- point_forecast_results[[i]]$Model
         mytable[i,"Forecasting Year"] <- forecastingyear
         pfcst <- point_forecast_results[[i]]$PointForecast
         pfcst <- ifelse(pfcst>0,pfcst,0)
         pfcst <- round(pfcst)
         usePackage("scales")
         pfcst <- as.character(comma(pfcst))
         mytable[i,"Point Forecast"] <- pfcst
         mytable[i,"Interval Forecast"] <- paste0(comma(interval_forecast_results[i,"PI.lwr"])," - ",comma(interval_forecast_results[i,"PI.upr"]))

    }

    usePackage("stringr")

    for (i in 1:length(point_forecast_results)){
       mytable[i,1] <- str_replace(mytable[i,1], "_", " ")
    }
    mytable

}#END table_interval_forecasts


empirical.probability.yboot.simplelogpower.regression.total.age <- function(pred.int.total.age.simplelogpower.regression.all.models, total.index.simplelogpower, stockabundance){


    if (total.index.simplelogpower==1) {   # naive model for youngest age (average of previous 5 years)

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    if (total.index.simplelogpower==2) {   # arima model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    if (total.index.simplelogpower==3) {   # exponential smoothing model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    ## cumulative probabilities evaluated for the endpoints of equal-sized bins covering the
    ## range of bootstrapped point forecasts

    x <- as.numeric(y.star.boot.stacked)
    ## usePackage("Hmisc")

    x.hist <- hist(x, breaks=20, plot=FALSE)
    x.hist.breaks <- x.hist$breaks

    my.ecdf <- ecdf(x)

    prob.less <- round(my.ecdf(x.hist.breaks),4)

    prob.greater <- round(1 - my.ecdf(x.hist.breaks),4)

    prob.less.percentage <- round(prob.less*100,2)

    prob.greater.percentage <- round(prob.greater*100,2)

    prob.interval.percentage <- c(NA, diff(prob.less.percentage))

    prob.interval.percentage <- round(prob.interval.percentage, 2)

    prob.threshold <- x.hist.breaks

    prob.thresholds <- data.frame(prob.threshold = prob.threshold,
                       prob.less.percentage = prob.less.percentage,
                       prob.greater.percentage = prob.greater.percentage,
                       prob.interval.percentage = prob.interval.percentage)

    prob.thresholds

    ## cumulative probabilities evaluated for the point forecast of total abundance

    prob.less.pfct <- round(my.ecdf(pfct),4)
    prob.greater.pfct <- round(1 - my.ecdf(pfct),4)

    prob.less.percentage.pfct <- round(prob.less.pfct*100,2)

    prob.greater.percentage.pfct <- round(prob.greater.pfct*100,2)

    prob.threshold.pfct <- pfct

    prob.interval.percentage.pfct <- NA

    prob.pfct <-  data.frame(prob.threshold = prob.threshold.pfct,
                             prob.less.percentage = prob.less.percentage.pfct,
                             prob.greater.percentage = prob.greater.percentage.pfct,
                             prob.interval.percentage = prob.interval.percentage.pfct)


    prob.pfct

    probs = list(prob.thresholds=prob.thresholds,
                 prob.point.forecast=prob.pfct)
    probs
}#END empirical.probability.yboot.simplelogpower.regression.total.age


extract.arima <- function(model){

   extract.arima.fit <- model

   sink("arimafit.txt")
   print(extract.arima.fit)
   sink()

   out <- readLines("arimafit.txt")
   usePackage("stringr")
   out.pattern <- str_detect(string=out, pattern="ARIMA")

   out.coefficients <- str_detect(string=out, pattern="Coefficients")
   flag <- sum(out.coefficients)  # flag = 0 means no Coefficients are reported for ARIMA model for youngest age
                                  # flag = 1 means Coefficients are reported for ARIMA model for youngest age

   modelarima <- out[out.pattern==TRUE]
   require(stringr)
   modelarima <- str_trim(modelarima)

   ## flag <- grepl("ARIMA(0,0,0)", modelarima, fixed=TRUE)

   if (flag > 0) { # if Coefficients are reported for ARIMA model for youngest age

      extract.arima.fit.coef.names <- attr(extract.arima.fit$coef,"names")
      extract.arima.fit.coef <- round(extract.arima.fit$coef,4)

      if (!isEmpty(extract.arima.fit$var.coef)) {

          extract.arima.fit.se <- round(sqrt(diag(extract.arima.fit$var.coef)),4)

          ## http://stats.stackexchange.com/questions/8868/how-to-calculate-the-p-value-of-parameters-for-arima-model-in-r

          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.z.statistic <- extract.arima.fit$coef/sqrt(extract.arima.fit$var.coef)
          } else if (length(extract.arima.fit$coef)>1) {
              extract.arima.fit.z.statistic <- extract.arima.fit$coef/sqrt(diag(extract.arima.fit$var.coef))
          }

          extract.arima.fit.p.value <- pnorm(abs(extract.arima.fit.z.statistic), lower.tail=FALSE)*2
          extract.arima.fit.p.value <- round(extract.arima.fit.p.value, 4)

          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.table <- data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef,
                                            extract.arima.fit.se,
                                            round(extract.arima.fit.z.statistic,4),
                                            extract.arima.fit.p.value)
          } else if (length(extract.arima.fit$coef)>1) {
             extract.arima.fit.table <- cbind.data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef,
                                            extract.arima.fit.se,
                                            round(extract.arima.fit.z.statistic,4),
                                            extract.arima.fit.p.value)
          } # end if else if


          rownames(extract.arima.fit.table) <- extract.arima.fit.coef.names
          colnames(extract.arima.fit.table) <- c("Coefficient","Estimate","Standard Error","Z-statistic","P-value")

          extract.arima.fit.aic <- extract.arima.fit$aic
          extract.arima.fit.bic <-  extract.arima.fit$bic
          extract.arima.fit.aicc <-  extract.arima.fit$aicc

          extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
          extract.arima.fit.loglik <- extract.arima.fit$loglik

          return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.table=extract.arima.fit.table,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))


      } # end !isEmpty()


      if (isEmpty(extract.arima.fit$var.coef)) {

          if (length(extract.arima.fit$coef)==1){
              extract.arima.fit.table <- data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef)
          } else if (length(extract.arima.fit$coef)>1) {
             extract.arima.fit.table <- cbind.data.frame(extract.arima.fit.coef.names,
                                            extract.arima.fit.coef)
          } # end if else if


          rownames(extract.arima.fit.table) <- extract.arima.fit.coef.names
          colnames(extract.arima.fit.table) <- c("Coefficient","Estimate")

          extract.arima.fit.aic <- extract.arima.fit$aic
          extract.arima.fit.bic <-  extract.arima.fit$bic
          extract.arima.fit.aicc <-  extract.arima.fit$aicc

          extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
          extract.arima.fit.loglik <- extract.arima.fit$loglik

          return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.table=extract.arima.fit.table,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))

      } # end isEmpty()


    } # end flag > 0

    if (flag==0) {  # if Coefficients are NOT reported for ARIMA model for youngest age

           extract.arima.fit.aic <- extract.arima.fit$aic
           extract.arima.fit.bic <-  extract.arima.fit$bic
           extract.arima.fit.aicc <-  extract.arima.fit$aicc

           extract.arima.fit.sigma2 <- extract.arima.fit$sigma2
           extract.arima.fit.loglik <- extract.arima.fit$loglik

           return(list(extract.arima.fit.model=modelarima,
               extract.arima.fit.aic=extract.arima.fit.aic,
               extract.arima.fit.bic=extract.arima.fit.bic,
               extract.arima.fit.aicc=extract.arima.fit.aicc,
               extract.arima.fit.sigma2=extract.arima.fit.sigma2,
               extract.arima.fit.loglik=extract.arima.fit.loglik))


    } # end flag = 0

}#END extract.arima


table_point_forecasts_simplelogpower <- function(results_best_fitting_model_for_each_age_class_simplelogpower, forecastingyear, stockabundance){

    point_forecast_results <-
      SIMPLELOGPOWER$point.forecast.best.fitting.model.for.each.age.class.simplelogpower(results_best_fitting_model_for_each_age_class_simplelogpower,
                                                           forecastingyear, SIMPLELOGPOWER$datafile_variables)

    mytable <- matrix(NA, nrow=length(point_forecast_results), ncol=4)
    mytable <- as.data.frame(mytable)
    names(mytable)[-1] <- c("Best Model","Forecasting Year","Point Forecast")
    names(mytable)[1] <- paste(stockabundance)
    mytable

    for (i in 1:length(point_forecast_results)){

         mytable[i,1] <- names(point_forecast_results)[i]
         mytable[i,"Best Model"] <- point_forecast_results[[i]]$Model
         mytable[i,"Forecasting Year"] <- forecastingyear
         pfcst <- point_forecast_results[[i]]$PointForecast
         pfcst <- ifelse(pfcst>0,pfcst,0)
         pfcst <- round(pfcst)
         require(scales)
         pfcst <- as.character(comma(pfcst))
         mytable[i,"Point Forecast"] <- pfcst

    }

    usePackage("stringr")

    for (i in 1:length(point_forecast_results)){
       mytable[i,1] <- str_replace(mytable[i,1], "_", " ")
    }
    mytable

}#END table_point_forecasts_simplelogpower



empirical.probability.yboot.simplelogpower.regression.total.age <- function(pred.int.total.age.simplelogpower.regression.all.models, total.index.simplelogpower, stockabundance){


    if (total.index.simplelogpower==1) {   # naive model for youngest age (average of previous 5 years)

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    if (total.index.simplelogpower==2) {   # arima model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    if (total.index.simplelogpower==3) {   # exponential smoothing model for youngest age

        y.star.boot.stacked <- pred.int.total.age.simplelogpower.regression.all.models$sim[[total.index.simplelogpower]]
        mylabel <- paste("Total", stockabundance)
        labels.stacked <-  rep(mylabel, length(y.star.boot.stacked))

        data.stacked <- data.frame(y.star.boot=y.star.boot.stacked, labels=labels.stacked)

        pfct <- pred.int.total.age.simplelogpower.regression.all.models$p[[total.index.simplelogpower]] ## point forecast of total abundance

    }

    ## cumulative probabilities evaluated for the endpoints of equal-sized bins covering the
    ## range of bootstrapped point forecasts

    x <- as.numeric(y.star.boot.stacked)
    ## usePackage("Hmisc")

    x.hist <- hist(x, breaks=20, plot=FALSE)
    x.hist.breaks <- x.hist$breaks

    my.ecdf <- ecdf(x)

    prob.less <- round(my.ecdf(x.hist.breaks),4)

    prob.greater <- round(1 - my.ecdf(x.hist.breaks),4)

    prob.less.percentage <- round(prob.less*100,2)

    prob.greater.percentage <- round(prob.greater*100,2)

    prob.interval.percentage <- c(NA, diff(prob.less.percentage))

    prob.interval.percentage <- round(prob.interval.percentage, 2)

    prob.threshold <- x.hist.breaks

    prob.thresholds <- data.frame(prob.threshold = prob.threshold,
                       prob.less.percentage = prob.less.percentage,
                       prob.greater.percentage = prob.greater.percentage,
                       prob.interval.percentage = prob.interval.percentage)

    prob.thresholds

    ## cumulative probabilities evaluated for the point forecast of total abundance

    prob.less.pfct <- round(my.ecdf(pfct),4)
    prob.greater.pfct <- round(1 - my.ecdf(pfct),4)

    prob.less.percentage.pfct <- round(prob.less.pfct*100,2)

    prob.greater.percentage.pfct <- round(prob.greater.pfct*100,2)

    prob.threshold.pfct <- pfct

    prob.interval.percentage.pfct <- NA

    prob.pfct <-  data.frame(prob.threshold = prob.threshold.pfct,
                             prob.less.percentage = prob.less.percentage.pfct,
                             prob.greater.percentage = prob.greater.percentage.pfct,
                             prob.interval.percentage = prob.interval.percentage.pfct)


    prob.pfct

    probs = list(prob.thresholds=prob.thresholds,
                 prob.point.forecast=prob.pfct)

    probs
}#END empirical.probability.yboot.simplelogpower.regression.total.age


plot_function1 <- function(){
 formula.pairs <- paste(" ~ ", SIMPLELOGPOWER$resp, "+ ", paste(SIMPLELOGPOWER$vars, collapse=" + "))
 formula.pairs <- formula(formula.pairs)
 # pairs(mydata, lower.panel=panel.cor)
 pairs(formula.pairs, lower.panel=SIMPLELOGPOWER$panel.cor, data=SIMPLELOGPOWER$dats)
}#END plot_function1



plot_function2 <- function(){
 formula.1 <- paste(SIMPLELOGPOWER$resp) ## response transformation
 formula.2 <- paste(SIMPLELOGPOWER$vars) ## predictor transformation
 transf.1 <- strsplit(formula.1, "\\(")[[1]][1]
 transf.2 <- strsplit(formula.2, "\\(")[[1]][1]

 if (transf.1=="log") { resp.var <- log(SIMPLELOGPOWER$dats[,3]) }
 if (transf.1=="log1p") { resp.var <- log1p(SIMPLELOGPOWER$dats[,3])}

 if (transf.2=="log") {pred.var <- log(SIMPLELOGPOWER$dats[,5])}
 if (transf.2=="log1p") {pred.var <- log1p(SIMPLELOGPOWER$dats[,5])}

 par(mfrow=c(1,2))
 d2 <- density(pred.var)
 plot(d2, las=1, main=formula.2 )
 polygon(d2, col="lightgrey", border="black")

 d1 <- density(resp.var)
 plot(d1, las=1, main=formula.1)
 polygon(d1, col="grey", border="black")

}#END plot_function2


