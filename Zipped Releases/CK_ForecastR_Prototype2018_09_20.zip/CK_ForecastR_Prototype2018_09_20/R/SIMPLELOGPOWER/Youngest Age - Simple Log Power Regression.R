########################################################################################################
########################################################################################################
#
# Naive Time Series Forecasting (Average of Past 5 Years) - Forecasting Results for Youngest Age
#
########################################################################################################
########################################################################################################
source("R/simplelogpower/Youngest Age - Simple Log Power Regression_functions.r")

cat("Youngest Age - Simple Log Power Regression.R", "\n\n")

## datafile <- read.csv("SPR_thousands.csv", as.is=TRUE)

SIMPLELOGPOWER$datafile_original <- datafile_original

SIMPLELOGPOWER$datafile <- SIMPLELOGPOWER$datafile_original

SIMPLELOGPOWER$datafilesub <- SIMPLELOGPOWER$datafile

SIMPLELOGPOWER$extract_ages <- sort(unique(SIMPLELOGPOWER$datafilesub$Age_Class))
SIMPLELOGPOWER$extract_names <- paste("T",SIMPLELOGPOWER$extract_ages,sep="")
SIMPLELOGPOWER$extract_names <- c("BY",SIMPLELOGPOWER$extract_names)

SIMPLELOGPOWER$tmpsub <- list()
for (i in 1:length(SIMPLELOGPOWER$extract_ages)){
     if (SIMPLELOGPOWER$stockabundance=="Terminal Run"){
     SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Terminal_Run")]
     } else if (SIMPLELOGPOWER$stockabundance=="Escapement") {
      SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Escapement")]
     } else if (SIMPLELOGPOWER$stockabundance=="Production") {
      SIMPLELOGPOWER$tmpsub[[i]] <- subset(SIMPLELOGPOWER$datafilesub, Age_Class==SIMPLELOGPOWER$extract_ages[i])[,c("Brood_Year","Average_Production")]
     }
}

SIMPLELOGPOWER$list.of.data.frames <- SIMPLELOGPOWER$tmpsub
SIMPLELOGPOWER$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), SIMPLELOGPOWER$list.of.data.frames)

SIMPLELOGPOWER$datafile_new <- SIMPLELOGPOWER$merged.data.frame
names(SIMPLELOGPOWER$datafile_new) <- SIMPLELOGPOWER$extract_names

SIMPLELOGPOWER$datafile <- SIMPLELOGPOWER$datafile_new



## cat("Working data file is: ","\n")
## print(datafile)
## cat("\n")


#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for naive forecasting (average of past 5 years) ---------------------------------

SIMPLELOGPOWER$datalist <- datalist.avgfive(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)  # CY refers to the T variable with highest age

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist[[1]] ## retain only the data for the youngest ages

SIMPLELOGPOWER$plot.data.avgfive.youngest(SIMPLELOGPOWER$datalist)


#--------- helper function for computing the average of the past 5 years of a time series -----


#---------  fit naive model (average of past 5 years) -----------------------------------------

SIMPLELOGPOWER$avgfive.model.fit.youngest  <- SIMPLELOGPOWER$avgfive.model.youngest(SIMPLELOGPOWER$datalist)

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$avgfive.model.fit.youngest

#---------  Plot naive model (average of past 5 years) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$avgfive.model.fit.youngest
SIMPLELOGPOWER$plot.fitted.avgfive.youngest(SIMPLELOGPOWER$fit)


SIMPLELOGPOWER$point.forecast.avgfive.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$fit)

SIMPLELOGPOWER$tmp_list <- SIMPLELOGPOWER$point.forecast.avgfive.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$avgfive.model.fit.youngest)

SIMPLELOGPOWER$tmp_df <- do.call(cbind.data.frame, SIMPLELOGPOWER$tmp_list)

SIMPLELOGPOWER$results.point.forecast.avgfive.youngest <- SIMPLELOGPOWER$tmp_df

SIMPLELOGPOWER$results.point.forecast.avgfive.youngest$Model <- as.character(SIMPLELOGPOWER$results.point.forecast.avgfive.youngest$Model)

SIMPLELOGPOWER$results.point.forecast.avgfive.youngest

## str(results.point.forecast.avgfive.youngest)


#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## meboot2 bootstrap for a specific age

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$avgfive.model.fit.youngest
SIMPLELOGPOWER$forecast.avgfive.modified.youngest(SIMPLELOGPOWER$fit, level=80, npaths=B)

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$avgfive.model.fit.youngest
SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest <- SIMPLELOGPOWER$prediction.intervals.individual.ages.avgfive.youngest(SIMPLELOGPOWER$fit, level=80, npaths=B)

SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest

## pred.int.individual.ages.avgfive.youngest

## pred.int.individual.ages.avgfive.youngest$PI.ctr
## pred.int.individual.ages.avgfive.youngest$PI.lwr
## pred.int.individual.ages.avgfive.youngest$PI.upr
## pred.int.individual.ages.avgfive.youngest$sim


########################################################################################################
########################################################################################################
#
# ARIMA Forecasting  - Forecasting Results for Youngest Age
#
########################################################################################################
########################################################################################################


#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for sibling regression ---------------------------------

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist.arima(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)  # CY refers to the T variable with highest age

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist[[1]]   # retain only the data for the youngest age

#---------  fit time series ARIMA model -----------------------------------------

SIMPLELOGPOWER$boxcoxtransform <- boxcoxtransform

SIMPLELOGPOWER$arima.model.fit.youngest  <- SIMPLELOGPOWER$arima.model.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$boxcoxtransform)

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$arima.model.fit.youngest

#---------  Plot fitted time series ARIMA model --------------------------------
# Plot fit time series ARIMA model
#-------------------------------------------------------------------------------

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$arima.model.fit.youngest
SIMPLELOGPOWER$plot.fitted.arima.youngest(SIMPLELOGPOWER$fit, SIMPLELOGPOWER$boxcoxtransform)


#-------------------------------------------------------------------------------
# Report ARIMA Model Results for Youngest Age Class
#-------------------------------------------------------------------------------

SIMPLELOGPOWER$arima.model.results.youngest(SIMPLELOGPOWER$fit)

SIMPLELOGPOWER$point.forecast.arima.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$fit)

SIMPLELOGPOWER$tmp_list <- SIMPLELOGPOWER$point.forecast.arima.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$arima.model.fit.youngest)

SIMPLELOGPOWER$tmp_df <- do.call(cbind.data.frame, SIMPLELOGPOWER$tmp_list)

SIMPLELOGPOWER$results.point.forecast.arima.youngest <- SIMPLELOGPOWER$tmp_df


SIMPLELOGPOWER$results.point.forecast.arima.youngest$Model <- as.character(SIMPLELOGPOWER$results.point.forecast.arima.youngest$Model)

## results.point.forecast.arima.youngest

## str(results.point.forecast.arima.youngest)

## SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$arima.model.fits[[1]]
## SIMPLELOGPOWER$debug <- SIMPLELOGPOWER$forecast.arima.modified.stlboot(SIMPLELOGPOWER$fit, SIMPLELOGPOWER$boxcoxtransform, level=80, npaths=B)


## SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$arima.model.fits[[1]]
## SIMPLELOGPOWER$debug <- SIMPLELOGPOWER$forecast.arima.modified.stlboot(SIMPLELOGPOWER$fit,  SIMPLELOGPOWER$boxcoxtransform, level=80, npaths=B)

## ISSUES WITH lower and upper values being too close to each other!

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$arima.model.fit.youngest

## Hard-code prediction interval for youngest age (ARIMA) to use "stlboot", since stlboot had better performance than meboot for our test data sets
SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest <- SIMPLELOGPOWER$prediction.interval.youngest.age.arima(SIMPLELOGPOWER$fit,
                                                              SIMPLELOGPOWER$boxcoxtransform,
                                                              bootmethod="stlboot", level=80, npaths=B)


#------------------------------------------------------------------------------------------
# IGNORE BELOW!!!!
#------------------------------------------------------------------------------------------

########################################################################################################
########################################################################################################
#
# Exponential Smoothing - Forecasting Results for Youngest Age
#
########################################################################################################
########################################################################################################


#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for sibling regression ---------------------------------

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist.expsmooth(SIMPLELOGPOWER$datafile, SIMPLELOGPOWER$forecastingyear)  # CY refers to the T variable with highest age

SIMPLELOGPOWER$datalist <- SIMPLELOGPOWER$datalist[[1]]

#---------  fit exponential smoothing model -----------------------------------------
SIMPLELOGPOWER$expsmooth.model.fit.youngest  <- SIMPLELOGPOWER$expsmooth.model(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$boxcoxtransform)

SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$expsmooth.model.fit.youngest


#---------  Plot fitted exponential smoothing model --------------------------------
# Plot fitted exponential smoothing model (ggplot)
#-----------------------------------------------------------------------------------
SIMPLELOGPOWER$fit <- SIMPLELOGPOWER$expsmooth.model.fit.youngest

SIMPLELOGPOWER$plot.fitted.expsmooth.youngest(SIMPLELOGPOWER$fit, SIMPLELOGPOWER$boxcoxtransform)

#-------------------------------------------------------------------------------
# Report Exponential Smoothing Model Results for A Specific Age Class
#-------------------------------------------------------------------------------

SIMPLELOGPOWER$expsmooth.model.results.youngest(SIMPLELOGPOWER$fit)

## point.forecast.expsmooth.youngest(datalist, fit)

SIMPLELOGPOWER$tmp_list <- SIMPLELOGPOWER$point.forecast.expsmooth.youngest(SIMPLELOGPOWER$datalist, SIMPLELOGPOWER$expsmooth.model.fit.youngest)

SIMPLELOGPOWER$tmp_df <- do.call(cbind.data.frame, SIMPLELOGPOWER$tmp_list)

SIMPLELOGPOWER$results.point.forecast.expsmooth.youngest <- SIMPLELOGPOWER$tmp_df

SIMPLELOGPOWER$results.point.forecast.expsmooth.youngest$Model <- as.character(SIMPLELOGPOWER$results.point.forecast.expsmooth.youngest$Model)

SIMPLELOGPOWER$results.point.forecast.expsmooth.youngest

## str(results.point.forecast.expsmooth.youngest)



############################################################################################
#===========================================================================================
#
# meboot bootstrapping for EXPSMOOTH
#
#
#===========================================================================================
############################################################################################

## fit <- expsmooth.model.fit.youngest

## SIMPLELOGPOWER$forecast.expsmooth.modified.meboot(SIMPLELOGPOWER$fit, SIMPLELOGPOWER$boxcoxtransform, level=0.8, npaths=B)


############################################################################################
#===========================================================================================
#
# stlboot bootstrapping for EXPSMOOTH
#
#===========================================================================================
############################################################################################

## fit <- expsmooth.model.fit.youngest

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

# fit <- expsmooth.model.fit.youngest


## Hard code "stlboot" as the bootstrap method of choice for EXPSMOOTH,
## since it worked better than meboot on the test data sets with considered
## for stocks with age


SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest <- SIMPLELOGPOWER$prediction.interval.youngest.age.expsmooth(
                                                 fit = SIMPLELOGPOWER$expsmooth.model.fit.youngest,
                                                 boxcoxtransform = SIMPLELOGPOWER$boxcoxtransform,
                                                 bootmethod = "stlboot",
                                                 level = 80,
                                                 npaths = B)


SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest

## str(pred.int.individual.ages.expsmooth.youngest)


#########################################################################################################################
#########################################################################################################################
#
# Putting it all together to compute the Total Abundance
#
#########################################################################################################################
#########################################################################################################################

SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest

SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest

SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest

SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression

#==========================================================================================================================
#
#==========================================================================================================================

## pred.int.total.age.simple.sibling.regression.all.models

SIMPLELOGPOWER$pred.total.age.avgfive.youngest <- list()
SIMPLELOGPOWER$pred.total.age.avgfive.youngest[[1]] <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$age
SIMPLELOGPOWER$pred.total.age.avgfive.youngest[[2]] <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.ctr
SIMPLELOGPOWER$pred.total.age.avgfive.youngest[[3]] <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.lwr
SIMPLELOGPOWER$pred.total.age.avgfive.youngest[[4]] <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.upr
SIMPLELOGPOWER$pred.total.age.avgfive.youngest[[5]] <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$sim
names(SIMPLELOGPOWER$pred.total.age.avgfive.youngest) <- c("age","p","pi.lwr","pi.upr","sim")

SIMPLELOGPOWER$pred.total.age.arima.youngest <- list()
SIMPLELOGPOWER$pred.total.age.arima.youngest[[1]] <- SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$age
SIMPLELOGPOWER$pred.total.age.arima.youngest[[2]] <- SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.ctr
SIMPLELOGPOWER$pred.total.age.arima.youngest[[3]] <- SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.lwr
SIMPLELOGPOWER$pred.total.age.arima.youngest[[4]] <- SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.upr
SIMPLELOGPOWER$pred.total.age.arima.youngest[[5]] <- SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$sim
names(SIMPLELOGPOWER$pred.total.age.arima.youngest) <- c("age","p","pi.lwr","pi.upr","sim")

SIMPLELOGPOWER$pred.total.age.expsmooth.youngest <- list()
SIMPLELOGPOWER$pred.total.age.expsmooth.youngest[[1]] <- SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$age
SIMPLELOGPOWER$pred.total.age.expsmooth.youngest[[2]] <- SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.ctr
SIMPLELOGPOWER$pred.total.age.expsmooth.youngest[[3]] <- SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.lwr
SIMPLELOGPOWER$pred.total.age.expsmooth.youngest[[4]] <- SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.upr
SIMPLELOGPOWER$pred.total.age.expsmooth.youngest[[5]] <- SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$sim
names(SIMPLELOGPOWER$pred.total.age.expsmooth.youngest) <- c("age","p","pi.lwr","pi.upr","sim")


## str(pred.int.individual.ages.simple.sibling.regression[[1]])

SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models <- list()

## youngest age

SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models$age <- SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$age

## point forecasts for total abundance

SIMPLELOGPOWER$p.total.age.avgfive.youngest.plus.oldest <-  round(SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$PI.ctr) +
                                 sum(unlist(lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                     function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                  # as produced by simple sibling regression,
                                                                  # and sum them up

SIMPLELOGPOWER$p.total.age.arima.youngest.plus.oldest  <-  round(SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$PI.ctr) +
                                 sum(unlist(lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                     function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                  # as produced by simple sibling regression,
                                                                  # and sum them up

SIMPLELOGPOWER$p.total.age.expsmooth.youngest.plus.oldest  <-  round(SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$PI.ctr) +
                                     sum(unlist(lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                         function(xl) round(xl$p))))  # extract point predictions for older ages,
                                                                      # as produced by simple sibling regression,
                                                                      # and sum them up


SIMPLELOGPOWER$p.list <- list(avgfive = SIMPLELOGPOWER$p.total.age.avgfive.youngest.plus.oldest ,
               arima = SIMPLELOGPOWER$p.total.age.arima.youngest.plus.oldest ,
               expsmooth = SIMPLELOGPOWER$p.total.age.expsmooth.youngest.plus.oldest)


SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models$p <- SIMPLELOGPOWER$p.list


## simulated values from bootstrap for avgfive

SIMPLELOGPOWER$sim.total.age.avgfive.oldest <- lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                              function(xl) xl$y.star.boot)
SIMPLELOGPOWER$sim.total.age.avgfive.oldest <- Reduce("+", SIMPLELOGPOWER$sim.total.age.avgfive.oldest)

SIMPLELOGPOWER$sim.total.age.avgfive.youngest.plus.oldest <-  SIMPLELOGPOWER$pred.int.individual.ages.avgfive.youngest$sim + SIMPLELOGPOWER$sim.total.age.avgfive.oldest

## simulated values from bootstrap for arima

SIMPLELOGPOWER$sim.total.age.arima.oldest <- lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                              function(xl) xl$y.star.boot)
SIMPLELOGPOWER$sim.total.age.arima.oldest <- Reduce("+", SIMPLELOGPOWER$sim.total.age.arima.oldest)

SIMPLELOGPOWER$sim.total.age.arima.youngest.plus.oldest <-  SIMPLELOGPOWER$pred.int.individual.ages.arima.youngest$sim + SIMPLELOGPOWER$sim.total.age.arima.oldest

## simulated values from bootstrap for exponential smoothing

SIMPLELOGPOWER$sim.total.age.expsmooth.oldest <- lapply(SIMPLELOGPOWER$pred.int.individual.ages.simplelogpower.regression,
                                              function(xl) xl$y.star.boot)
SIMPLELOGPOWER$sim.total.age.expsmooth.oldest <- Reduce("+", SIMPLELOGPOWER$sim.total.age.expsmooth.oldest)

SIMPLELOGPOWER$sim.total.age.expsmooth.youngest.plus.oldest <-  SIMPLELOGPOWER$pred.int.individual.ages.expsmooth.youngest$sim + SIMPLELOGPOWER$sim.total.age.expsmooth.oldest

SIMPLELOGPOWER$sim.list <- list(avgfive=SIMPLELOGPOWER$sim.total.age.avgfive.youngest.plus.oldest,
                 arima=SIMPLELOGPOWER$sim.total.age.arima.youngest.plus.oldest,
                 expsmooth=SIMPLELOGPOWER$sim.total.age.expsmooth.youngest.plus.oldest)

SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models$sim <- SIMPLELOGPOWER$sim.list


#=======================================================================================================================
# Retrospective Evaluation of Point Forecasts for Total Age
#=======================================================================================================================

level <- 80

## lower.total.age.avgfive <- as.numeric(quantile(sim.total.age.avgfive.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLELOGPOWER$lower.total.age.avgfive <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.avgfive.youngest.plus.oldest, (1-level/100)/2, type = 8))

SIMPLELOGPOWER$lower.total.age.avgfive <- max(0, round(SIMPLELOGPOWER$lower.total.age.avgfive))

## upper.total.age.avgfive <- as.numeric(quantile(sim.total.age.avgfive.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLELOGPOWER$upper.total.age.avgfive <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.avgfive.youngest.plus.oldest, (1-level/100)/2 + level/100, type = 8))
SIMPLELOGPOWER$upper.total.age.avgfive <- round(SIMPLELOGPOWER$upper.total.age.avgfive)

## arima

## lower.total.age.arima <- as.numeric(quantile(sim.total.age.arima.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLELOGPOWER$lower.total.age.arima <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.arima.youngest.plus.oldest, (1-level/100)/2, type = 8))
SIMPLELOGPOWER$lower.total.age.arima <- max(0, round(SIMPLELOGPOWER$lower.total.age.arima))

## upper.total.age.arima <- as.numeric(quantile(sim.total.age.arima.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLELOGPOWER$upper.total.age.arima <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.arima.youngest.plus.oldest, (1 - level/100)/2 + level/100, type = 8))
SIMPLELOGPOWER$upper.total.age.arima <- round(SIMPLELOGPOWER$upper.total.age.arima)

## expsmooth

## lower.total.age.expsmooth <- as.numeric(quantile(sim.total.age.expsmooth.youngest.plus.oldest, 0.5 - level/200, type = 8))
SIMPLELOGPOWER$lower.total.age.expsmooth <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.expsmooth.youngest.plus.oldest, (1 - level/100)/2, type = 8))
SIMPLELOGPOWER$lower.total.age.expsmooth <- max(0, round(SIMPLELOGPOWER$lower.total.age.expsmooth))

## upper.total.age.expsmooth <- as.numeric(quantile(sim.total.age.expsmooth.youngest.plus.oldest, 0.5 + level/200, type = 8))
SIMPLELOGPOWER$upper.total.age.expsmooth <- as.numeric(quantile(SIMPLELOGPOWER$sim.total.age.expsmooth.youngest.plus.oldest, (1 - level/100)/2 + level/100, type = 8))
SIMPLELOGPOWER$upper.total.age.expsmooth <- round(SIMPLELOGPOWER$upper.total.age.expsmooth)

## add prediction intervals to pred.int.total.age.simple.sibling.regression.all.models

SIMPLELOGPOWER$lower.list <- list(avgfive=SIMPLELOGPOWER$lower.total.age.avgfive,
                   arima=SIMPLELOGPOWER$lower.total.age.arima,
                   expsmooth=SIMPLELOGPOWER$lower.total.age.expsmooth)

SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models$p.lwr <- SIMPLELOGPOWER$lower.list


SIMPLELOGPOWER$upper.list <- list(avgfive=SIMPLELOGPOWER$upper.total.age.avgfive,
                   arima=SIMPLELOGPOWER$upper.total.age.arima,
                   expsmooth=SIMPLELOGPOWER$upper.total.age.expsmooth)

SIMPLELOGPOWER$pred.int.total.age.simplelogpower.regression.all.models$p.upr <- SIMPLELOGPOWER$upper.list


###
###  Plot fitted values for the youngest age: avgfive, arima and expsmooth
###

SIMPLELOGPOWER$plot.fitted.value.youngest(SIMPLELOGPOWER$avgfive.model.fit.youngest,
                                          SIMPLELOGPOWER$arima.model.fit.youngest,
                                          SIMPLELOGPOWER$expsmooth.model.fit.youngest,
                                          SIMPLELOGPOWER$boxcoxtransform)

