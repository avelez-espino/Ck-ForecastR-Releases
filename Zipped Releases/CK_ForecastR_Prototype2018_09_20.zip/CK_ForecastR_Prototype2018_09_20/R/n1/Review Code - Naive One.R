# original version -> problem b/c path differs for local GUI vs. Server vs. Command Line
#source("../R/n1/Review Code - Naive One_functions.r")

# tried doing this below in 2_MainFunctionCall.R, but the read-in functions don't get here
#source(paste(path.Rfolder,"n1/Review Code - Naive One_functions.r",sep="/"))

# Tried to source from here, but this is not working, because path.Rfolder seems to not get all the way here from the umbrella function
# source(paste(path.Rfolder,"n1/Review Code - Naive One_functions.r",sep="/"))

# Now reading in all the functions in the main fn call, 
# and just copying the relevant ones into the environment here.
# eventually this will all go away, but need it for now to keep the old reports running

# Prepare the data
n1$datalist.naiveone <- datalist.naiveone 


# Fit the Model
n1$naiveone.model <- naiveone.model
n1$point.forecast.naiveone <- point.forecast.naiveone

# Bootstrap Intervals
n1$forecast.naiveone.modified.meboot <- forecast.naiveone.modified.meboot
n1$forecast.naiveone.modified.stlboot <- forecast.naiveone.modified.stlboot
n1$prediction.intervals.individual.ages.naiveone <-  prediction.intervals.individual.ages.naiveone

# Retrospective Tests
n1$individual.ages.retro.predictive.performance.naiveone <- individual.ages.retro.predictive.performance.naiveone
n1$total.age.retro.predictive.performance.naiveone <- total.age.retro.predictive.performance.naiveone 

# Diagnostics/Plots - Data
n1$plot.data.naiveone <- plot.data.naiveone

# Diagnostics/Plots - Fits
n1$plot.fitted.naiveone <- plot.fitted.naiveone
n1$diagnostics.naiveone.model.fit <- diagnostics.naiveone.model.fit
n1$barplot.forecasted.values.individual.ages.naiveone <- barplot.forecasted.values.individual.ages.naiveone
n1$barplot.forecasted.values.total.age.naiveone <-  barplot.forecasted.values.total.age.naiveone
n1$scatterplot.forecasted.values.and.forecast.intervals.individual.ages.naiveone <-  scatterplot.forecasted.values.and.forecast.intervals.individual.ages.naiveone
n1$scatterplot.forecasted.values.and.forecast.intervals.total.age.naiveone <-  scatterplot.forecasted.values.and.forecast.intervals.total.age.naiveone

n1$scatter.plot.results.afe.total.age.retro.naiveone <- scatter.plot.results.afe.total.age.retro.naiveone

# Diagnostics/Plots - Bootstrap
n1$plot.distribution.bootstrapped.point.forecasts.individual.ages.naiveone <- plot.distribution.bootstrapped.point.forecasts.individual.ages.naiveone
n1$plot.distribution.bootstrapped.point.forecasts.total.age.naiveone <- plot.distribution.bootstrapped.point.forecasts.total.age.naiveone 

# Diagnostics/Plots - Retro
n1$measures.individual.ages.retro.naiveone <- measures.individual.ages.retro.naiveone
n1$measures.total.age.retro.naiveone <- measures.total.age.retro.naiveone 
n1$afe.total.age.retro.naiveone <- afe.total.age.retro.naiveone
n1$scatter.plot.results.afe.individual.ages.retro.naiveone <- scatter.plot.results.afe.individual.ages.retro.naiveone
n1$dens.results.afe.individual.ages.retro.naiveone <- dens.results.afe.individual.ages.retro.naiveone
n1$dens.results.afe.total.age.retro.naiveone <- dens.results.afe.total.age.retro.naiveone
n1$timeseries.plot.results.afe.individual.ages.retro.naiveone <- timeseries.plot.results.afe.individual.ages.retro.naiveone 
n1$timeseries.plot.results.afe.total.age.retro.naiveone <- timeseries.plot.results.afe.total.age.retro.naiveone
n1$bias.coefficient.afe.total.age.retro.naiveone <- bias.coefficient.afe.total.age.retro.naiveone 
n1$bias.coefficients.afe.individual.ages.retro.naiveone <- bias.coefficients.afe.individual.ages.retro.naiveone
n1$individual.ages.retro.plot.naiveone <- individual.ages.retro.plot.naiveone 
n1$total.age.retro.plot.naiveone <- total.age.retro.plot.naiveone 
n1$gary.plot.individual.ages <- gary.plot.individual.ages 
n1$gary.plot.total.age <- gary.plot.total.age






########################################################################################################
# Naive Time Series Forecasting (Last Year) - Prediction Results
########################################################################################################

##########################################################################################################

n1$datafile <- datafile_original

n1$datafilesub <- n1$datafile

n1$stockabundance <- n1$datafile$Stock_Abundance[1]

n1$stockabundance <- gsub("[[:space:]]", "_", n1$stockabundance)

n1$stockname <- n1$datafile$Stock_Name[1]
n1$stockspecies <- n1$datafile$Stock_Species[1]
n1$forecastingyear <- n1$datafile$Forecasting_Year[1]

usePackage("stringr")

n1$forecastingyear <- str_replace_all(n1$forecastingyear, "\n","")
n1$forecastingyear <- as.numeric(n1$forecastingyear)

#######################################################################################################




n1$extract_ages <- sort(unique(n1$datafilesub$Age_Class))
n1$extract_names <- paste("T",n1$extract_ages,sep="")
n1$extract_names <- c("BY",n1$extract_names)

n1$tmpsub <- list()
for (i in 1:length(n1$extract_ages)){
    n1$tmpsub[[i]] <- subset(n1$datafilesub, Age_Class==n1$extract_ages[i])[,c("Brood_Year",paste0("Average","_",n1$stockabundance))]
}


n1$list.of.data.frames <- n1$tmpsub
n1$merged.data.frame = Reduce(function(...) merge(...,by="Brood_Year", all=T), n1$list.of.data.frames)

n1$datafile_new <- n1$merged.data.frame
names(n1$datafile_new) <- n1$extract_names



## n1$datafile <- n1$datafile_new

n1$datafile <- n1$datafile_new

#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for sibling regression ---------------------------------




n1$datalist <- n1$datalist.naiveone(n1$datafile, n1$forecastingyear)  # CY refers to the T variable with highest age
					#OLD version n1$datalist.naiveone(n1$datafile, n1$forecastingyear)  # CY refers to the T variable with highest age


#--------- prepare data table for reporting --------------------------------------------------

n1$datafile.report <-  n1$datafile

n1$datafile.report[n1$datafile.report <0] <- "NA"



#--------- plot data to be used for naive forecasting (last year) (uses ggplot) ---------------------------

n1$plot.data.naiveone(n1$datalist)

#---------  fit naive model (last year) -----------------------------------------

n1$naiveone.model.fits  <- n1$naiveone.model(n1$datalist)

n1$fits <- n1$naiveone.model.fits

#---------  Plot fitted exponential smoothing model --------------------------------
# Plot fitted exponential smoothing model (ggplot)
#-------------------------------------------------------------------------------

n1$fits <- n1$naiveone.model.fits
n1$plot.fitted.naiveone(n1$fits)



#-------------------------------------------------------------------------------
# Model Diagnostics for Age-Specific Naive Time Series Model
#-------------------------------------------------------------------------------

## n1$fits <- n1$naiveone.model.fits
# TEMPORARY BYPASS FOR DEBUGGING (turn on/off the line below)
n1$diagnostics.naiveone.model.fit(n1$naiveone.model.fits,i)

n1$point.forecast.naiveone(n1$datalist, n1$fits)


n1$results.point.forecast.naiveone <- NULL
for (j in 1:length(n1$naiveone.model.fits)){

       n1$tmp_list <- n1$point.forecast.naiveone(n1$datalist, n1$naiveone.model.fits)[[j]]

       # list2 <- unlist(list1)

       # point.pred.asslr <- rbind(point.pred.asslr, list2)

       n1$tmp_df <- do.call(cbind.data.frame, n1$tmp_list)

       n1$results.point.forecast.naiveone <- rbind(n1$results.point.forecast.naiveone, n1$tmp_df)

}

n1$results.point.forecast.naiveone$Model <- as.character(n1$results.point.forecast.naiveone$Model)

n1$results.point.forecast.naiveone

## str(results.point.forecast.naiveone)


#--------- retrospective evaluation for each individual age ----------------------------------

n1$results.individual.ages.retro.predictive.performance.naiveone  <-
     n1$individual.ages.retro.predictive.performance.naiveone(n1$datalist, n1$index.year)

#-------------------------------------------------------------------------------

n1$individual.ages.retro.plot.naiveone(n1$individual.ages.retro.plot.info.naiveone, n1$stockabundance, j=1)

## results.individual.ages.retro.predictive.performance.naiveone

## names(results.individual.ages.retro.predictive.performance.naiveone)

n1$MIA <- n1$measures.individual.ages.retro.naiveone(n1$results.individual.ages.retro.predictive.performance.naiveone)

## MIA


##
## Total Age
##


#--------- retrospective evaluation for the total age ----------------------------------------

n1$results.total.age.retro.predictive.performance.naiveone <-
      n1$total.age.retro.predictive.performance.naiveone(n1$datalist, n1$index.year)

n1$results.total.age.retro.predictive.performance.naiveone

names(n1$results.total.age.retro.predictive.performance.naiveone)


n1$total.age.retro.plot.naiveone(n1$total.age.retro.plot.info.naiveone, n1$stockabundance)

### report retrospective performance measures for total age in a nicer format

n1$MTA <- n1$measures.total.age.retro.naiveone(n1$results.total.age.retro.predictive.performance.naiveone)

## M <- merge(MIA, MTA, by = intersect(names(MIA), names(MTA)), sort=FALSE)

n1$M <- merge(n1$MIA, n1$MTA, by = c("Measure"), sort=FALSE)

n1$M <- subset(n1$M, select=-Model.y)

## M

names(n1$M)[names(n1$M)=="Model.x"] <- "Model"

## M

n1$M.naiveone <- n1$M


### report actual, forecasted and error values for total age in a nicer format

n1$results.afe.total.age.retro.naiveone <-
 n1$afe.total.age.retro.naiveone(n1$results.total.age.retro.predictive.performance.naiveone)

## results.afe.total.age.retro.naiveone


## usePackage("scales")
## cbind(results.afe.total.age.retro.naiveone[,1],
##      comma(round(results.afe.total.age.retro.naiveone[,"Actual"])),
##      comma(round(results.afe.total.age.retro.naiveone[,"Forecast"])),
##      comma(round(results.afe.total.age.retro.naiveone[,"Error"]))
## )


#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## fit <- naiveone.model.fits[[1]]
## forecast.naiveone.modified(fit, level=80, npaths=B)

##  forecast.naiveone.modified(naiveone.model.fits[[1]], level=80, npaths=1000)

n1$fits <- n1$naiveone.model.fits
n1$pred.int.individual.ages.naiveone <- n1$prediction.intervals.individual.ages.naiveone(n1$fits, n1$bootmethod, level=80, npaths=n1$B)

n1$pred.int.individual.ages.naiveone


#----------------------------------------------------------------------------

n1$PI.ctr <- NULL
n1$PI.lwr <- NULL
n1$PI.upr <- NULL
# PI.med <- NULL
n1$PI.sim <- NULL
n1$nms <- NULL

for (k in 1:length(n1$pred.int.individual.ages.naiveone)){

     n1$PI.ctr <- c(n1$PI.ctr,
                 n1$pred.int.individual.ages.naiveone[[k]]$PI.ctr)

     n1$PI.lwr <- c(n1$PI.lwr,
                 n1$pred.int.individual.ages.naiveone[[k]]$PI.lwr)

     n1$PI.upr <- c(n1$PI.upr,
                 n1$pred.int.individual.ages.naiveone[[k]]$PI.upr)

     # PI.med <- c(PI.med,
     #            pred.int.individual.ages.expsmooth[[k]]$PI.median)

     n1$PI.sim <- cbind(n1$PI.sim, n1$pred.int.individual.ages.naiveone[[k]]$sim)

     n1$nms <- c(n1$nms, n1$pred.int.individual.ages.naiveone[[k]]$age)

}

colnames(n1$PI.sim) <- n1$nms


n1$PI.lwr[n1$PI.lwr < 0] <- 0
n1$PI.upr[n1$PI.upr < 0] <- 0
## PI.med[PI.med < 0] <- 0

n1$PI.ctr <- round(n1$PI.ctr)
n1$PI.lwr <- round(n1$PI.lwr)
n1$PI.upr <- round(n1$PI.upr)
## PI.med <- round(PI.med)

## PI.individual.ages.naiveone <- data.frame(PI.ctr=PI.ctr, PI.med=PI.med, PI.lwr=PI.lwr, PI.upr=PI.upr)

n1$PI.individual.ages.naiveone <- data.frame(PI.ctr=n1$PI.ctr, PI.lwr=n1$PI.lwr, PI.upr=n1$PI.upr)

## PI.individual.ages.expsmooth.no.comma <- data.frame(PI.ctr=PI.ctr, PI.med=PI.med, PI.lwr=PI.lwr, PI.upr=PI.upr)

n1$PI.individual.ages.naiveone.no.comma <- data.frame(PI.ctr=n1$PI.ctr, PI.lwr=n1$PI.lwr, PI.upr=n1$PI.upr)


## PI.individual.ages.naiveone

usePackage("scales")

n1$PI.individual.ages.naiveone <- comma(n1$PI.individual.ages.naiveone)

## PI.individual.ages.naiveone

n1$PI.individual.ages.naiveone.sim <- n1$PI.sim


##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - individual ages
#
##########################################################################################

n1$plot.distribution.bootstrapped.point.forecasts.individual.ages.naiveone(n1$PI.individual.ages.naiveone.sim,
                                                                     n1$PI.individual.ages.naiveone.no.comma, n1$stockabundance)


############################################################################################
#*******************************************************************************************
#
#------------ compute prediction interval for point forecast of total age       -----------
#
#*******************************************************************************************

n1$naiveone.sim.total.age <- NULL
n1$nms <- NULL
n1$naiveone.PI.ctr.total.age <- 0
for (k in 1:length(n1$pred.int.individual.ages.naiveone)){
     n1$naiveone.sim.total.age <- cbind(n1$naiveone.sim.total.age, n1$pred.int.individual.ages.naiveone[[k]]$sim)
     n1$nms <- c(n1$nms, n1$pred.int.individual.ages.naiveone[[k]]$age)
     n1$naiveone.PI.ctr.total.age <- n1$naiveone.PI.ctr.total.age + n1$pred.int.individual.ages.naiveone[[k]]$PI.ctr
}

colnames(n1$naiveone.sim.total.age) <- n1$nms

n1$PI.total.age.naiveone <- NULL


n1$sim <- apply(n1$naiveone.sim.total.age, 1, sum)

n1$PI.total.age.naiveone$PI.ctr <- n1$naiveone.PI.ctr.total.age
## PI.total.age.expsmooth$PI.med <- quantile(sim, 0.500)
n1$PI.total.age.naiveone$PI.lwr <- quantile(n1$sim, 0.10)  # need to automate this!
n1$PI.total.age.naiveone$PI.upr <- quantile(n1$sim, 0.90)  # need to automate this!

# PI.total.age.arima <- unlist(PI.total.age.arima)

n1$PI.total.age.naiveone <- data.frame(n1$PI.total.age.naiveone)

## names(PI.total.age.naiveone) <- c("PI.ctr","PI.med","PI.lwr","PI.upr")
names(n1$PI.total.age.naiveone) <- c("PI.ctr","PI.lwr","PI.upr")

## PI.total.age.naiveone

rownames(n1$PI.total.age.naiveone) <- NULL

## PI.total.age.naiveone

# hist(sim)

#-----------------------------------------------------------------------------------------------


n1$PI.total.age.naiveone$PI.lwr[n1$PI.total.age.naiveone$PI.lwr < 0] <- 0
n1$PI.total.age.naiveone$PI.upr[n1$PI.total.age.naiveone$PI.upr < 0] <- 0
## PI.total.age.expsmooth$PI.med[PI.total.age.expsmooth$PI.med < 0] <- 0

n1$PI.total.age.naiveone$PI.ctr <- round(n1$PI.total.age.naiveone$PI.ctr)
n1$PI.total.age.naiveone$PI.lwr <- round(n1$PI.total.age.naiveone$PI.lwr)
n1$PI.total.age.naiveone$PI.upr <- round(n1$PI.total.age.naiveone$PI.upr)
## PI.total.age.naiveone$PI.med <- round(PI.total.age.naiveone$PI.med)

usePackage("scales")

n1$PI.total.age.naiveone.no.comma <- n1$PI.total.age.naiveone

n1$PI.total.age.naiveone$PI.ctr <- comma(n1$PI.total.age.naiveone$PI.ctr)

n1$PI.total.age.naiveone$PI.lwr <- comma(n1$PI.total.age.naiveone$PI.lwr)

n1$PI.total.age.naiveone$PI.upr <- comma(n1$PI.total.age.naiveone$PI.upr)

## PI.total.age.naiveone$PI.med <- comma(PI.total.age.naiveone$PI.med)

## PI.total.age.naiveone

n1$PI.total.age.naiveone.sim <- n1$sim

##########################################################################################
#
#  Plot distribution of bootstrapped point forecasts - total age
#
##########################################################################################


###
### Histogram of Bootstrap Predictions
###

n1$plot.distribution.bootstrapped.point.forecasts.total.age.naiveone(n1$PI.total.age.naiveone.sim,
      n1$PI.total.age.naiveone.no.comma, n1$stockabundance)


#################################################################################
# Scatter plot of forecasted vs. actual abundance values(age-specific components)
#################################################################################

## n1$results <- n1$results.individual.ages.retro.predictive.performance.naiveone

n1$scatter.plot.results.afe.individual.ages.retro.naiveone(
     n1$results.individual.ages.retro.predictive.performance.naiveone)


#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values (individual ages, naiveone)
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.naiveone
## timeseries.plot.results.afe.individual.ages.retro.naiveone(results, stockabundance)


n1$timeseries.plot.results.afe.individual.ages.retro.naiveone(
   n1$results.individual.ages.retro.predictive.performance.naiveone,
   n1$stockabundance)

print("flag: starting scatterplot of FC vs actual")

#*******************************************************************************
# Scatter plot of forecasted vs. actual abundance (total age)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.naiveone

n1$scatter.plot.results.afe.total.age.retro.naiveone(n1$results.total.age.retro.predictive.performance.naiveone)


#*******************************************************************************
# Time series plot of forecasted vs. actual abundance (total age)
#
#*******************************************************************************

## results <- results.total.age.retro.predictive.performance.naiveone
## timeseries.plot.results.afe.total.age.retro.naiveone(results, stockabundance)

n1$timeseries.plot.results.afe.total.age.retro.naiveone(
   n1$results.total.age.retro.predictive.performance.naiveone,
   n1$stockabundance)



#*******************************************************************************
# Histogram of Retrospective Forecast Errors - Individual Ages
#*******************************************************************************


###
### Density of Retrospective Forecast Errors: Individual Ages
###

n1$dens.results.afe.individual.ages.retro.naiveone(n1$naiveone.model.fits,
    n1$results.individual.ages.retro.predictive.performance.naiveone)



#*******************************************************************************
#
# Density of retrospective forecast errors (total age)
#
#*******************************************************************************

## results <- results.afe.total.age.retro.naiveone

n1$dens.results.afe.total.age.retro.naiveone(n1$results.afe.total.age.retro.naiveone)

## hist.results.afe.total.age.retro.naiveone(results)

#*******************************************************************************
#  barplot forecasted values (specific ages)
#
#*******************************************************************************

## fits <- naiveone.model.fits

n1$pointforecasts <- n1$point.forecast.naiveone(n1$datalist, n1$naiveone.model.fits)

## barplot.forecasted.values.individual.ages.naiveone(fits, pointforecasts,i)



#*******************************************************************************
#  barplot forecasted values (total age)
#
#*******************************************************************************

n1$results <- n1$results.total.age.retro.predictive.performance.naiveone

n1$pointforecasts <- n1$point.forecast.naiveone(n1$datalist, n1$naiveone.model.fits)

print("adding barplot to env: barplot.forecasted.values.total.age.naiveone")

n1$barplot.forecasted.values.total.age.naiveone(n1$results, n1$pointforecasts)

print("finished adding barplot to env: barplot.forecasted.values.total.age.naiveone")



#*******************************************************************************
#
# Gary's Plot for Individual Ages
#
#*******************************************************************************

n1$results.retro <- n1$results.individual.ages.retro.predictive.performance.naiveone
names(n1$results.retro)

n1$results.pred <- n1$pred.int.individual.ages.naiveone

## par(mfrow=c(1,1))
## j <- 1
## gary.plot.individual.ages(results.retro, results.pred, j)

# bypassing Gary Plot https://github.com/avelez-espino/forecastR_phase4/issues/48
ggplot(data.frame(A=1:5,B=1:5),aes(x=A,y=B))  + geom_text(x=3,y=3,label= "bypassing Gary plot indiv ages") + geom_point(size=2, shape=23)

#n1$gary.plot.individual.ages(n1$results.retro, n1$results.pred, 1)


#*******************************************************************************
#
# Gary's Plot for "Total Age"
#
#*******************************************************************************

n1$results.retro <- n1$results.total.age.retro.predictive.performance.naiveone
names(n1$results.retro)
n1$results.pred <- n1$PI.total.age.naiveone.no.comma

# bypassing Gary Plot https://github.com/avelez-espino/forecastR_phase4/issues/48
ggplot(data.frame(A=1:5,B=1:5),aes(x=A,y=B))  + geom_text(x=3,y=3,label= "bypassing Gary plot total age") + geom_point(size=2, shape=23)

#n1$gary.plot.total.age(n1$results.retro, n1$results.pred)



###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (individual ages) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

n1$fits <- n1$naiveone.model.fits
n1$pointforecasts <- n1$point.forecast.naiveone(n1$datalist, n1$naiveone.model.fits)
n1$intervalforecasts <-   n1$PI.individual.ages.naiveone.no.comma

## i <- 1

n1$scatterplot.forecasted.values.and.forecast.intervals.individual.ages.naiveone(n1$fits, n1$pointforecasts, n1$intervalforecasts,i=1)



#------------------------------------------------------------------------------------------------------------------

#---- plot forecasted values & forecast intervals:  scatterplot (total age) ----------------------------------------

# ----------------------------------------------------------------------------------------------------------------

n1$results <- n1$results.total.age.retro.predictive.performance.naiveone

n1$pointforecasts <- n1$point.forecast.naiveone(n1$datalist, n1$naiveone.model.fits)

n1$intervalforecasts <-  n1$PI.total.age.naiveone.no.comma


n1$scatterplot.forecasted.values.and.forecast.intervals.total.age.naiveone(n1$results, n1$pointforecasts, n1$intervalforecasts)



##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - individual ages
#
##########################################################################################



n1$fits <- n1$naiveone.model.fits
n1$results <- n1$results.individual.ages.retro.predictive.performance.naiveone

windows()
n1$bias.coefficients.afe.individual.ages.retro.naiveone(n1$naiveone.model.fits,
                                                     n1$results.individual.ages.retro.predictive.performance.naiveone,
                                                     n1$stockabundance)

n1$bias.coeff.afe.individual.ages.retro.naiveone

##########################################################################################
#
#  Bias coefficients of retrospective forecast errors - total age
#
##########################################################################################

n1$results <- n1$results.total.age.retro.predictive.performance.naiveone

windows()
n1$bias.coefficient.afe.total.age.retro.naiveone(n1$results.total.age.retro.predictive.performance.naiveone,
                                                 n1$stockabundance)

n1$bias.coeff.afe.total.age.retro.naiveone
