
###
### Histogram of Bootstrap Predictions: Best Model for Stock with No Age Information
###

# pred.int.individual.stock.naiveone.no.age
# pred.int.individual.stock.avgthree.no.age
# pred.int.individual.stock.avgfive.no.age
# pred.int.individual.stock.arima.no.age
# pred.int.individual.stock.expsmooth.no.age

source("R/noage/4. Display Results for Best Forecasting Model_functions.R")

## best.index.no.age <- table.rank.rmse.results.no.age$index.min.avg.rank

best.index.no.age <- table.rank.rmse.results.no.age$index.min.avg.rank

plot.yboot.best.model.no.age(pred.args, best.index.no.age, stockabundance)

#====================================================================================================================
#
# Empirical Probabilities for Stock With No Age Information: Best Model
#
#====================================================================================================================

###
### Empirical Probabilities:  Distribution of Bootstrapped Point Forecasts
###

# pred.int.individual.stock.naiveone.no.age
# pred.int.individual.stock.avgthree.no.age,
# pred.int.individual.stock.avgfive.no.age,
# pred.int.individual.stock.arima.no.age,
# pred.int.individual.stock.expsmooth.no.age

emp.prob.best.model.no.age <- empirical.probability.yboot.best.model.no.age(pred.args, best.index.no.age, stockabundance)

###
### Histogram of Bootstrap Predictions: All Models for Stock with No Age Information
###

# pred.int.individual.stock.naiveone.no.age
# pred.int.individual.stock.avgthree.no.age
# pred.int.individual.stock.avgfive.no.age
# pred.int.individual.stock.arima.no.age
# pred.int.individual.stock.expsmooth.no.age

plot.yboot.all.models.no.age(pred.args, stockabundance)

###
### plot forecast vs. actual: best model (stock without age information)
###

plot.results.afe.individual.stock.retro.best.model.no.age(retro.args, best.index.no.age)

#*******************************************************************************
# Time series plot of retrospectively forecasted vs. actual abundance (total age, expsmooth)
#
#*******************************************************************************

timeseries.plot.results.afe.individual.stock.retro.best.model.no.age(retro.args, best.index.no.age, stockabundance)

## results <- results.total.age.retro.predictive.performance.expsmooth
## timeseries.plot.results.afe.total.age.retro.expsmooth(results, stockabundance)

##===============================================================================================
## Bias Coefficient Plots
##===============================================================================================

windows()
plot.bias.coefficients.retrospective.forecast.errors.individual.stock.best.model.no.age(rmse.results.no.age.args, retro.args, best.index.no.age)
