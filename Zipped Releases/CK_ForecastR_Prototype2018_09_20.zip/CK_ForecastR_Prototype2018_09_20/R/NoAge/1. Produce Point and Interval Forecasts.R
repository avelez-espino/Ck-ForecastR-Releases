source("R/noage/1. Produce Point and Interval Forecasts_functions.R")

# Naive Time Series Forecasting (Average of Past 5 Years) - Forecasting Results for Youngest Age

#datafile$Forecasting_Year[1] <- as.numeric(gsub("\\s", "", datafile$Forecasting_Year[1]))
datafile$Forecasting_Year <- as.numeric(trimws(datafile$Forecasting_Year))

datafile_original <- datafile


stockname <- datafile$Stock_Name[1]
stockabundance <- datafile$Stock_Abundance[1]
stockspecies <- datafile$Stock_Species[1]
forecastingyear <- datafile$Forecasting_Year[1]



#-----  add calendar year to age extracted from name of --------------------------
#-----  response variable for naive forecasting (average of past 5 years) ---------------------------------

datalist <- datalist.no.age(datafile, forecastingyear, stockabundance)  # CY refers to the T variable with highest age


#--------- plot data to be used for naive forecasting (average of past 5 years) (uses ggplot) ---------------------------

## plot.data.no.age(datalist)

###  naiveone ###


#---------  fit naive model (previous year) -----------------------------------------


if (noagemodelnaiveone) {  #naiveone
      fit.naiveone.model.no.age <- naiveone.model.no.age(datalist)}


#---------  Plot naive model (previous year) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------

## options(warn=-1)
## plot.fitted.naiveone.no.age(fit.naiveone.model.no.age)
## options(warn=0)


#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm

## point.forecast.naiveone.no.age(datalist, fit.naiveone.model.no.age, forecastingyear)

if (noagemodelnaiveone){  # naiveone

    tmp_list <- point.forecast.naiveone.no.age(datalist, fit.naiveone.model.no.age, forecastingyear)

    tmp_df <- do.call(cbind.data.frame, tmp_list)

    results.point.forecast.naiveone.no.age <- tmp_df

    results.point.forecast.naiveone.no.age$Model <- as.character(results.point.forecast.naiveone.no.age$Model)

}



#---- meboot2 function for bootstrapping positive time series ----------------------------------------


#*******************************************************************************************
#
#-- compute prediction intervals for point forecasts of individual ages
#
#*******************************************************************************************

## fit=fit.naiveone.model.no.age; level=80; npaths=B

## meboot2 bootstrap for a specific age


## forecast.naiveone.modified.no.age(fit=fit.naiveone.model.no.age, bootmethod, level=80, npaths=B)

if (noagemodelnaiveone) {  # naiveone

   pred.int.individual.stock.naiveone.no.age <- prediction.intervals.individual.stock.naiveone.no.age(fit.naiveone.model.no.age, bootmethod, level=80, npaths=B)

}

##############  avgthree ##########################################################################################################################


###############  avgthree #########################################################################################################################


#--------- helper function for computing the average of the past 3 years of a time series -----


#---------  fit naive model (average of past 3 years) -----------------------------------------


if (noagemodelavgthree){  ## avgthree

   fit.avgthree.model.no.age <- avgthree.model.no.age(datalist)

}

#---------  Plot naive model (average of past 3 years) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------

## options(warn=-1)
## plot.fitted.avgthree.no.age(fit.avgthree.model.no.age)
## options(warn=0)



#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm


## point.forecast.avgthree.no.age(datalist, fit.avgthree.model.no.age, forecastingyear)

if (noagemodelavgthree){  ## avgthree

    tmp_list <- point.forecast.avgthree.no.age(datalist, fit.avgthree.model.no.age, forecastingyear)

    tmp_df <- do.call(cbind.data.frame, tmp_list)

    results.point.forecast.avgthree.no.age <- tmp_df

    results.point.forecast.avgthree.no.age$Model <- as.character(results.point.forecast.avgthree.no.age$Model)

}



#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## meboot2 bootstrap for a stock without age-specific data


## forecast.avgthree.modified.no.age(fit.avgthree.model.no.age, bootmethod, level=80, npaths=B)

if (noagemodelavgthree){  ## avgthree

    pred.int.individual.stock.avgthree.no.age <- prediction.intervals.individual.stock.avgthree.no.age(fit.avgthree.model.no.age, bootmethod, level=80, npaths=B)

}

## pred.int.individual.stock.avgthree.no.age

###############  avgfive #########################################################################################################################


#--------- helper function for computing the average of the past 5 years of a time series -----

#---------  fit naive model (average of past 5 years) -----------------------------------------

if (noagemodelavgfive){  ## avgfive

   fit.avgfive.model.no.age <- avgfive.model.no.age(datalist)

}


#---------  Plot naive model (average of past 5 years) --------------------------------
# Plot fitted naive model (ggplot)
#-------------------------------------------------------------------------------

## options(warn=-1)
## plot.fitted.avgfive.no.age(fit.avgfive.model.no.age)
## options(warn=0)

#--------- point forecast for each individual age and for the total age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm


## point.forecast.avgfive.no.age(datalist, fit.avgfive.model.no.age, forecastingyear)

if (noagemodelavgfive) {   ## avgfive

    tmp_list <- point.forecast.avgfive.no.age(datalist, fit.avgfive.model.no.age, forecastingyear)

    tmp_df <- do.call(cbind.data.frame, tmp_list)

    results.point.forecast.avgfive.no.age <- tmp_df

    results.point.forecast.avgfive.no.age$Model <- as.character(results.point.forecast.avgfive.no.age$Model)

}

#---- meboot2 function for bootstrapping positive time series ----------------------------------------

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## meboot2 bootstrap for a stock without age-specific data


## forecast.avgfive.modified.no.age(fit.avgfive.model.no.age, bootmethod, level=80, npaths=B)


if (noagemodelavgfive) {   ## avgfive

   pred.int.individual.stock.avgfive.no.age <- prediction.intervals.individual.stock.avgfive.no.age(fit.avgfive.model.no.age, bootmethod, level=80, npaths=B)

}


## pred.int.individual.ages.avgfive.no.age

## pred.int.individual.ages.avgfive.no.age$PI.ctr
## pred.int.individual.ages.avgfive.no.age$PI.lwr
## pred.int.individual.ages.avgfive.no.age$PI.upr
## pred.int.individual.ages.avgfive.no.age$sim


########################################################################################################
########################################################################################################
#
# ARIMA Forecasting  - Forecasting Results for Stock Without Age Information
#
########################################################################################################
########################################################################################################

#---------  fit time series ARIMA model -----------------------------------------

if (noagemodelarima) {   ## arima

    arima.model.fit.no.age  <- arima.model.no.age(datalist, boxcoxtransform)
    fit.arima.model.no.age <- arima.model.fit.no.age

}

#---------  Plot fitted time series ARIMA model --------------------------------
# Plot fit time series ARIMA model
#-------------------------------------------------------------------------------

## plot.fitted.arima.no.age(arima.model.fit.no.age, boxcoxtransform)



#-------------------------------------------------------------------------------
# Report ARIMA Model Results for Stock Without Age Information
#-------------------------------------------------------------------------------

## arima.model.results.no.age(arima.model.fit.no.age)


#--------- point forecast for the stock without age information ---------------------------------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm


## point.forecast.arima.no.age(datalist, fit=arima.model.fit.no.age, forecastingyear, boxcoxtransform)


if (noagemodelarima) {   ## arima

    tmp_list <- point.forecast.arima.no.age(datalist, arima.model.fit.no.age, forecastingyear, boxcoxtransform)

    tmp_df <- do.call(cbind.data.frame, tmp_list)

    results.point.forecast.arima.no.age <- tmp_df

    results.point.forecast.arima.no.age$Model <- as.character(results.point.forecast.arima.no.age$Model)

}


#---- meboot2 function for bootstrapping positive time series ----------------------------------------

#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

##
## meboot2 bootstrap
##

## fit <- fit.arima.model.no.age
## forecast.arima.modified.meboot.no.age(fit.arima.model.no.age, boxcoxtransform, level=80, npaths=B)


##
## stlboot (loess) bootstrap
##

## debug <- forecast.arima.modified.stlboot.no.age(fit.arima.model.no.age,  boxcoxtransform, level=80, npaths=B)

## debug$lower
## debug$mean
## debug$upper


#*******************************************************************************************
#
#------------ compute prediction interval for arima model -----------
#
#*******************************************************************************************

if (noagemodelarima) {   ## arima

   ## pred.int.individual.stock.arima.no.age <- prediction.interval.no.age.arima(fit.arima.model.no.age, boxcoxtransform, bootmethod, level=0.80, npaths=B)

   pred.int.individual.stock.arima.no.age <- prediction.interval.no.age.arima(fit.arima.model.no.age, boxcoxtransform, bootmethod, level=80, npaths=B)

}


########################################################################################################
########################################################################################################
#
# Exponential Smoothing - Forecasting Results for Stock without Age Information
#
########################################################################################################
########################################################################################################


#---------  fit exponential smoothing model -----------------------------------------

if (noagemodelexpsmooth) {   ## expsmooth

   expsmooth.model.fit.no.age  <- expsmooth.model.no.age(datalist, boxcoxtransform)
   fit <- expsmooth.model.fit.no.age

   fit.expsmooth.model.no.age <- expsmooth.model.fit.no.age

}


#---------  Plot fitted exponential smoothing model --------------------------------
# Plot fitted exponential smoothing model (ggplot)
#-----------------------------------------------------------------------------------

## plot.fitted.expsmooth.no.age(expsmooth.model.fit.no.age, boxcoxtransform)



#-------------------------------------------------------------------------------
# Report Exponential Smoothing Model Results for A Specific Age Class
#-------------------------------------------------------------------------------

## expsmooth.model.results.no.age(fit)



#--------- point forecast for the youngest age ----------------------

## http://science.nature.nps.gov/im/datamgmt/statistics/r/advanced/ReproducibleReporting.cfm


if (noagemodelexpsmooth) {   ## expsmooth

    tmp_list <- point.forecast.expsmooth.no.age(datalist, expsmooth.model.fit.no.age, boxcoxtransform, forecastingyear)

    tmp_df <- do.call(cbind.data.frame, tmp_list)

    results.point.forecast.expsmooth.no.age <- tmp_df

    results.point.forecast.expsmooth.no.age$Model <- as.character(results.point.forecast.expsmooth.no.age$Model)

}




#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

## meboot2 bootstrap for a specific age

## fit <- expsmooth.model.fit.no.age

## debug <- forecast.expsmooth.modified.meboot.no.age(fit,  boxcoxtransform, level=80, npaths=B)


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

## debug <- forecast.expsmooth.modified.stlboot.no.age(fit=expsmooth.model.fit.no.age, boxcoxtransform, level=80, npaths=B)


#*******************************************************************************************
#
#------------ compute prediction intervals for point forecasts of individual ages -----------
#
#*******************************************************************************************

# fit <- expsmooth.model.fit.no.age

if (noagemodelexpsmooth) {   ## expsmooth

   fit <- expsmooth.model.fit.no.age
   pred.int.individual.stock.expsmooth.no.age <- prediction.interval.no.age.expsmooth(fit, boxcoxtransform, bootmethod, level=80, npaths=B)

}






