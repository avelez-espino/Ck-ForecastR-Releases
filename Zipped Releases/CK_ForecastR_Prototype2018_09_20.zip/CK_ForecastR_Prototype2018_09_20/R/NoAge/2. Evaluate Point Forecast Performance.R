source("R/noage/2. Evaluate Point Forecast Performance_functions.R")

## need to refresh the datalist object, as it currently contains only the youngest age!!!
## datalist

##========================================================================================================
## stock without age information: naiveone
##========================================================================================================

## individual.stock.retro.predictive.performance.naiveone.no.age(datalist, forecastingyear, index)

## individual.stock.retro.plot.no.age.naiveone(no.age.retro.plot.info.naiveone, stockabundance)

##========================================================================================================
## stock without age information: avgthree
##========================================================================================================

## individual.stock.retro.predictive.performance.avgthree.no.age(datalist, forecastingyear, index)

## individual.stock.retro.plot.no.age.avgthree(no.age.retro.plot.info.avgthree, stockabundance)

##========================================================================================================
## stock without age information: avgfive
##========================================================================================================

individual.stock.retro.predictive.performance.avgfive.no.age(datalist, forecastingyear, index)

## individual.stock.retro.plot.no.age.avgfive(no.age.retro.plot.info.avgfive, stockabundance)

##=========================================================
## stock without age information: arima
##========================================================================================================

## individual.stock.retro.predictive.performance.arima.no.age(datalist, forecastingyear, arima.model.fit.no.age, boxcoxtransform, index)

## individual.stock.retro.plot.no.age.arima(no.age.retro.plot.info.arima, stockabundance)


##========================================================================================================
## no age: expsmooth
##========================================================================================================

## individual.stock.retro.predictive.performance.expsmooth.no.age(datalist, forecastingyear, expsmooth.model.fit.no.age, boxcoxtransform, index)

## individual.stock.retro.plot.no.age.expsmooth(no.age.retro.plot.info.expsmooth, stockabundance)


##=========================================================================================================
## measures of retro performance - naiveone
##=========================================================================================================

if (noagemodelnaiveone) {  # naiveone
   results.retro.naiveone.no.age <- individual.stock.retro.predictive.performance.naiveone.no.age(datalist, forecastingyear, index)
   rmse.results.no.age.naiveone <- no.age.retro.predictive.performance.naiveone(results.retro.naiveone.no.age)

   all.retro.measures <- c("MRE","MAE","MPE","MAPE","MASE","RMSE")
   all.retro.measures <- tolower(all.retro.measures)
   flag.all.retro.measures <- c(retromeasureMRE,retromeasureMAE,retromeasureMPE,retromeasureMAPE,retromeasureMASE, retromeasureRMSE)
   user.selected.retro.measures <- all.retro.measures[flag.all.retro.measures==TRUE]

   rmse.results.no.age.naiveone.tmp1 <- rmse.results.no.age.naiveone[names(rmse.results.no.age.naiveone) %in% c("method", "resjoin", "a", "p", "e", "p.bench", "e.bench")]
   rmse.results.no.age.naiveone.tmp2 <- rmse.results.no.age.naiveone[names(rmse.results.no.age.naiveone) %in% user.selected.retro.measures]
   rmse.results.no.age.naiveone <- c(rmse.results.no.age.naiveone.tmp1, rmse.results.no.age.naiveone.tmp2)
}

##=========================================================================================================
## measures of retro performance - avgthree
##=========================================================================================================

if (noagemodelavgthree) {  # avgthree

results.retro.avgthree.no.age <- individual.stock.retro.predictive.performance.avgthree.no.age(datalist, forecastingyear, index)
rmse.results.no.age.avgthree <- no.age.retro.predictive.performance.avgthree(results.retro.avgthree.no.age)

all.retro.measures <- c("MRE","MAE","MPE","MAPE","MASE","RMSE")
all.retro.measures <- tolower(all.retro.measures)
flag.all.retro.measures <- c(retromeasureMRE,retromeasureMAE,retromeasureMPE,retromeasureMAPE,retromeasureMASE, retromeasureRMSE)
user.selected.retro.measures <- all.retro.measures[flag.all.retro.measures==TRUE]

rmse.results.no.age.avgthree.tmp1 <- rmse.results.no.age.avgthree[names(rmse.results.no.age.avgthree) %in% c("method", "resjoin", "a", "p", "e", "p.bench", "e.bench")]
rmse.results.no.age.avgthree.tmp2 <- rmse.results.no.age.avgthree[names(rmse.results.no.age.avgthree) %in% user.selected.retro.measures]
rmse.results.no.age.avgthree <- c(rmse.results.no.age.avgthree.tmp1, rmse.results.no.age.avgthree.tmp2)

}

##=========================================================================================================
## measures of retro performance - avgfive
##=========================================================================================================

if (noagemodelavgfive) {  # avgfive

    results.retro.avgfive.no.age <- individual.stock.retro.predictive.performance.avgfive.no.age(datalist, forecastingyear, index)
    rmse.results.no.age.avgfive <- no.age.retro.predictive.performance.avgfive(results.retro.avgfive.no.age)

    all.retro.measures <- c("MRE","MAE","MPE","MAPE","MASE","RMSE")
    all.retro.measures <- tolower(all.retro.measures)
    flag.all.retro.measures <- c(retromeasureMRE,retromeasureMAE,retromeasureMPE,retromeasureMAPE,retromeasureMASE, retromeasureRMSE)
    user.selected.retro.measures <- all.retro.measures[flag.all.retro.measures==TRUE]

    rmse.results.no.age.avgfive.tmp1 <- rmse.results.no.age.avgfive[names(rmse.results.no.age.avgfive) %in% c("method", "resjoin", "a", "p", "e", "p.bench", "e.bench")]
    rmse.results.no.age.avgfive.tmp2 <- rmse.results.no.age.avgfive[names(rmse.results.no.age.avgfive) %in% user.selected.retro.measures]
    rmse.results.no.age.avgfive <- c(rmse.results.no.age.avgfive.tmp1, rmse.results.no.age.avgfive.tmp2)

}


##=========================================================================================================
## measures of retro performance - arima
##=========================================================================================================

if (noagemodelarima) {  # arima

    results.retro.arima.no.age <- individual.stock.retro.predictive.performance.arima.no.age(datalist, forecastingyear, arima.model.fit.no.age, boxcoxtransform, index)

    rmse.results.no.age.arima <- no.age.retro.predictive.performance.arima(results.retro.arima.no.age)

    all.retro.measures <- c("MRE","MAE","MPE","MAPE","MASE","RMSE")
    all.retro.measures <- tolower(all.retro.measures)
    flag.all.retro.measures <- c(retromeasureMRE,retromeasureMAE,retromeasureMPE,retromeasureMAPE,retromeasureMASE, retromeasureRMSE)
    user.selected.retro.measures <- all.retro.measures[flag.all.retro.measures==TRUE]

    rmse.results.no.age.arima.tmp1 <- rmse.results.no.age.arima[names(rmse.results.no.age.arima) %in% c("method", "resjoin", "a", "p", "e", "p.bench", "e.bench")]
    rmse.results.no.age.arima.tmp2 <- rmse.results.no.age.arima[names(rmse.results.no.age.arima) %in% user.selected.retro.measures]
    rmse.results.no.age.arima <- c(rmse.results.no.age.arima.tmp1, rmse.results.no.age.arima.tmp2)

}

##=========================================================================================================
## measures of retro performance - expsmooth
##=========================================================================================================

if (noagemodelexpsmooth) {  # expsmooth

    results.retro.expsmooth.no.age <- individual.stock.retro.predictive.performance.expsmooth.no.age(datalist,
                                                forecastingyear,
                                                expsmooth.model.fit.no.age,
                                                boxcoxtransform, index)

    rmse.results.no.age.expsmooth <- no.age.retro.predictive.performance.expsmooth(results.retro.expsmooth.no.age)

    all.retro.measures <- c("MRE","MAE","MPE","MAPE","MASE","RMSE")
    all.retro.measures <- tolower(all.retro.measures)
    flag.all.retro.measures <- c(retromeasureMRE,retromeasureMAE,retromeasureMPE,retromeasureMAPE,retromeasureMASE, retromeasureRMSE)
    user.selected.retro.measures <- all.retro.measures[flag.all.retro.measures==TRUE]

    rmse.results.no.age.expsmooth.tmp1 <- rmse.results.no.age.expsmooth[names(rmse.results.no.age.expsmooth) %in% c("method", "resjoin", "a", "p", "e", "p.bench", "e.bench")]
    rmse.results.no.age.expsmooth.tmp2 <- rmse.results.no.age.expsmooth[names(rmse.results.no.age.expsmooth) %in% user.selected.retro.measures]
    rmse.results.no.age.expsmooth <- c(rmse.results.no.age.expsmooth.tmp1, rmse.results.no.age.expsmooth.tmp2)

}


##=========================================================================================================
## choosing the measure of retro performance (i.e., rmse) which is "best" for forecasting stock abundance
## among avgone, avgthree, avgfive, arima and expsmooth
##=========================================================================================================


#-------------------------------------------------------------------------------

all.args <- c("rmse.results.no.age.naiveone",
                                  "rmse.results.no.age.avgthree",
                                  "rmse.results.no.age.avgfive",
                                  "rmse.results.no.age.arima",
                                  "rmse.results.no.age.expsmooth")

rmse.results.no.age.args <- mget( ls( pattern = "^rmse.results.no.age.", env = .GlobalEnv ) , env = .GlobalEnv )

select.args <- names(rmse.results.no.age.args)

order.all.args <- all.args[all.args %in% select.args]

rmse.results.no.age.args <- rmse.results.no.age.args[order.all.args]

rmse.results.no.age.args$rmse.results.no.age.args <- NULL

## rmse.results.no.age.args

## names(rmse.results.no.age.args)

## str(rmse.results.no.age.args)

#-------------------------------------------------------------------------------


retromeasure.args <- mget( ls( pattern = "^retromeasure", env = .GlobalEnv) , env = .GlobalEnv )

retromeasure.args <- Filter(isTRUE, retromeasure.args)

all.measures <- c("retromeasureMRE",
                  "retromeasureMAE",
                  "retromeasureMPE",
                  "retromeasureMAPE",
                  "retromeasureMASE",
                  "retromeasureRMSE")


retromeasure.args <-  retromeasure.args[all.measures]

## Source: https://stat.ethz.ch/pipermail/r-help/2006-August/111896.html
delete.NULLs  <-  function(x.list){   # delele null/empty entries in a list
    x.list[unlist(lapply(x.list, length) != 0)]
}

retromeasure.args <- delete.NULLs(retromeasure.args)

## names(retromeasure.args)

#-------------------------------------------------------------------------------

table.rmse.results.no.age <- rmse.results.no.age(rmse.results.no.age.args, retromeasure.args)

##
## rank table of rmse (and other performance metrics) results
##

pred.args <- mget( ls( pattern = "^pred.int.individual.stock.", env = .GlobalEnv) , env = .GlobalEnv )

all.pred.args <- c("pred.int.individual.stock.naiveone.no.age",
                     "pred.int.individual.stock.avgthree.no.age",
                       "pred.int.individual.stock.avgfive.no.age",
                         "pred.int.individual.stock.arima.no.age",
                           "pred.int.individual.stock.expsmooth.no.age")

pred.args <-  pred.args[all.pred.args]

pred.args <- delete.NULLs(pred.args)

## names(pred.args)

table.rank.rmse.results.no.age <- rank.rmse.results.no.age(table.rmse.results.no.age, pred.args)

## print(table.rank.rmse.results.no.age$best.model)
## print(table.rank.rmse.results.no.age)

###
### Histogram of Retrospective Forecast Errors: No Age Information // naiveone
###

#--------------------------------------------------------------------------------------------------

retro.args <- mget( ls( pattern = "^results.retro.", env = .GlobalEnv) , env = .GlobalEnv )

all.results.retro <- c("results.retro.naiveone.no.age",
                        "results.retro.avgthree.no.age",
                         "results.retro.avgfive.no.age",
                           "results.retro.arima.no.age",
                             "results.retro.expsmooth.no.age")

retro.args <-  retro.args[all.results.retro]
retro.args <- delete.NULLs(retro.args)
## names(retro.args)

#--------------------------------------------------------------------------------------------------

## plot.hist.retrospective.forecast.errors.individual.stock(retro.args)

#*******************************************************************************
#
# Gary's Plot: avgthree
#
#*******************************************************************************

## pred.int.individual.stock.naiveone.no.age

## gary.plot.individual.stock.naiveone.no.age(pred.int.individual.stock.naiveone.no.age,
##                                            results.retro.naiveone.no.age,
##                                            stockabundance,
##                                            forecastingyear)

#*******************************************************************************
#
# Gary's Plot: avgthree
#
#*******************************************************************************

## pred.int.individual.stock.avgthree.no.age

## gary.plot.individual.stock.avgthree.no.age(pred.int.individual.stock.avgthree.no.age,
##                                            results.retro.avgthree.no.age,
##                                            stockabundance,
##                                             forecastingyear)


#*******************************************************************************
#
# Gary's Plot: avgfive
#
#*******************************************************************************

## pred.int.individual.stock.avgfive.no.age

## gary.plot.individual.stock.avgfive.no.age(pred.int.individual.stock.avgfive.no.age,
##                                            results.retro.avgfive.no.age,
##                                            stockabundance,
##                                            forecastingyear)

#*******************************************************************************
#
# Gary's Plot: arima
#
#*******************************************************************************

## pred.int.individual.stock.arima.no.age

## gary.plot.individual.stock.arima.no.age(pred.int.individual.stock.arima.no.age,
##                                            results.retro.arima.no.age,
##                                            stockabundance,
##                                            forecastingyear)



#*******************************************************************************
#
# Gary's Plot: expsmooth
#
#*******************************************************************************

## pred.int.individual.stock.expsmooth.no.age

## gary.plot.individual.stock.expsmooth.no.age(pred.int.individual.stock.expsmooth.no.age,
##                                            results.retro.expsmooth.no.age,
##                                            stockabundance,
##                                            forecastingyear)


##
## Table of results for candidate models for no age: avgfive, arima, expsmooth
##

# pred.int.individual.stock.naiveone.no.age
# pred.int.individual.stock.avgthree.no.age
# pred.int.individual.stock.avgfive.no.age
# pred.int.individual.stock.arima.no.age
# pred.int.individual.stock.expsmooth.no.age


## extract PI.ctr  ---  lapply(X = pred.args, FUN = `[[`, "PI.ctr")



table.results.individual.stock.all.models.no.age <- list()

names.pred.args <-  names(pred.args)
names.pred.args <- str_replace_all(names.pred.args,"pred.int.individual.stock.","")
names.pred.args <- str_replace_all(names.pred.args,".no.age","")
## names.pred.args

labels.pred.args <- NULL       ## names of forecasting models

for (k in 1:length(pred.args)){

          tmplabel <-  names.pred.args[k]
          if (tmplabel=="naiveone") {
              labels.pred.args <- c(labels.pred.args, "Naive Model (Previous Year)")
          } else if (tmplabel=="avgthree") {
              labels.pred.args <- c(labels.pred.args, "Naive Model (Average of Previous Three Years)")
          } else if (tmplabel=="avgfive") {
              labels.pred.args <- c(labels.pred.args, "Naive Model (Average of Previous Five Years)")
          } else if (tmplabel=="arima") {
              labels.pred.args <- c(labels.pred.args, "ARIMA Model")
          } else {
              labels.pred.args <- c(labels.pred.args, "Exponential Smoothing Model")
          }
}

table.results.individual.stock.all.models.no.age$Model <- labels.pred.args   ## names of forecasting models

table.results.individual.stock.all.models.no.age$PI.ctr <-  unlist(lapply(X = pred.args, FUN = `[[`, "PI.ctr"))

table.results.individual.stock.all.models.no.age$PI.ctr <- round(as.numeric(table.results.individual.stock.all.models.no.age$PI.ctr))

table.results.individual.stock.all.models.no.age$PI.lwr <- unlist(lapply(X = pred.args, FUN = `[[`, "PI.lwr"))

table.results.individual.stock.all.models.no.age$PI.lwr <- round(as.numeric(table.results.individual.stock.all.models.no.age$PI.lwr))


table.results.individual.stock.all.models.no.age$PI.upr <- unlist(lapply(X = pred.args, FUN = `[[`, "PI.upr"))

table.results.individual.stock.all.models.no.age$PI.upr <- round(as.numeric(table.results.individual.stock.all.models.no.age$PI.upr))

table.results.individual.stock.all.models.no.age <- do.call(cbind.data.frame, table.results.individual.stock.all.models.no.age)

usePackage("scales")
table.results.individual.stock.all.models.no.age$PI.ctr <- comma(table.results.individual.stock.all.models.no.age$PI.ctr)
table.results.individual.stock.all.models.no.age$PI.lwr <- comma(table.results.individual.stock.all.models.no.age$PI.lwr)
table.results.individual.stock.all.models.no.age$PI.upr <- comma(table.results.individual.stock.all.models.no.age$PI.upr)



table.results.individual.stock.all.models.no.age$PI.int <- paste0(table.results.individual.stock.all.models.no.age$PI.lwr,
                                                                   " - ",
                                                                   table.results.individual.stock.all.models.no.age$PI.upr)

table.results.individual.stock.all.models.no.age <- subset(table.results.individual.stock.all.models.no.age,
                                                            select=c(Model, PI.ctr,  PI.int))
names(table.results.individual.stock.all.models.no.age) <-  c("Model", "Point Forecast", "Interval Forecast")

## table.results.individual.stock.all.models.no.age



###
### plot forecast vs. actual: all models
###

## scatter.plot.results.afe.individual.stock.retro.all.models.no.age(retro.args, stockabundance)

#-----------------------------------------------------------------------------------------
# Time series plot of retrospectively forecasted and actual values
#-----------------------------------------------------------------------------------------

## results <- results.individual.ages.retro.predictive.performance.expsmooth
## timeseries.plot.results.afe.individual.ages.retro.expsmooth(results, stockabundance)

timeseries.plot.results.afe.individual.stock.retro.all.models.no.age(retro.args, stockabundance)
