
## Extract ARIMA Modeling Results

#*******************************************************************************
#  barplot forecasted values: naiveone
#*******************************************************************************

if (noagemodelnaiveone) {barplot.forecasted.values.individual.stock.naiveone.no.age(pred.int.individual.stock.naiveone.no.age, forecastingyear)}

#*******************************************************************************
#  barplot forecasted values: avgthree
#*******************************************************************************

if (noagemodelavgthree) {

barplot.forecasted.values.individual.stock.avgthree.no.age(
    pred.int.individual.stock.avgthree.no.age,
      forecastingyear)

}

#*******************************************************************************
#  barplot forecasted values: avgfive
#*******************************************************************************

if (noagemodelavgfive){

  barplot.forecasted.values.individual.stock.avgfive.no.age(
   pred.int.individual.stock.avgfive.no.age,
    forecastingyear)
}

#*******************************************************************************
#  barplot forecasted values: arima
#*******************************************************************************
if (noagemodelarima) {
  barplot.forecasted.values.individual.stock.arima.no.age(pred.int.individual.stock.arima.no.age, forecastingyear)}

#*******************************************************************************
#  barplot forecasted values: expsmooth
#*******************************************************************************
if (noagemodelexpsmooth) {
  barplot.forecasted.values.individual.stock.expsmooth.no.age(
  pred.int.individual.stock.expsmooth.no.age,
  forecastingyear)
}

###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (avgthree) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## scatterplot.forecasted.values.and.forecast.intervals.individual.stock.naiveone.no.age(pred.int.individual.stock.naiveone.no.age, forecastingyear)


###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (avgthree) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## scatterplot.forecasted.values.and.forecast.intervals.individual.stock.avgthree.no.age(pred.int.individual.stock.avgthree.no.age, forecastingyear)

###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (avgfive) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## scatterplot.forecasted.values.and.forecast.intervals.individual.stock.avgfive.no.age(pred.int.individual.stock.avgfive.no.age, forecastingyear)

###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (arima) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## scatterplot.forecasted.values.and.forecast.intervals.individual.stock.arima.no.age(pred.int.individual.stock.arima.no.age, forecastingyear)

###################################################################################################################################
#**********************************************************************************************************************************
#
#---- plot forecasted values & forecast intervals:  scatterplot (expsmooth) -------------------------------------------------
#
#**********************************************************************************************************************************
###################################################################################################################################

## scatterplot.forecasted.values.and.forecast.intervals.individual.stock.expsmooth.no.age(pred.int.individual.stock.expsmooth.no.age, forecastingyear)

###
### Density Plots of Retrospective Forecast Errors: All models selected by the user
###

# rmse.results.no.age.expsmooth$resjoin

# rmse.results.no.age.naiveone
# rmse.results.no.age.avgthree
# rmse.results.no.age.avgfive
# rmse.results.no.age.arima
# rmse.results.no.age.expsmooth

plot.dens.retrospective.forecast.errors.individual.stock.no.age(rmse.results.no.age.args, retro.args)

plot.superimposed.dens.retrospective.forecast.errors.individual.stock.no.age(rmse.results.no.age.args, retro.args)

##===============================================================================================
## Bias Coefficient Plots
##===============================================================================================

windows()
plot.bias.coefficients.retrospective.forecast.errors.individual.stock.no.age(
  rmse.results.no.age.args,
  retro.args)

##===============================================================================================
## APPENDIX:  Model Diagnostics for All Considered Models
##===============================================================================================


## fits <-  list(naiveone = fit.naiveone.model.no.age,
##              avgthree = fit.avgthree.model.no.age,
##              avgfive = fit.avgfive.model.no.age,
##              arima = fit.arima.model.no.age,
##              expsmooth = fit.expsmooth.model.no.age)


user.fits <- mget( ls( pattern = "^fit.", env = .GlobalEnv) , env = .GlobalEnv )


all.fits <- c("fit.naiveone.model.no.age",
                "fit.avgthree.model.no.age",
                  "fit.avgfive.model.no.age",
                    "fit.arima.model.no.age",
                      "fit.expsmooth.model.no.age")

user.fits <-  user.fits[all.fits]
user.fits <- delete.NULLs(user.fits)

## names(user.fits)

## str(user.fits)

##--- Index Plot of Residuals -------------------------------------------------------------------

## index.plot.residuals.individual.stock.all.models.no.age(user.fits, retro.args)

##--- Time Series Plot of Residuals -------------------------------------------------------------------

## timeseries.plot.residuals.individual.stock.all.models.no.age(user.fits, retro.args)

##--- ACF Plot of Model Residuals for All Models

## acf.plot.residuals.individual.stock.all.models.no.age(user.fits, retro.args)

##--- PACF Plot of Model Residuals for All Models

## pacf.plot.residuals.individual.stock.all.models.no.age(user.fits, retro.args)


##--- P-Values of Ljung-Box Test for All Models

## ljung.box.plot.residuals.individual.stock.all.models.no.age(datalist, user.fits, retro.args, boxcoxtransform)
