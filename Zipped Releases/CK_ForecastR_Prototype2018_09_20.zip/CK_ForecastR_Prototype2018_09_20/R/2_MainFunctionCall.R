# MAIN FUNCTION CALL FOR FORECASTR GUI

# This file duplicates the steps from the following original scripts:
# "Produce Individual Model Reports for Stocks with Age.R"
# "Produce Reports for Stocks without Age.r"
# A lot of code is copied from those scripts verbatim.

# the steps are here organized inside a single umbrella function that
# accepts a single input object from the GUI.

# Note: Michael Folkes is concurrently reworking the core model code
# (e.g. streamlining, extensions). At some point, the 2 pieces will be merged,
# but for now this is set up to communicate with the original code and retains
# the current variable names etc.


forecastR_Main <- function(input.obj,
							path.Rfolder="../../R",
							path.reports="../../ForecastRReports",
							path.template="../inst/extdata/TemplateReport"){

# temporary for testing
#input.obj <- list(model.type = "WithAge")
#browser()
print(input.obj)


####
#### Step 1: House Keeping and Setting Up ####
####

options(warn=1)
homeDir <- getwd()  # TO DO: change this to input.obj$homeDir # seems to be a bit convoluted to get shiny selection for a directory. using "current dir" for now

# new step to read in ALL the functions
# this should work, becauswe in the old code they all have unique names 
# (datalist.naiveone, datatlist.avgthree, etc), and as this get's fixed there
# will be just a few files with consolidated functions



for(dir.use in list.dirs(path=path.Rfolder,full.names = TRUE, recursive = TRUE)){
	print("------------------")
	print(dir.use)
	
	if(dir.use == path.Rfolder){pattern.list <- c("*[.]R$","*[.]r$") } 
	if(dir.use != path.Rfolder){pattern.list <- c("_functions.R","_functions.r") } 	

	for(pattern.use in pattern.list){
		fn.file.list <- list.files(path=dir.use,pattern=pattern.use) # get all .R files 
		#print(fn.file.list)
		print("-------")
		for(file.source in fn.file.list){
			print(paste("Sourcing: ",file.source))
			source(paste(dir.use,file.source,sep="/"))
			} # end looping through files
		} # end looping through patterns
	} # end looping through folders



# already done as part of above: source(paste(path.Rfolder,"3b_HelperFunctions_ReportCreation.R",sep="/"))


# filename <- input.obj$file.in$name # To Do: link this to GUI input (for now, use hardwired)
#if(input.obj$model.type == "WithAge"){filename <- "Atnarko_Ch_Esc_to2017_3_6_ForecastR.csv"}
#if(input.obj$model.type == "WithoutAge"){filename <- "GSQ_Esc_No_Age.csv"}
filename <- input.obj$file.name



# "WithAge" script used to have this, but now included in 3_HelperFunctions.R
#usePackage("ReporteRs")
#source("startReport.R")
#source("endReport.R")





#### Step 2: General Settings ####

# Keeping these hardwired for now.
# TO DO: convert these to GUI inputs (or use input files?)



if(input.obj$model.type == "WithAge"){

	# changed all these to global variables
	# TEMPORARY, until Git issue #8 sorted

	set.seed(input.obj$set.seed)
	bootmethod <<-  input.obj$boots.method

	# "meboot"      # use maximum entropy bootstrapping for time series bootstrapping
	# "stlboot"   # use loess bootstrapping for time series bootstrapping

	index.year <<- input.obj$index.year    # minimum number of years to use for retrospective forecast evaluation
	B <<- input.obj$B            # number of bootstrap samples to use when constructing forecast intervals
	boxcoxtransform <<- input.obj$boxcoxtransform  # whether or not to use Box Cox transformation for data used to fit time series models
                         # (i.e., ARIMA, Exponential Smoothing)  ---> set to FALSE if no transformation is desired


	#Note: why no retromeasure inputs here -> see Git Issue #10


}


if(input.obj$model.type == "WithoutAge"){

	boxcoxtransform <<- input.obj$boxcoxtransform   # use Box Cox transformation
	bootmethod <<- input.obj$boots.method
	# "meboot" =use maximum entropy bootstrapping
	# "stlboot"   # use loess bootstrapping
	index <<- input.obj$index.year     ## how many years to use when initializing the retrospective point forecast evaluation
	B <<- input.obj$B

	#Note: why retromeasure inputs here but not for WithAge models -> see Git Issue #10
	# To Do: convert these to GUI settings
	retromeasureMRE <<- TRUE
	retromeasureMAE <<- FALSE
	retromeasureMPE <<- TRUE
	retromeasureMAPE <<- FALSE
	retromeasureMASE <<- TRUE
	retromeasureRMSE <<- FALSE

	usePackage("rJava")

}




####
#### Step 3: Activate Selected Models ####
####

# For now, exactly replicate the existing list of  model options
# During re-design, need to fix the fundamental structure
# e.g. naive n.yr, rather than n1, n3, n5


# WithAge


n1.model <- "n1.model" %in% input.obj$model.use.withage  # if n1.model is one of the selected models, then this is TRUE
n3.model <- "n3.model" %in% input.obj$model.use.withage
n5.model <- "n5.model" %in% input.obj$model.use.withage
ARIMA.model <- "ARIMA.model" %in% input.obj$model.use.withage
EXPSMOOTH.model <-  "EXPSMOOTH.model" %in% input.obj$model.use.withage
SIMPLESIBREG.model <-  "SIMPLESIBREG.model" %in% input.obj$model.use.withage
SIMPLELOGPOWER.model <-  "SIMPLELOGPOWER.model" %in% input.obj$model.use.withage


print("---------------------")
print("model selections")
print(isTRUE(n1.model))
print(isTRUE(n3.model))
print(isTRUE(n5.model))
print(isTRUE(ARIMA.model))
print(isTRUE(EXPSMOOTH.model))
print(isTRUE(SIMPLESIBREG.model))
print(isTRUE(SIMPLELOGPOWER.model))





#WithoutAge
# feed into global variable
# TEMPORARY UNTIL ENVIRONMENTS ARE SORTED OUT -> see Git Issue #8


noagemodelnaiveone <- TRUE # noagemodelnaiveone %in% input.obj$model.use.withoutage  # naive model (previous year)
noagemodelavgthree <- TRUE # noagemodelavgthree %in% input.obj$model.use.withoutage # naive model (average of previous 3 years)
noagemodelavgfive <-  TRUE # noagemodelavgfive %in% input.obj$model.use.withoutage # naive model (average of previous 5 years)
noagemodelarima <- TRUE # noagemodelarima %in% input.obj$model.use.withoutage   # ARIMA model
noagemodelexpsmooth <- TRUE # noagemodelexpsmooth %in% input.obj$model.use.withoutage # exponential smoothing model





####
#### Step 4: Read Data ####
####

# This step almost identical for "WithAge" and "WithoutAge"
filename_in <- input.obj$file.name #now getting full filename from GUI selection (and using that in read.csv)
# there must be a more elegant way to get only the filename root, but doing in 2 steps for now
#filename_original <- substr(filename_in,1,which(strsplit(filename_in,"")[[1]]==".")-1)
#filename_original <- substr(filename_original,which(strsplit(filename_in,"")[[1]]=="/")+1,nchar(filename_original))

print("filename_in -------------------")
print(filename_in)

filename_original <- basename(filename_in)

datafile_original <- read.csv(filename_in, header=TRUE, as.is=TRUE)

#
print("File Names")
print(input.obj$filename)
print(filename_in)
print(filename_original)


# used to be
#filename_original  <- paste0(filename, ".csv")  , but
#datafile_original <- read.csv(paste0("Data","\\",filename_original), header=TRUE, as.is=TRUE)




# was commented out in original, keeping around asa ref for now
## ind <- apply(datafile_original, 1, function(x) all(is.na(x)))
## datafile_original <- datafile_original[!ind, ]       ## R may read an extra final line

datafile_original$Stock_Name[datafile_original$Stock_Name==""] <- NA
datafile_original$Stock_Species[datafile_original$Stock_Species==""] <- NA
datafile_original$Stock_Abundance[datafile_original$Stock_Abundance==""] <- NA
datafile_original$Forecasting_Year[datafile_original$Forecasting_Year==""] <- NA

datafile_original <- datafile_original[rowSums(is.na(datafile_original))!=ncol(datafile_original), ]

# not sure yet why this is needed
# To Do: trace through, then remove/fix
if(input.obj$model.type == "WithoutAge"){
	datafile <- datafile_original  ## Add this GUI command for stocks with NO AGE information,
                               ## otherwise the test R code will NOT work
	}


# feed into global variable
# TEMPORARY UNTIL ENVIRONMENTS ARE SORTED OUT -> see Git Issue #8
datafile <<- datafile_original
datafile_original <<- datafile_original

print("------------------")
print(filename_original)
print("------------------")
print(head(datafile_original))  # TO DO: print these to screen or log file or report?
print("------------------")
print(tail(datafile_original))
print("------------------")





####
#### Steps X to Y: Run Forecasts and Create Reports ####
####

# this will be streamlined based on Michael's work.
# for now, just keeping the sections separate and identical the the original scripts
# except for condensing the code layout


# Keeping "WithAge" and "WithoutAge" completely separate for now, because
# "WithAge" uses environments
# "WithoutAge" seems to not use environments
# -> see Git issue #8

####
#### Step 5: START OF "WITHOUT AGE" SECTION ####
####

if(input.obj$model.type == "WithoutAge"){

usePackage("rJava")

# Source Code for Bias Coefficient Computation and Visualization
# functions in here are already read in beginning
# source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)

# Source Code for Loess Bootstrapping for Time Series (Imported from package ‘TStools’ version 1.90)
## usePackage("Rcpp")
# functions in here are already read in beginning
#source(paste(path.Rfolder,"stlboot.R",sep="/"), echo=TRUE)

# Source Code for Naive and Time Series Modeling
source(paste(path.Rfolder,"noage/1. Produce Point and Interval Forecasts.R",sep="/"), echo=TRUE)
source(paste(path.Rfolder,"noage/2. Evaluate Point Forecast Performance.R",sep="/"), echo=TRUE)
source(paste(path.Rfolder,"noage/3. Produce Model and Forecast Diagnostics.R",sep="/"), echo=TRUE)
source(paste(path.Rfolder,"noage/4. Display Results for Best Forecasting Model.R",sep="/"), echo=TRUE)

#MF: these fn's are in  helperfunctions.R
# Source Helper Functions for Creating Word Reports
# source(paste0("R Code","\\","No Age","\\","startReport.R"), echo=TRUE)
#source(paste0("R Code","\\","No Age","\\","endReport.R"), echo=TRUE)

# Produce FULL report
docx.file <- paste0(path.reports,"/","Full_Report_", filename_original,"_", bootmethod,".docx")
startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)
source(paste(path.Rfolder,"noage/5. Create ForecastR Report.R",sep="/"), echo=TRUE)
endReport(docx.file=docx.file)

# To Do: Streamline the code to produce this text output
usePackage("stringr")

cat("\n\n\n")
cat("=============================================================================","\n")
cat("Full ForecastR report successfully produced and stored in the following directory:","\n")
cat(homeDir, "\n\n")
cat("Full ForecastR report has the following name:", "\n")
cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

cat("Population/Stock Name: ", stockname, "\n")
cat("Population/Stock Species: ", stockspecies, "\n")
cat("Population/Stock Abundance: ", stockabundance, "\n")
cat("Forecasting Year: ", forecastingyear, "\n")

forecastingmodels <- c(ifelse(isTRUE(noagemodelnaiveone), "naiveone", "\n"),
                       ifelse(isTRUE(noagemodelavgthree), "avgthree", "\n"),
                       ifelse(isTRUE(noagemodelavgfive), "avgfive", "\n"),
                       ifelse(isTRUE(noagemodelarima), "arima", "\n"),
                       ifelse(isTRUE(noagemodelexpsmooth), "expsmooth", "\n"))


cat("Forecasting Model(s): ", forecastingmodels, "\n")
cat("Bootstrap Method: ", bootmethod, "\n")
cat("=============================================================================","\n")

browseURL(docx.file)

graphics.off()


#### Produce SHORT report ("executive") ####
docx.file <- paste0(path.reports,"\\","Executive_Report_", filename_original,"_", bootmethod,".docx")
startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)
source(paste(path.Rfolder,"noage/6. Create Executive Summary for ForecastR Report.R",sep=""), echo=TRUE)
endReport(docx.file=docx.file)


# To Do: Streamline the code to produce this text output
usePackage("stringr")

cat("\n\n\n")
cat("=============================================================================","\n")
cat("Executive ForecastR report successfully produced and stored in the following directory:","\n")
cat(homeDir, "\n\n")
cat("Executive ForecastR report has the following name:", "\n")
cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

cat("Population/Stock Name: ", stockname, "\n")
cat("Population/Stock Species: ", stockspecies, "\n")
cat("Population/Stock Abundance: ", stockabundance, "\n")
cat("Forecasting Year: ", forecastingyear, "\n")

forecastingmodels <- c(ifelse(isTRUE(noagemodelnaiveone), "naiveone", "\n"),
                       ifelse(isTRUE(noagemodelavgthree), "avgthree", "\n"),
                       ifelse(isTRUE(noagemodelavgfive), "avgfive", "\n"),
                       ifelse(isTRUE(noagemodelarima), "arima", "\n"),
                       ifelse(isTRUE(noagemodelexpsmooth), "expsmooth", "\n"))


cat("Forecasting Model(s): ", forecastingmodels, "\n")
cat("Bootstrap Method: ", bootmethod, "\n")
cat("=============================================================================","\n")

browseURL(docx.file)
graphics.off()
}

####
# END OF "WITHOUT AGE" SECTION
####

####
#### Step 6: START OF "WITH AGE" SECTION ####
####

if(input.obj$model.type == "WithAge"){

####
#### Step 6.1: Initialize Model Environments ####
####


if (isTRUE(n1.model)) { n1 <<- new.env() ; print("creating env n1") }
if (isTRUE(n3.model)) { n3 <<- new.env() ; print("creating env n3") }
if (isTRUE(n5.model)) { n5 <<- new.env() ; print("creating env n5") }
if (isTRUE(ARIMA.model)) { ARIMA <<- new.env() ; print("creating env ARIMA") }
if (isTRUE(EXPSMOOTH.model)) { EXPSMOOTH <<- new.env(); print("creating env EXPSMOOTH")  }
if (isTRUE(SIMPLESIBREG.model)) { SIMPLESIBREG <<- new.env() ; print("creating env SIMPLESIBREG ")}  # don't seem to need <<- here? see Git Issue #27
if (isTRUE(SIMPLELOGPOWER.model)) { SIMPLELOGPOWER <<- new.env() ; print("creating env SIMPLELOGPOWER") }



####
####Step 6.2: Distribute User Input to Various Models ####
####


if (isTRUE(n1.model)) {
    n1$index.year <- index.year
    n1$bootmethod <- bootmethod
    n1$B <- B
    n1$boxcoxtransform <- boxcoxtransform

	print("Environment n1 - current contents")
	print(ls(n1))
}

if (isTRUE(n3.model)) {
    n3$index.year <- index.year
    n3$bootmethod <- bootmethod
    n3$B <- B
    n3$boxcoxtransform <- boxcoxtransform
}

if (isTRUE(n5.model)) {
    n5$index.year <- index.year
    n5$bootmethod <- bootmethod
    n5$B <- B
    n5$boxcoxtransform <- boxcoxtransform
}

if (isTRUE(ARIMA.model)) {
    ARIMA$index.year <- index.year
    ARIMA$bootmethod <- bootmethod
    ARIMA$B <- B
    ARIMA$boxcoxtransform <- boxcoxtransform
}


if (isTRUE(EXPSMOOTH.model)) {
     EXPSMOOTH$index.year <- index.year
    EXPSMOOTH$bootmethod <- bootmethod
    EXPSMOOTH$B <- B
    EXPSMOOTH$boxcoxtransform <- boxcoxtransform
}

if (isTRUE(SIMPLESIBREG.model)) {
    SIMPLESIBREG$index.year <- index.year
    ## SIMPLESIBREG$bootmethod <- bootmethod   ## Prediction intervals for youngest age
                                               ## were hard-coded to use stlboot
    SIMPLESIBREG$B <- B
    SIMPLESIBREG$boxcoxtransform <- boxcoxtransform
}


if (isTRUE(SIMPLELOGPOWER.model)) {
    SIMPLELOGPOWER$index.year <- index.year
    ## SIMPLELOGPOWER$bootmethod <- bootmethod   ## Prediction intervals for youngest age
                                                 ## were hard-coded to use stlboot
    SIMPLELOGPOWER$B <- B
    SIMPLELOGPOWER$boxcoxtransform <- boxcoxtransform
}




####
#### Step 6.3: Source Code for Selected Models ####
####

if (isTRUE(n1.model)) {
   # source(paste0(homeDir, "\\", "R Code", "\\", "n1", "\\", "Bias Coefficient Code - Naive One", ".r"))
   # source(paste0(homeDir, "\\", "R Code", "\\", "n1", "\\","stlboot",".r"))
	
	# functions in here are already read in beginning
	#source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
	#source(paste(path.Rfolder,"n1/Review Code - Naive One_functions.r",sep="/"))
	#source(paste(path.Rfolder,"n1/Report - Naive One_functions.r",sep="/"))    
	
	print("-------------------------------------")
	print("Starting to source n1/Review Code - Naive One.r")
	source(paste(path.Rfolder,"n1/Review Code - Naive One.r",sep="/"))
	print("-------------------------------------")
	print("Finished sourcing n1/Review Code - Naive One.r")
	

}

if (isTRUE(n3.model)) {
     #source(paste0(homeDir, "\\", "R Code", "\\", "n3", "\\", "Bias Coefficient Code - Average Three", ".r"))
     #source(paste0(homeDir, "\\", "R Code", "\\", "n3", "\\","stlboot",".r"))
     #source(paste0(homeDir, "\\", "R Code", "\\", "n3", "\\","Review Code - Average Three",".r"))
	
	# functions in here are already read in beginning
	# source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
		
	   source(paste(path.Rfolder,"n3/Review Code - Average Three.r",sep="/"))

}

if (isTRUE(n5.model)) {
    # source(paste0(homeDir, "\\", "R Code", "\\", "n5", "\\", "Bias Coefficient Code - Average Five", ".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "n5", "\\","stlboot",".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "n5", "\\","Review Code - Average Five",".r"))
	
	# functions in here are already read in beginning
	#source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
	
	source(paste(path.Rfolder,"n5/Review Code - Average Five.r",sep="/"))

	}

if (isTRUE(ARIMA.model)) {
    # source(paste0(homeDir, "\\", "R Code", "\\", "ARIMA", "\\", "Bias Coefficient Code - ARIMA", ".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "ARIMA", "\\","stlboot",".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "ARIMA", "\\","Review Code - ARIMA",".r"))
	
	# functions in here are already read in beginning
	#source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
	
	source(paste(path.Rfolder,"arima/Review Code - ARIMA.r",sep="/"))
}

if (isTRUE(EXPSMOOTH.model)) {
    # source(paste0(homeDir, "\\", "R Code", "\\", "EXPSMOOTH", "\\", "Bias Coefficient Code - Exponential Smoothing", ".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "EXPSMOOTH", "\\","stlboot",".r"))
    # source(paste0(homeDir, "\\", "R Code", "\\", "EXPSMOOTH", "\\","Review Code - Exponential Smoothing",".r"))
	# functions in here are already read in beginning
	# source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
	source(paste(path.Rfolder,"EXPSMOOTH/Review Code - Exponential Smoothing.R",sep="/"))
}

if (isTRUE(SIMPLESIBREG.model)) {

	# functions in here are already read in beginning
    #cat("==================================================================", "\n\n")
    #cat("Source file: ", "Bias Coefficient Code - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\", "Bias Coefficient Code - Simple Sibling Regression", ".r"))
    #source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
    #cat("==================================================================", "\n\n")
    #cat("Source file: ", "stlboot", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","stlboot",".r"))
    #source(paste(path.Rfolder,"stlboot.R",sep="/"), echo=TRUE)
    
	
	cat("==================================================================", "\n\n")
    cat("Source file: ", "Review Code - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","Review Code - Simple Sibling Regression",".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/Review Code - Simple Sibling Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Youngest Age - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","Youngest Age - Simple Sibling Regression",".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/Youngest Age - Simple Sibling Regression.r",sep="/"))
    cat("==================================================================", "\n\n")
    cat("Source file: ", "RETRO - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","RETRO - Simple Sibling Regression",".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/RETRO - Simple Sibling Regression.r",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Effects - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","Effects - Simple Sibling Regression",".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/Effects - Simple Sibling Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Misc - Simple Sibling Regressio", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\","Misc - Simple Sibling Regression",".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/Misc - Simple Sibling Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Bias Coefficient Computation - Simple Sibling Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLESIBREG", "\\", "Bias Coefficient Computation - Simple Sibling Regression", ".r"))
    source(paste(path.Rfolder,"SIMPLESIBREG/Bias Coefficient Computation - Simple Sibling Regression.R",sep="/"))

    cat("==================================================================", "\n\n")

}

if (isTRUE(SIMPLELOGPOWER.model)) {
    
	# functions in here are already read in beginning
	#cat("==================================================================", "\n\n")
    #cat("Source file: ", "Bias Coefficient Code - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\", "Bias Coefficient Code - Simple Log Power Regression", ".r"))
    #source(paste(path.Rfolder,"BiasCoefficient.R",sep="/"), echo=TRUE)
    #cat("==================================================================", "\n\n")
    #cat("Source file: ", "stlboot", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","stlboot",".r"))
    #source(paste(path.Rfolder,"stlboot.R",sep="/"), echo=TRUE)
    
	cat("==================================================================", "\n\n")
    cat("Source file: ", "Review Code - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","Review Code - Simple Log Power Regression",".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/Review Code - Simple Log Power Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Youngest Age - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","Youngest Age - Simple Log Power Regression",".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/Youngest Age - Simple Log Power Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "RETRO - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","RETRO - Simple Log Power Regression",".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/RETRO - Simple Log Power Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Effects - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","Effects - Simple Log Power Regression",".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/Effects - Simple Log Power Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Misc - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\","Misc - Simple Log Power Regression",".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/Misc - Simple Log Power Regression.R",sep="/"))

    cat("==================================================================", "\n\n")
    cat("Source file: ", "Bias Coefficient Computation - Simple Log Power Regression", ".r", "\n\n")
    #source(paste0(homeDir, "\\", "R Code", "\\", "SIMPLELOGPOWER", "\\", "Bias Coefficient Computation - Simple Log Power Regression", ".r"))
    source(paste(path.Rfolder,"SIMPLELOGPOWER/Bias Coefficient Computation - Simple Log Power Regression.R",sep="/"))


    cat("==================================================================", "\n\n")
}




####
#### Step 6.4: Create Reports ####
####


usePackage("ReporteRs")



####
#### Produce individual reports:  Naive Model (Previous Year) ####
####

if (isTRUE(n1.model)) {



  if (n1$bootmethod=="meboot") {

     docx.file <- paste0(path.reports,"\\","Report_Naive_Modeling_Previous_Year", "_", filename_original,"_",n1$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

		print(" ------------------------------------------------------------")	
		print("starting to source n1/Report - Naive One.R with meboot")
     #source(paste0("R Code","\\","n1","\\","Report - Naive One.R"),echo=TRUE)
     source(paste(path.Rfolder,"n1/Report - Naive One.R",sep="/"),echo=TRUE)

	 	 
     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", n1$stockname, "\n")
     cat("Population/Stock Species", n1$stockspecies, "\n")
     cat("Population/Stock Abundance", n1$stockabundance, "\n")
     cat("Forecasting Year", n1$forecastingyear, "\n")
     cat("Forecasting Model:", "Naive Model (Previous Year)", "\n")
     cat("Bootstrap Method:", n1$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  } # end  if (n1$bootmethod=="meboot")

  if (n1$bootmethod=="stlboot") {

     docx.file <- paste0(path.reports,"\\", "Report_Naive_Modeling_Previous_Year", "_", filename_original, "_",bootmethod,".docx")
     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     ## source("Report - Naive One.R", echo=TRUE)

		print(" ------------------------------------------------------------")
		print("starting to source n1/Report - Naive One.R with STLboot")
	 
     #source(paste0("R Code","\\","n1","\\","Report - Naive One.R"),echo=TRUE)
     source(paste(path.Rfolder,"n1/Report - Naive One.R",sep="/"),echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")
     cat("=============================================================================","\n")

     cat("Population/Stock Name", n1$stockname, "\n")
     cat("Population/Stock Species", n1$stockspecies, "\n")
     cat("Population/Stock Abundance", n1$stockabundance, "\n")
     cat("Forecasting Year", n1$forecastingyear, "\n")
     cat("Forecasting Model:", "Naive Model (Previous Year)", "\n")
     cat("Bootstrap Method:", n1$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()
  }

}


####
#### Produce individual reports:  Naive Model (Average of Previous Three Years) ####
####

if (isTRUE(n3.model)) {

  if (n3$bootmethod=="meboot") {

     docx.file <- paste0(path.reports,"\\","Report_Naive_Modeling_Average_of_Previous_Three_Years", "_", filename_original,"_",n3$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","n3","\\","Report - Average Three.R"),echo=TRUE)
     source(paste(path.Rfolder,"n3/Report - Average Three.R",sep="/"),echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", n3$stockname, "\n")
     cat("Population/Stock Species", n3$stockspecies, "\n")
     cat("Population/Stock Abundance", n3$stockabundance, "\n")
     cat("Forecasting Year", n3$forecastingyear, "\n")
     cat("Forecasting Model:", "Naive Model (Average of Previous Three Years)", "\n")
     cat("Bootstrap Method:", n3$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

  if (n3$bootmethod=="stlboot") {

      docx.file <- paste0(path.reports,"\\","Report_Naive_Modeling_Average_of_Previous_Three_Years", "_", filename_original, "_",n3$bootmethod,".docx")

      startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

      #source(paste0("R Code","\\","n3","\\","Report - Average Three.R"), echo=TRUE)
      source(paste(path.Rfolder,"n3/Report - Average Three.R",sep="/"), echo=TRUE)

      endReport(docx.file=docx.file)

      usePackage("stringr")

      cat("\n\n\n")
      cat("=============================================================================","\n")
      cat("ForecastR report successfully produced and stored in the following directory:","\n")
      cat(homeDir, "\n\n")
      cat("ForecastR report has the following name:", "\n")
      cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")
      cat("=============================================================================","\n")

      cat("Population/Stock Name", n3$stockname, "\n")
      cat("Population/Stock Species", n3$stockspecies, "\n")
      cat("Population/Stock Abundance", n3$stockabundance, "\n")
      cat("Forecasting Year", n3$forecastingyear, "\n")
      cat("Forecasting Model:", "Naive Model (Average of Previous Three Years)", "\n")
      cat("Bootstrap Method:", n3$bootmethod, "\n")
      cat("=============================================================================","\n")

      browseURL(docx.file)

      graphics.off()
  }

}



####
#### Produce individual reports:  Naive Model (Average of Previous Five Years) ####
####

if (isTRUE(n5.model)) {

  if (n5$bootmethod=="meboot") {

     docx.file <- paste0(path.reports,"\\","Report_Naive_Modeling_Average_of_Previous_FIve_Years", "_", filename_original,"_",n5$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)


     #source(paste0("R Code","\\","n5","\\","Report - Average Five.R"),echo=TRUE)
     source(paste(path.Rfolder,"n5/Report - Average Five.R",sep="/"),echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", n5$stockname, "\n")
     cat("Population/Stock Species", n5$stockspecies, "\n")
     cat("Population/Stock Abundance", n5$stockabundance, "\n")
     cat("Forecasting Year", n5$forecastingyear, "\n")
     cat("Forecasting Model:", "Naive Model (Average of Previous Five Years)", "\n")
     cat("Bootstrap Method:", n5$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

  if (n5$bootmethod=="stlboot") {

     docx.file <- paste0(path.reports,"\\","Report_Naive_Modeling_Average_of_Previous_Five_Years", "_", filename_original, "_",n5$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","n5","\\","Report - Average Five.R"), echo=TRUE)
     source(paste(path.Rfolder,"n5/Report - Average Five.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")
     cat("=============================================================================","\n")

     cat("Population/Stock Name", n5$stockname, "\n")
     cat("Population/Stock Species", n5$stockspecies, "\n")
     cat("Population/Stock Abundance", n5$stockabundance, "\n")
     cat("Forecasting Year", n5$forecastingyear, "\n")
     cat("Forecasting Model:", "Naive Model (Average of Previous Five Years)", "\n")
     cat("Bootstrap Method:", n5$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

}


####
#### Produce individual reports:  ARIMA Model ####
####

## ARIMA$forecast.arima.modified.meboot

if (isTRUE(ARIMA.model)) {

  if (ARIMA$bootmethod=="meboot") {

     docx.file <- paste0(path.reports,"\\","Report_ARIMA_Modeling", "_", filename_original,"_",ARIMA$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","ARIMA","\\","Report - ARIMA - meboot.R"), echo=TRUE)
     source(paste(path.Rfolder,"arima/Report - ARIMA - meboot.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", ARIMA$stockname, "\n")
     cat("Population/Stock Species", ARIMA$stockspecies, "\n")
     cat("Population/Stock Abundance", ARIMA$stockabundance, "\n")
     cat("Forecasting Year", ARIMA$forecastingyear, "\n")
     cat("Forecasting Model:", "ARIMA Model", "\n")
     cat("Bootstrap Method:", ARIMA$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

  if (ARIMA$bootmethod=="stlboot") {

     docx.file <- paste0(path.reports,"\\","Report_ARIMA_Modeling", "_", filename_original,"_",ARIMA$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","ARIMA","\\","Report - ARIMA - stlboot.R"), echo=TRUE)
     source(paste(path.Rfolder,"arima/Report - ARIMA - stlboot.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file,paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", ARIMA$stockname, "\n")
     cat("Population/Stock Species", ARIMA$stockspecies, "\n")
     cat("Population/Stock Abundance", ARIMA$stockabundance, "\n")
     cat("Forecasting Year", ARIMA$forecastingyear, "\n")
     cat("Forecasting Model:", "ARIMA Model", "\n")
     cat("Bootstrap Method:", ARIMA$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

}


####
#### Produce individual reports:  Exponential Smoothing Model ####
####

## EXPSMOOTH$forecast.expsmooth.modified.meboot

if (isTRUE(EXPSMOOTH.model)) {

  if (EXPSMOOTH$bootmethod=="meboot") {

     docx.file <- paste0(path.reports,"\\","Report_EXPSMOOTH_Modeling", "_", filename_original,"_",EXPSMOOTH$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","EXPSMOOTH","\\","Report - Exponential Smoothing - meboot.R"), echo=TRUE)
     source(paste(path.Rfolder,"EXPSMOOTH/Report - Exponential Smoothing - meboot.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", EXPSMOOTH$stockname, "\n")
     cat("Population/Stock Species", EXPSMOOTH$stockspecies, "\n")
     cat("Population/Stock Abundance", EXPSMOOTH$stockabundance, "\n")
     cat("Forecasting Year", EXPSMOOTH$forecastingyear, "\n")
     cat("Forecasting Model:", "Exponential Smoothing Model", "\n")
     cat("Bootstrap Method:", EXPSMOOTH$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

  }

  if (EXPSMOOTH$bootmethod=="stlboot") {

     docx.file <- paste0(path.reports,"\\","Report_EXPSMOOTH_Modeling", "_", filename_original,"_",EXPSMOOTH$bootmethod,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","EXPSMOOTH","\\","Report - Exponential Smoothing - stlboot.R"), echo=TRUE)
     source(paste(path.Rfolder,"EXPSMOOTH/Report - Exponential Smoothing - stlboot.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", EXPSMOOTH$stockname, "\n")
     cat("Population/Stock Species", EXPSMOOTH$stockspecies, "\n")
     cat("Population/Stock Abundance", EXPSMOOTH$stockabundance, "\n")
     cat("Forecasting Year", EXPSMOOTH$forecastingyear, "\n")
     cat("Forecasting Model:", "Exponential Smoothing Model", "\n")
     cat("Bootstrap Method:", EXPSMOOTH$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)
     graphics.off()
  }
}


####
#### Produce individual reports:  Simple Sibling Regression ####
####
browser()
if (isTRUE(SIMPLESIBREG.model)) {

     docx.file <- paste0(path.reports,"\\","Report_Simple_Sibling_Regression_Modeling", "_", filename_original,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","SIMPLESIBREG","\\","Report - Simple Sibling Regression.R"), echo=TRUE)
     source(paste(path.Rfolder,"SIMPLESIBREG/Report - Simple Sibling Regression.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", SIMPLESIBREG$stockname, "\n")
     cat("Population/Stock Species", SIMPLESIBREG$stockspecies, "\n")
     cat("Population/Stock Abundance", SIMPLESIBREG$stockabundance, "\n")
     cat("Forecasting Year", SIMPLESIBREG$forecastingyear, "\n")
     cat("Forecasting Model:", "Simple Sibling Regression Model", "\n")
     cat("Bootstrap Method:", SIMPLESIBREG$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

}


####
####  Produce individual reports:  Simple Log Power Regression ####
####

if (isTRUE(SIMPLELOGPOWER.model)) {

     docx.file <- paste0(path.reports,"\\","Report_Simple_Log_Power_Regression_Modeling", "_", filename_original,".docx")

     startReport(template=paste0(path.template,"/","Template_ReporteRs.docx"),
            plotwidth=6, plotheight=7)

     #source(paste0("R Code","\\","SIMPLELOGPOWER","\\","Report - Simple Log Power Regression.R"), echo=TRUE)
     source(paste(path.Rfolder,"SIMPLELOGPOWER/Report - Simple Log Power Regression.R",sep="/"), echo=TRUE)

     endReport(docx.file=docx.file)

     usePackage("stringr")

     cat("\n\n\n")
     cat("=============================================================================","\n")
     cat("ForecastR report successfully produced and stored in the following directory:","\n")
     cat(homeDir, "\n\n")
     cat("ForecastR report has the following name:", "\n")
     cat(str_replace(docx.file, paste0(path.reports,"\\\\"),""), "\n\n")

     cat("Population/Stock Name", SIMPLELOGPOWER$stockname, "\n")
     cat("Population/Stock Species", SIMPLELOGPOWER$stockspecies, "\n")
     cat("Population/Stock Abundance", SIMPLELOGPOWER$stockabundance, "\n")
     cat("Forecasting Year", SIMPLELOGPOWER$forecastingyear, "\n")
     cat("Forecasting Model:", "Simple Log Power Regression Model", "\n")
     cat("Bootstrap Method:", SIMPLELOGPOWER$bootmethod, "\n")
     cat("=============================================================================","\n")

     browseURL(docx.file)

     graphics.off()

}


}

#### END OF "WITH AGE" SECTION ####

} # end function forecastR_Main

