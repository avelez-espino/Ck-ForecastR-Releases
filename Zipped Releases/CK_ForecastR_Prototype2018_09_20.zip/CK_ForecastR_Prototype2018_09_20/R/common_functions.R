avgfive.youngest <- function(series){
	# helper function for computing the average of the past 5 years of a time series
     # n = length of time series
     # n must be strictly greater than 5!!

     n <- length(series)
     fitted <- rep(NA,n)
     residuals <- rep(NA,n)

     for (k in 6:n) {
          fitted[k] <- (series[k-5] + series[k-4] + series[k-3] + series[k-2] + series[k-1])/5
          residuals[k] <- series[k] - fitted[k]
     }

     fcast <- (series[n-4]+ series[n-3] + series[n-2] + series[n-1] + series[n])/5   # point-forecast for series[n+1]

     out <- list()
     out$x <- series
     out$mean <- fcast
     out$fitted <- fitted
     out$residuals <- residuals

     return(out)
}#END avgfive.youngest
