# THIS IS A REPOSITORY OF HELPER FUNCTIONS EMBEDDED IN THE ORIGINAL FORECASTR CODE

# For now, functions are replicated exactly.
# This is just to store them all in one place


#===============================================================================
# Helper Function for Installing R Packages
#===============================================================================

## function for installing and/or loading R packages
usePackage <- function(p) {
    if (!is.element(p, installed.packages()[,1]))
        install.packages(p, dep = TRUE)
        require(p, character.only = TRUE)
}




#===============================================================================
# Helper Function for Capitalizing Words
#===============================================================================

capwords <- function(s, strict = FALSE) {
    cap <- function(s) paste(toupper(substring(s, 1, 1)),
                  {s <- substring(s, 2); if(strict) tolower(s) else s},
                             sep = "", collapse = " " )
    sapply(strsplit(s, split = " "), cap, USE.NAMES = !is.null(names(s)))
}

## capwords(c("using AIC for model selection"))

#===============================================================================
# Helper Function for Wrapping Text
#===============================================================================

wrapper <- function(x, ...){
      paste(strwrap(x, width=50, ...), collapse = "\n")
}




#===============================================================================
# Helper Functions for Creating Word Reports
#===============================================================================


startReport <- function(template="Template_ReporteRs.docx", plotwidth=6, plotheight=7){

    plotwidth <<- plotwidth
    plotheight <<- plotheight

    ## usePackage <- function(p) {
    ##     if (!is.element(p, installed.packages()[,1]))
    ##     install.packages(p, dep = TRUE)
    ##     require(p, character.only = TRUE)
    ## }


    ## usePackage("ReporteRs")

    ## options("ReporteRs-fontsize" = 10,
    ##    "ReporteRs-default-font" = "Calibri")

    options( "ReporteRs-fontsize" = 10,
         "ReporteRs-default-font" = "Calibri")

    # assign the template
    doc <<- docx(template = template, empty_template=TRUE)

    # display available styles
    # styles(doc)

}


endReport <- function(docx.file="Report.docx"){

    # Produce report
    writeDoc(doc, file = docx.file)

    # Open report
    # browseURL(docx.file)

}
