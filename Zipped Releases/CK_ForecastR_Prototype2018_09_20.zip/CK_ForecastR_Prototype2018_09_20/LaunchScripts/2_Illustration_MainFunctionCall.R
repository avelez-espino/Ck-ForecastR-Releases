#########################################################################
# THIS SCRIPT ILLUSTRATES HOW TO USE THE MAIN FUNCTION CALL FOR GENERATING REPORTS
# (e.g. if you want to cycle through a batch of data files)
# (this is also  called inside the GUI when pressing "Create Report")

# NOTE: WORK IN PROGRESS


# SETTING UP

# load/install packages needed for running the model
source("../R/utils.R")
source("../R/common_functions.R")
source("../R/3c_HelperFunctions_ModelSetup.R")

# load the main function call
source("../R/2_MainFunctionCall.R")



#########################################################################
# WITH AGE EXAMPLE 

#list of models:
#"n1.model","n3.model","n5.model","ARIMA.model","EXPSMOOTH.model","SIMPLESIBREG.model","SIMPLELOGPOWER.model"


input.test <- list(model.type="WithAge",file.name="../inst/extdata/SampleFile_WithAge.csv", 
			model.use.withage="n1.model", #
			set.seed= 1700, # random seed
			boots.method = "meboot",  # meboot = maximum entropy bootstrapping , stlboot = use loess bootstrapping for time series bootstrapping
			B =  2500,   # number of bootstrap samples to use when constructing forecast intervals
			index.year = 20,  # minimum number of years to use for retrospective forecast evaluation
			boxcoxtransform = FALSE
			)


#pdf("OUTPUT/Test_Withage.pdf",onefile=TRUE,width=11,height=8.5)
# this stores many of the screen plots, but at some point it gets closed and a screen plot opens

forecastR_Main(input.obj=input.test,
			path.Rfolder="../R",
			path.reports="../ForecastRReports",
			path.template="../TemplateReport")

#dev.off()


#########################################################################
# WITHOUT AGE

# this one runs through large part of it, but crashed with
#  Error in index:(length(y) - 1) : NA/NaN argument

pdf("OUTPUT/Test_Withoutage.pdf",onefile=TRUE,width=11,height=8.5)

# list of models
# "noagemodelnaiveone", "noagemodelavgthree","noagemodelavgfive","noagemodelarima","noagemodelexpsmooth"
# "NTH_TR_No_Age"


input.test=list(model.type="WithoutAge",file.name="inst/extdata/NTH_TR_No_Age.csv", # "Data/SampleFile_WithoutAge.csv"
			model.use.withoutage=c("noagemodelnaiveone", "noagemodelexpsmooth"), #
			boots.method = "meboot",  # meboot = maximum entropy bootstrapping , stlboot = use loess bootstrapping for time series bootstrapping
			B =  2500,   # number of bootstrap samples to use when constructing forecast intervals
			index.year = 20,  # minimum number of years to use for retrospective forecast evaluation
			boxcoxtransform = FALSE
			)

forecastR_Main(input.obj=input.test)

dev.off()


